# # AnalyzeRecipeInstructions200ResponseParsedInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  |
**steps** | [**\OpenAPI\Client\Model\AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner[]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# GetShoppingList200ResponseAislesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**items** | Option<[**Vec<crate::models::GetShoppingList200ResponseAislesInnerItemsInner>**](getShoppingList_200_response_aisles_inner_items_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



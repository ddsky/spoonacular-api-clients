# WWW::OpenAPIClient::Object::AddMealPlanTemplate200ResponseItemsInnerValue

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AddMealPlanTemplate200ResponseItemsInnerValue;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**servings** | **double** |  | [optional] 
**title** | **string** |  | [optional] 
**image_type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



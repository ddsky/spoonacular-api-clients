# # GetAnalyzedRecipeInstructions200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  |
**steps** | [**\OpenAPI\Client\Model\GetAnalyzedRecipeInstructions200ResponseInnerStepsInner[]**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

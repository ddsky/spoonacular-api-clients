# RecipeInformationWinePairingProductMatchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** |  | 
**title** | **String** |  | 
**description** | **String** |  | 
**price** | **String** |  | 
**image_url** | **String** |  | 
**average_rating** | **f64** |  | 
**rating_count** | **i32** |  | 
**score** | **f64** |  | 
**link** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



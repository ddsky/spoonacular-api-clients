# Spoonacular.SearchRestaurants200ResponseRestaurantsInnerAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streetAddr** | **String** |  | [optional] 
**city** | **String** |  | [optional] 
**state** | **String** |  | [optional] 
**zipcode** | **String** |  | [optional] 
**country** | **String** |  | [optional] 
**lat** | **Number** |  | [optional] 
**lon** | **Number** |  | [optional] 
**streetAddr2** | **String** |  | [optional] 
**latitude** | **Number** |  | [optional] 
**longitude** | **Number** |  | [optional] 



# WWW::OpenAPIClient::Object::GetShoppingList200ResponseAislesInnerItemsInnerMeasures

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetShoppingList200ResponseAislesInnerItemsInnerMeasures;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  | 
**metric** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  | 
**us** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



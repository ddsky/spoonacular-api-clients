
# GetRecipeEquipmentByID200ResponseEquipmentInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **kotlin.String** |  | 
**name** | **kotlin.String** |  | 




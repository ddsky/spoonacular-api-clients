
# GetShoppingList200ResponseAislesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **aisle** | **kotlin.String** |  |  |
| **items** | [**kotlin.collections.Set&lt;GetShoppingList200ResponseAislesInnerItemsInner&gt;**](GetShoppingList200ResponseAislesInnerItemsInner.md) |  |  [optional] |




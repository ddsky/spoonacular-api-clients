

# ConvertAmounts200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**sourceAmount** | **BigDecimal** |  |  |
|**sourceUnit** | **String** |  |  |
|**targetAmount** | **BigDecimal** |  |  |
|**targetUnit** | **String** |  |  |
|**answer** | **String** |  |  |




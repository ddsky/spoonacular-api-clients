# WWW::OpenAPIClient::Object::SearchCustomFoods200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchCustomFoods200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**custom_foods** | [**ARRAY[SearchCustomFoods200ResponseCustomFoodsInner]**](SearchCustomFoods200ResponseCustomFoodsInner.md) |  | 
**type** | **string** |  | 
**offset** | **int** |  | 
**number** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



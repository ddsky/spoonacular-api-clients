# AddToMealPlanRequest1Value

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**Vec<crate::models::AddToMealPlanRequest1ValueIngredientsInner>**](addToMealPlan_request_1_value_ingredients_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



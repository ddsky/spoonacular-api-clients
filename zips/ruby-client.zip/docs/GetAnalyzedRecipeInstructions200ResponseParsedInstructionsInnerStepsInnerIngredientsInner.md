# OpenapiClient::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **name** | **String** |  |  |
| **localized_name** | **String** |  |  |
| **image** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.new(
  id: null,
  name: null,
  localized_name: null,
  image: null
)
```


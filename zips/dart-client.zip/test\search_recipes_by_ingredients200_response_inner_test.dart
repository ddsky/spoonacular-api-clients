//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchRecipesByIngredients200ResponseInner
void main() {
  // final instance = SearchRecipesByIngredients200ResponseInner();

  group('test SearchRecipesByIngredients200ResponseInner', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String imageType
    test('to test the property `imageType`', () async {
      // TODO
    });

    // int likes
    test('to test the property `likes`', () async {
      // TODO
    });

    // int missedIngredientCount
    test('to test the property `missedIngredientCount`', () async {
      // TODO
    });

    // Set<SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner> missedIngredients (default value: const {})
    test('to test the property `missedIngredients`', () async {
      // TODO
    });

    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // List<Object> unusedIngredients (default value: const [])
    test('to test the property `unusedIngredients`', () async {
      // TODO
    });

    // num usedIngredientCount
    test('to test the property `usedIngredientCount`', () async {
      // TODO
    });

    // Set<SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner> usedIngredients (default value: const {})
    test('to test the property `usedIngredients`', () async {
      // TODO
    });


  });

}

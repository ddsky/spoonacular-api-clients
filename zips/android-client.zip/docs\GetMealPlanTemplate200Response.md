

# GetMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**name** | **String** |  | 
**days** | [**Set&lt;GetMealPlanTemplate200ResponseDaysInner&gt;**](GetMealPlanTemplate200ResponseDaysInner.md) |  | 





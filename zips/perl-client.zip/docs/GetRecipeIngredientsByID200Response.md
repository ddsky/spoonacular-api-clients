# WWW::OpenAPIClient::Object::GetRecipeIngredientsByID200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetRecipeIngredientsByID200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**ARRAY[GetRecipeIngredientsByID200ResponseIngredientsInner]**](GetRecipeIngredientsByID200ResponseIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



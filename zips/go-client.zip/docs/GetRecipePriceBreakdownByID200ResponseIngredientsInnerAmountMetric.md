# GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Unit** | **string** |  | 
**Value** | **float32** |  | 

## Methods

### NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric

`func NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric(unit string, value float32, ) *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric`

NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric instantiates a new GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetricWithDefaults

`func NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetricWithDefaults() *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric`

NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetricWithDefaults instantiates a new GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetUnit

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric) GetUnit() string`

GetUnit returns the Unit field if non-nil, zero value otherwise.

### GetUnitOk

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric) GetUnitOk() (*string, bool)`

GetUnitOk returns a tuple with the Unit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnit

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric) SetUnit(v string)`

SetUnit sets Unit field to given value.


### GetValue

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric) GetValue() float32`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric) GetValueOk() (*float32, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric) SetValue(v float32)`

SetValue sets Value field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



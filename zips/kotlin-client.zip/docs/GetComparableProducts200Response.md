
# GetComparableProducts200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comparableProducts** | [**GetComparableProducts200ResponseComparableProducts**](GetComparableProducts200ResponseComparableProducts.md) |  | 




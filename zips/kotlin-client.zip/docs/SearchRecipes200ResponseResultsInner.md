
# SearchRecipes200ResponseResultsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**title** | **kotlin.String** |  | 
**calories** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**carbs** | **kotlin.String** |  | 
**fat** | **kotlin.String** |  | 
**image** | **kotlin.String** |  | 
**imageType** | **kotlin.String** |  | 
**protein** | **kotlin.String** |  | 




# OpenapiClient::GetRandomFoodTrivia200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **text** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRandomFoodTrivia200Response.new(
  text: null
)
```


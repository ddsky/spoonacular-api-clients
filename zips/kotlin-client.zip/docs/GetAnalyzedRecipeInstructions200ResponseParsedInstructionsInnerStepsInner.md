
# GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **number** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **step** | **kotlin.String** |  |  |
| **ingredients** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
| **equipment** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |




# WWW::OpenAPIClient::Object::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**steps** | [**ARRAY[GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner]**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



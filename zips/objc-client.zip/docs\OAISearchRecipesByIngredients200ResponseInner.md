# OAISearchRecipesByIngredients200ResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** |  | 
**image** | **NSString*** |  | 
**imageType** | **NSString*** |  | 
**likes** | **NSNumber*** |  | 
**missedIngredientCount** | **NSNumber*** |  | 
**missedIngredients** | [**OAISet&lt;OAISearchRecipesByIngredients200ResponseInnerMissedIngredientsInner&gt;***](OAISearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 
**title** | **NSString*** |  | 
**unusedIngredients** | **NSArray&lt;NSObject*&gt;*** |  | 
**usedIngredientCount** | **NSNumber*** |  | 
**usedIngredients** | [**OAISet&lt;OAISearchRecipesByIngredients200ResponseInnerMissedIngredientsInner&gt;***](OAISearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



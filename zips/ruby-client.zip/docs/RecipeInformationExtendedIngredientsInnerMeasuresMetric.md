# OpenapiClient::RecipeInformationExtendedIngredientsInnerMeasuresMetric

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | **Float** |  |  |
| **unit_long** | **String** |  |  |
| **unit_short** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RecipeInformationExtendedIngredientsInnerMeasuresMetric.new(
  amount: null,
  unit_long: null,
  unit_short: null
)
```


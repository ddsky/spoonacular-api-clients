# spoonacular.Model.ParseIngredients200ResponseInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nutrients** | [**List&lt;ParseIngredients200ResponseInnerNutritionNutrientsInner&gt;**](ParseIngredients200ResponseInnerNutritionNutrientsInner.md) |  | 
**Properties** | [**List&lt;ParseIngredients200ResponseInnerNutritionPropertiesInner&gt;**](ParseIngredients200ResponseInnerNutritionPropertiesInner.md) |  | 
**Flavonoids** | [**List&lt;ParseIngredients200ResponseInnerNutritionPropertiesInner&gt;**](ParseIngredients200ResponseInnerNutritionPropertiesInner.md) |  | 
**CaloricBreakdown** | [**ParseIngredients200ResponseInnerNutritionCaloricBreakdown**](ParseIngredients200ResponseInnerNutritionCaloricBreakdown.md) |  | 
**WeightPerServing** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


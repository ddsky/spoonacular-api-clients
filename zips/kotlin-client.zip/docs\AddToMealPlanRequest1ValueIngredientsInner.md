
# AddToMealPlanRequest1ValueIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  | 






# SearchRestaurants200ResponseRestaurantsInnerAddress


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**streetAddr** | **String** |  |  [optional] |
|**city** | **String** |  |  [optional] |
|**state** | **String** |  |  [optional] |
|**zipcode** | **String** |  |  [optional] |
|**country** | **String** |  |  [optional] |
|**lat** | **BigDecimal** |  |  [optional] |
|**lon** | **BigDecimal** |  |  [optional] |
|**streetAddr2** | **String** |  |  [optional] |
|**latitude** | **BigDecimal** |  |  [optional] |
|**longitude** | **BigDecimal** |  |  [optional] |




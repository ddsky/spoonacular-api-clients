# SpoonacularApi.ClassifyGroceryProduct200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cleanTitle** | **String** |  | 
**image** | **String** |  | 
**category** | **String** |  | 
**breadcrumbs** | **[String]** |  | 
**usdaCode** | **Number** |  | 



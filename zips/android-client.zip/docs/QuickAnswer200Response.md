

# QuickAnswer200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answer** | **String** |  | 
**image** | **String** |  | 





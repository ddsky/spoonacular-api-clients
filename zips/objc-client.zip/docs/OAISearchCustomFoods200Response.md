# OAISearchCustomFoods200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customFoods** | [**OAISet&lt;OAISearchCustomFoods200ResponseCustomFoodsInner&gt;***](OAISearchCustomFoods200ResponseCustomFoodsInner.md) |  | 
**type** | **NSString*** |  | 
**offset** | **NSNumber*** |  | 
**number** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



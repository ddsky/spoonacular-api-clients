
# AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**name** | **kotlin.String** |  | 
**localizedName** | **kotlin.String** |  | 
**image** | **kotlin.String** |  | 




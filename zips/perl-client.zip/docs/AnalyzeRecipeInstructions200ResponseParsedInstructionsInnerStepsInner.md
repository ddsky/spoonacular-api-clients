# WWW::OpenAPIClient::Object::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **double** |  | 
**step** | **string** |  | 
**ingredients** | [**ARRAY[AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | [**ARRAY[AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



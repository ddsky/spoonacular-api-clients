
# SummarizeRecipe200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** |  |  |
| **summary** | **kotlin.String** |  |  |
| **title** | **kotlin.String** |  |  |




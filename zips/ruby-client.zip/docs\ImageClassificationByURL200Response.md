# OpenapiClient::ImageClassificationByURL200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **category** | **String** |  |  |
| **probability** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ImageClassificationByURL200Response.new(
  category: null,
  probability: null
)
```


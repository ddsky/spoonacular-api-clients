# # SearchAllFood200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **string** |  |
**total_results** | **int** |  |
**limit** | **int** |  |
**offset** | **int** |  |
**search_results** | [**\OpenAPI\Client\Model\SearchAllFood200ResponseSearchResultsInner[]**](SearchAllFood200ResponseSearchResultsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

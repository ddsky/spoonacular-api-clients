# ImageAnalysisByUrl200ResponseNutritionCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **f32** |  | 
**unit** | **String** |  | 
**confidence_range95_percent** | [**crate::models::ImageAnalysisByUrl200ResponseNutritionCaloriesConfidenceRange95Percent**](imageAnalysisByURL_200_response_nutrition_calories_confidenceRange95Percent.md) |  | 
**standard_deviation** | **f32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



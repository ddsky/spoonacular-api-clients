# ConvertAmounts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source_amount** | **f64** |  | 
**source_unit** | **String** |  | 
**target_amount** | **f64** |  | 
**target_unit** | **String** |  | 
**answer** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



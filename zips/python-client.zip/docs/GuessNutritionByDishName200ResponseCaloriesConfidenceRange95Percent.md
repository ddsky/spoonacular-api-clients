# GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | **float** |  | 
**min** | **float** |  | 

## Example

```python
from spoonacular.models.guess_nutrition_by_dish_name200_response_calories_confidence_range95_percent import GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent

# TODO update the JSON string below
json = "{}"
# create an instance of GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent from a JSON string
guess_nutrition_by_dish_name200_response_calories_confidence_range95_percent_instance = GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.from_json(json)
# print the JSON string representation of the object
print GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.to_json()

# convert the object into a dict
guess_nutrition_by_dish_name200_response_calories_confidence_range95_percent_dict = guess_nutrition_by_dish_name200_response_calories_confidence_range95_percent_instance.to_dict()
# create an instance of GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent from a dict
guess_nutrition_by_dish_name200_response_calories_confidence_range95_percent_form_dict = guess_nutrition_by_dish_name200_response_calories_confidence_range95_percent.from_dict(guess_nutrition_by_dish_name200_response_calories_confidence_range95_percent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



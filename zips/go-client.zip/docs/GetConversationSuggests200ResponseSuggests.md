# GetConversationSuggests200ResponseSuggests

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_** | [**[]GetConversationSuggests200ResponseSuggestsInner**](GetConversationSuggests200ResponseSuggestsInner.md) |  | 

## Methods

### NewGetConversationSuggests200ResponseSuggests

`func NewGetConversationSuggests200ResponseSuggests( []GetConversationSuggests200ResponseSuggestsInner, ) *GetConversationSuggests200ResponseSuggests`

NewGetConversationSuggests200ResponseSuggests instantiates a new GetConversationSuggests200ResponseSuggests object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetConversationSuggests200ResponseSuggestsWithDefaults

`func NewGetConversationSuggests200ResponseSuggestsWithDefaults() *GetConversationSuggests200ResponseSuggests`

NewGetConversationSuggests200ResponseSuggestsWithDefaults instantiates a new GetConversationSuggests200ResponseSuggests object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### Get_

`func (o *GetConversationSuggests200ResponseSuggests) Get_() []GetConversationSuggests200ResponseSuggestsInner`

Get_ returns the _ field if non-nil, zero value otherwise.

### Get_Ok

`func (o *GetConversationSuggests200ResponseSuggests) Get_Ok() (*[]GetConversationSuggests200ResponseSuggestsInner, bool)`

Get_Ok returns a tuple with the _ field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### Set_

`func (o *GetConversationSuggests200ResponseSuggests) Set_(v []GetConversationSuggests200ResponseSuggestsInner)`

Set_ sets _ field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



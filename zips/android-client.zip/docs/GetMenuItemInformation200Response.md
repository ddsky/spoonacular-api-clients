

# GetMenuItemInformation200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**restaurantChain** | **String** |  | 
**nutrition** | [**SearchGroceryProductsByUPC200ResponseNutrition**](SearchGroceryProductsByUPC200ResponseNutrition.md) |  | 
**badges** | **List&lt;String&gt;** |  | 
**breadcrumbs** | **List&lt;String&gt;** |  | 
**generatedText** | **String** |  |  [optional]
**imageType** | **String** |  | 
**likes** | [**BigDecimal**](BigDecimal.md) |  | 
**servings** | [**SearchGroceryProductsByUPC200ResponseServings**](SearchGroceryProductsByUPC200ResponseServings.md) |  | 
**price** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**spoonacularScore** | [**BigDecimal**](BigDecimal.md) |  |  [optional]





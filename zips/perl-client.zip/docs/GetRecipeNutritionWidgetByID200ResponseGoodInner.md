# WWW::OpenAPIClient::Object::GetRecipeNutritionWidgetByID200ResponseGoodInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetRecipeNutritionWidgetByID200ResponseGoodInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **string** |  | 
**indented** | **boolean** |  | 
**percent_of_daily_needs** | **double** |  | 
**name** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



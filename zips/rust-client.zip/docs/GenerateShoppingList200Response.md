# GenerateShoppingList200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**Vec<models::GetShoppingList200ResponseAislesInner>**](getShoppingList_200_response_aisles_inner.md) |  | 
**cost** | **f64** |  | 
**start_date** | **f64** |  | 
**end_date** | **f64** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



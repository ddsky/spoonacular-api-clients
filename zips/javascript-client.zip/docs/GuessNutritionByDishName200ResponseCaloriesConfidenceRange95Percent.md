# Spoonacular.GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | **Number** |  | 
**min** | **Number** |  | 



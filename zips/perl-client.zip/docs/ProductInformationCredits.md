# WWW::OpenAPIClient::Object::ProductInformationCredits

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ProductInformationCredits;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **string** |  | [optional] 
**link** | **string** |  | [optional] 
**image** | **string** |  | [optional] 
**image_link** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OAISearchCustomFoods200ResponseCustomFoodsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** |  | 
**title** | **NSString*** |  | 
**servings** | **NSNumber*** |  | 
**imageUrl** | **NSString*** |  | 
**price** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



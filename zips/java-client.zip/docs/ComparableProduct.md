

# ComparableProduct


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**difference** | **BigDecimal** |  |  |
|**id** | **Integer** |  |  |
|**image** | **String** |  |  |
|**title** | **String** |  |  |




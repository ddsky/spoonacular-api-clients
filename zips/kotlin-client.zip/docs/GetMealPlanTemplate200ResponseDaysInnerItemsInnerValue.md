
# GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **title** | **kotlin.String** |  |  |
| **imageType** | **kotlin.String** |  |  |




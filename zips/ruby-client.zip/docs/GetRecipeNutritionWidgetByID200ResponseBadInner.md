# OpenapiClient::GetRecipeNutritionWidgetByID200ResponseBadInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **amount** | **String** |  |  |
| **indented** | **Boolean** |  |  |
| **percent_of_daily_needs** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipeNutritionWidgetByID200ResponseBadInner.new(
  name: null,
  amount: null,
  indented: null,
  percent_of_daily_needs: null
)
```


# OAIAnalyzeARecipeSearchQuery200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dishes** | [**OAISet&lt;OAIAnalyzeARecipeSearchQuery200ResponseDishesInner&gt;***](OAIAnalyzeARecipeSearchQuery200ResponseDishesInner.md) |  | 
**ingredients** | [**OAISet&lt;OAIAnalyzeARecipeSearchQuery200ResponseIngredientsInner&gt;***](OAIAnalyzeARecipeSearchQuery200ResponseIngredientsInner.md) |  | 
**cuisines** | **NSArray&lt;NSString*&gt;*** |  | 
**modifiers** | **NSArray&lt;NSString*&gt;*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



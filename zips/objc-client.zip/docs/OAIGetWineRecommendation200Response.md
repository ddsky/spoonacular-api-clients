# OAIGetWineRecommendation200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommendedWines** | [**OAISet&lt;OAIGetWineRecommendation200ResponseRecommendedWinesInner&gt;***](OAIGetWineRecommendation200ResponseRecommendedWinesInner.md) |  | 
**totalFound** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



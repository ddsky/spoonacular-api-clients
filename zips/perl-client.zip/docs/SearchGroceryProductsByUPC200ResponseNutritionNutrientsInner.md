# WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**amount** | **double** |  | 
**unit** | **string** |  | 
**percent_of_daily_needs** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# SearchRecipesByIngredients200ResponseInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  |
|**image** | **String** |  |  |
|**imageType** | **String** |  |  |
|**likes** | **Integer** |  |  |
|**missedIngredientCount** | **Integer** |  |  |
|**missedIngredients** | [**Set&lt;SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner&gt;**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  |  |
|**title** | **String** |  |  |
|**unusedIngredients** | **List&lt;Object&gt;** |  |  |
|**usedIngredientCount** | **BigDecimal** |  |  |
|**usedIngredients** | [**Set&lt;SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner&gt;**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  |  |




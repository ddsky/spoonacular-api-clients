# OpenapiClient::GetMealPlanWeek200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **days** | [**Array&lt;GetMealPlanWeek200ResponseDaysInner&gt;**](GetMealPlanWeek200ResponseDaysInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetMealPlanWeek200Response.new(
  days: null
)
```



# GenerateShoppingListRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **kotlin.String** | The username. | 
**startDate** | **kotlin.String** | The start date in the format yyyy-mm-dd. | 
**endDate** | **kotlin.String** | The end date in the format yyyy-mm-dd. | 
**hash** | **kotlin.String** | The private hash for the username. | 




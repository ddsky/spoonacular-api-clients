# # GetShoppingList200ResponseAislesInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**name** | **string** |  |
**measures** | [**\OpenAPI\Client\Model\GetShoppingList200ResponseAislesInnerItemsInnerMeasures**](GetShoppingList200ResponseAislesInnerItemsInnerMeasures.md) |  | [optional]
**pantry_item** | **bool** |  |
**aisle** | **string** |  |
**cost** | **float** |  |
**ingredient_id** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

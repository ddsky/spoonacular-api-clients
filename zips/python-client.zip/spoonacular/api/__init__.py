# flake8: noqa

# import apis into api package
from spoonacular.api.default_api import DefaultApi
from spoonacular.api.ingredients_api import IngredientsApi
from spoonacular.api.meal_planning_api import MealPlanningApi
from spoonacular.api.menu_items_api import MenuItemsApi
from spoonacular.api.misc_api import MiscApi
from spoonacular.api.products_api import ProductsApi
from spoonacular.api.recipes_api import RecipesApi
from spoonacular.api.wine_api import WineApi


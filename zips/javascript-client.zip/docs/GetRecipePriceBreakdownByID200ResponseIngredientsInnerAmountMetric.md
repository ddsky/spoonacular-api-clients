# SpoonacularApi.GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit** | **String** |  | 
**value** | **Number** |  | 



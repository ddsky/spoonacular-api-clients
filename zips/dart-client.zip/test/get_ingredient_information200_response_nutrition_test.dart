//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GetIngredientInformation200ResponseNutrition
void main() {
  // final instance = GetIngredientInformation200ResponseNutrition();

  group('test GetIngredientInformation200ResponseNutrition', () {
    // Set<ParseIngredients200ResponseInnerNutritionNutrientsInner> nutrients (default value: const {})
    test('to test the property `nutrients`', () async {
      // TODO
    });

    // Set<ParseIngredients200ResponseInnerNutritionPropertiesInner> properties (default value: const {})
    test('to test the property `properties`', () async {
      // TODO
    });

    // ParseIngredients200ResponseInnerNutritionCaloricBreakdown caloricBreakdown
    test('to test the property `caloricBreakdown`', () async {
      // TODO
    });

    // ParseIngredients200ResponseInnerNutritionWeightPerServing weightPerServing
    test('to test the property `weightPerServing`', () async {
      // TODO
    });


  });

}

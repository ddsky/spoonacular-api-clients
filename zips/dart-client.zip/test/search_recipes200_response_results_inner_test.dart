//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchRecipes200ResponseResultsInner
void main() {
  // final instance = SearchRecipes200ResponseResultsInner();

  group('test SearchRecipes200ResponseResultsInner', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String imageType
    test('to test the property `imageType`', () async {
      // TODO
    });


  });

}

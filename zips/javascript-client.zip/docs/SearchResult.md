# SpoonacularApi.SearchResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataPoints** | [**[SearchResultDataPointsInner]**](SearchResultDataPointsInner.md) |  | [optional] 
**image** | **String** |  | [optional] 
**link** | **String** |  | [optional] 
**name** | **String** |  | 
**type** | **String** |  | [optional] 
**kvtable** | **String** |  | [optional] 
**content** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**relevance** | **Number** |  | [optional] 



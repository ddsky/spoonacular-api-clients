# OAIGetWinePairing200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **NSArray&lt;NSString*&gt;*** |  | 
**pairingText** | **NSString*** |  | 
**productMatches** | [**OAISet&lt;OAIGetWinePairing200ResponseProductMatchesInner&gt;***](OAIGetWinePairing200ResponseProductMatchesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



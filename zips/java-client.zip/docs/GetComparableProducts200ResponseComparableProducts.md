

# GetComparableProducts200ResponseComparableProducts


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**calories** | **List&lt;Object&gt;** |  |  |
|**likes** | **List&lt;Object&gt;** |  |  |
|**price** | **List&lt;Object&gt;** |  |  |
|**protein** | [**Set&lt;GetComparableProducts200ResponseComparableProductsProteinInner&gt;**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  |  |
|**spoonacularScore** | [**Set&lt;GetComparableProducts200ResponseComparableProductsProteinInner&gt;**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  |  |
|**sugar** | **List&lt;Object&gt;** |  |  |




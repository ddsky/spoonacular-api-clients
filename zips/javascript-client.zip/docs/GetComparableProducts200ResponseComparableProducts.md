# SpoonacularApi.GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **[Object]** |  | 
**likes** | **[Object]** |  | 
**price** | **[Object]** |  | 
**protein** | [**[GetComparableProducts200ResponseComparableProductsProteinInner]**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**spoonacularScore** | [**[GetComparableProducts200ResponseComparableProductsProteinInner]**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**sugar** | **[Object]** |  | 



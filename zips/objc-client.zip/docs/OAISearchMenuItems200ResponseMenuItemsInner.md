# OAISearchMenuItems200ResponseMenuItemsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** |  | 
**title** | **NSString*** |  | 
**restaurantChain** | **NSString*** |  | 
**image** | **NSString*** |  | 
**imageType** | **NSString*** |  | 
**servings** | [**OAISearchGroceryProductsByUPC200ResponseServings***](OAISearchGroceryProductsByUPC200ResponseServings.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



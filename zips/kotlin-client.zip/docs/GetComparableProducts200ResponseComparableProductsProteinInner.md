
# GetComparableProducts200ResponseComparableProductsProteinInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **difference** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **id** | **kotlin.Int** |  |  |
| **image** | **kotlin.String** |  |  |
| **title** | **kotlin.String** |  |  |




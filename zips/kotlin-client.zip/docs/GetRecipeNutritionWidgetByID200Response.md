
# GetRecipeNutritionWidgetByID200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **calories** | **kotlin.String** |  |  |
| **carbs** | **kotlin.String** |  |  |
| **fat** | **kotlin.String** |  |  |
| **protein** | **kotlin.String** |  |  |
| **bad** | [**kotlin.collections.Set&lt;GetRecipeNutritionWidgetByID200ResponseBadInner&gt;**](GetRecipeNutritionWidgetByID200ResponseBadInner.md) |  |  |
| **good** | [**kotlin.collections.Set&lt;GetRecipeNutritionWidgetByID200ResponseGoodInner&gt;**](GetRecipeNutritionWidgetByID200ResponseGoodInner.md) |  |  |




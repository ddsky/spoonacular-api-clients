# OpenapiClient::ImageAnalysisByURL200ResponseRecipesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **title** | **String** |  |  |
| **image_type** | **String** |  |  |
| **url** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ImageAnalysisByURL200ResponseRecipesInner.new(
  id: null,
  title: null,
  image_type: null,
  url: null
)
```


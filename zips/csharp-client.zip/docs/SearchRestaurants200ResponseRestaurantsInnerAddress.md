# Org.OpenAPITools.Model.SearchRestaurants200ResponseRestaurantsInnerAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StreetAddr** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**State** | **string** |  | [optional] 
**Zipcode** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 
**Lat** | **decimal?** |  | [optional] 
**Lon** | **decimal?** |  | [optional] 
**StreetAddr2** | **string** |  | [optional] 
**Latitude** | **decimal?** |  | [optional] 
**Longitude** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# Org.OpenAPITools.Model.ConvertAmounts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceAmount** | **decimal?** |  | 
**SourceUnit** | **string** |  | 
**TargetAmount** | **decimal?** |  | 
**TargetUnit** | **string** |  | 
**Answer** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


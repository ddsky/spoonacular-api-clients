# Org.OpenAPITools.Model.GetWinePairing200ResponseProductMatchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | 
**Title** | **string** |  | 
**AverageRating** | **decimal?** |  | 
**Description** | **Object** |  | [optional] 
**ImageUrl** | **string** |  | 
**Link** | **string** |  | 
**Price** | **string** |  | 
**RatingCount** | **int?** |  | 
**Score** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# Spoonacular.RecipeInformationExtendedIngredientsInnerMeasuresMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | 
**unitLong** | **String** |  | 
**unitShort** | **String** |  | 



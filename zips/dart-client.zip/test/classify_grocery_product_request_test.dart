//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ClassifyGroceryProductRequest
void main() {
  // final instance = ClassifyGroceryProductRequest();

  group('test ClassifyGroceryProductRequest', () {
    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // String upc
    test('to test the property `upc`', () async {
      // TODO
    });

    // String pluCode
    test('to test the property `pluCode`', () async {
      // TODO
    });


  });

}

# SpoonacularApi.AddToMealPlanRequest1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **Number** |  | 
**slot** | **Number** |  | 
**position** | **Number** |  | 
**type** | **String** |  | 
**value** | [**AddToMealPlanRequest1Value**](AddToMealPlanRequest1Value.md) |  | 




# SearchRestaurants200ResponseRestaurantsInnerAddress

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **streetAddr** | **kotlin.String** |  |  [optional] |
| **city** | **kotlin.String** |  |  [optional] |
| **state** | **kotlin.String** |  |  [optional] |
| **zipcode** | **kotlin.String** |  |  [optional] |
| **country** | **kotlin.String** |  |  [optional] |
| **lat** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **lon** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **streetAddr2** | **kotlin.String** |  |  [optional] |
| **latitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **longitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |




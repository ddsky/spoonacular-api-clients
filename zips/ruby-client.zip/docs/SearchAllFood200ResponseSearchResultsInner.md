# OpenapiClient::SearchAllFood200ResponseSearchResultsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **total_results** | **Integer** |  |  |
| **results** | [**Array&lt;SearchResult&gt;**](SearchResult.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchAllFood200ResponseSearchResultsInner.new(
  name: null,
  total_results: null,
  results: null
)
```


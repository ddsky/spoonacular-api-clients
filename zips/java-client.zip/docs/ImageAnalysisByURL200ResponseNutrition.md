

# ImageAnalysisByURL200ResponseNutrition


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**recipesUsed** | **Integer** |  |  |
|**calories** | [**ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |  |
|**fat** | [**ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |  |
|**protein** | [**ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |  |
|**carbs** | [**ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |  |




# OpenapiClient::SearchCustomFoods200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **custom_foods** | [**Array&lt;SearchCustomFoods200ResponseCustomFoodsInner&gt;**](SearchCustomFoods200ResponseCustomFoodsInner.md) |  |  |
| **type** | **String** |  |  |
| **offset** | **Integer** |  |  |
| **number** | **Integer** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchCustomFoods200Response.new(
  custom_foods: null,
  type: null,
  offset: null,
  number: null
)
```


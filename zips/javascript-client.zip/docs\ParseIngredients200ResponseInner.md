# SpoonacularApi.ParseIngredients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**original** | **String** |  | 
**originalName** | **String** |  | 
**name** | **String** |  | 
**nameClean** | **String** |  | 
**amount** | **Number** |  | 
**unit** | **String** |  | 
**unitShort** | **String** |  | 
**unitLong** | **String** |  | 
**possibleUnits** | **[String]** |  | 
**estimatedCost** | [**ParseIngredients200ResponseInnerEstimatedCost**](ParseIngredients200ResponseInnerEstimatedCost.md) |  | 
**consistency** | **String** |  | 
**aisle** | **String** |  | 
**image** | **String** |  | 
**meta** | **[String]** |  | 
**nutrition** | [**ParseIngredients200ResponseInnerNutrition**](ParseIngredients200ResponseInnerNutrition.md) |  | 




# GetMealPlanWeek200ResponseDaysInnerItemsInnerValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**servings** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**title** | **kotlin.String** |  | 
**imageType** | **kotlin.String** |  | 




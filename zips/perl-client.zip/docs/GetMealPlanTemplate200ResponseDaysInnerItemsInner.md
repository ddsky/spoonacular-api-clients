# WWW::OpenAPIClient::Object::GetMealPlanTemplate200ResponseDaysInnerItemsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetMealPlanTemplate200ResponseDaysInnerItemsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**slot** | **int** |  | 
**position** | **int** |  | 
**type** | **string** |  | 
**value** | [**GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue**](GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



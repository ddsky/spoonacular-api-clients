# spoonacular.Model.AnalyzeRecipeInstructions200ResponseParsedInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | 
**Steps** | [**List&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# OAIImageAnalysisByURL200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition** | [**OAIImageAnalysisByURL200ResponseNutrition***](OAIImageAnalysisByURL200ResponseNutrition.md) |  | 
**category** | [**OAIImageAnalysisByURL200ResponseCategory***](OAIImageAnalysisByURL200ResponseCategory.md) |  | 
**recipes** | [**OAISet&lt;OAIImageAnalysisByURL200ResponseRecipesInner&gt;***](OAIImageAnalysisByURL200ResponseRecipesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# SearchGroceryProductsByUPC200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | [**OasAnyTypeNotMapped**](.md) |  |  [optional]
**name** | **String** |  | 
**safetyLevel** | [**OasAnyTypeNotMapped**](.md) |  |  [optional]





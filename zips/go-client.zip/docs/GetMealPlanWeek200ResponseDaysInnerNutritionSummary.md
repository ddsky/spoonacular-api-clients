# GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nutrients** | [**[]GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner**](GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.md) |  | 

## Methods

### NewGetMealPlanWeek200ResponseDaysInnerNutritionSummary

`func NewGetMealPlanWeek200ResponseDaysInnerNutritionSummary(nutrients []GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner, ) *GetMealPlanWeek200ResponseDaysInnerNutritionSummary`

NewGetMealPlanWeek200ResponseDaysInnerNutritionSummary instantiates a new GetMealPlanWeek200ResponseDaysInnerNutritionSummary object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetMealPlanWeek200ResponseDaysInnerNutritionSummaryWithDefaults

`func NewGetMealPlanWeek200ResponseDaysInnerNutritionSummaryWithDefaults() *GetMealPlanWeek200ResponseDaysInnerNutritionSummary`

NewGetMealPlanWeek200ResponseDaysInnerNutritionSummaryWithDefaults instantiates a new GetMealPlanWeek200ResponseDaysInnerNutritionSummary object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNutrients

`func (o *GetMealPlanWeek200ResponseDaysInnerNutritionSummary) GetNutrients() []GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner`

GetNutrients returns the Nutrients field if non-nil, zero value otherwise.

### GetNutrientsOk

`func (o *GetMealPlanWeek200ResponseDaysInnerNutritionSummary) GetNutrientsOk() (*[]GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner, bool)`

GetNutrientsOk returns a tuple with the Nutrients field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNutrients

`func (o *GetMealPlanWeek200ResponseDaysInnerNutritionSummary) SetNutrients(v []GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner)`

SetNutrients sets Nutrients field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



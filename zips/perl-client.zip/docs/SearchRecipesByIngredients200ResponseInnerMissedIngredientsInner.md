# WWW::OpenAPIClient::Object::SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **string** |  | 
**amount** | **double** |  | 
**id** | **int** |  | 
**image** | **string** |  | 
**meta** | **ARRAY[string]** |  | [optional] 
**name** | **string** |  | 
**original** | **string** |  | 
**original_name** | **string** |  | 
**unit** | **string** |  | 
**unit_long** | **string** |  | 
**unit_short** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# # AddMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  |
**items** | [**\OpenAPI\Client\Model\AddMealPlanTemplate200ResponseItemsInner[]**](AddMealPlanTemplate200ResponseItemsInner.md) |  |
**publish_as_public** | **bool** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

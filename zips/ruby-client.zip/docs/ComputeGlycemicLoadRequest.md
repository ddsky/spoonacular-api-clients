# OpenapiClient::ComputeGlycemicLoadRequest

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **ingredients** | **Array&lt;String&gt;** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ComputeGlycemicLoadRequest.new(
  ingredients: null
)
```


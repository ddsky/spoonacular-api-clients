# OpenapiClient::AnalyzeARecipeSearchQuery200ResponseIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **image** | **String** |  |  |
| **include** | **Boolean** |  |  |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AnalyzeARecipeSearchQuery200ResponseIngredientsInner.new(
  image: null,
  include: null,
  name: null
)
```


# Org.OpenAPITools.Model.GetRandomRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Recipes** | [**List<GetRandomRecipes200ResponseRecipesInner>**](GetRandomRecipes200ResponseRecipesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


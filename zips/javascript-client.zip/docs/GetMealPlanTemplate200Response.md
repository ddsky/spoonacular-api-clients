# SpoonacularApi.GetMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | 
**days** | [**[GetMealPlanTemplate200ResponseDaysInner]**](GetMealPlanTemplate200ResponseDaysInner.md) |  | 



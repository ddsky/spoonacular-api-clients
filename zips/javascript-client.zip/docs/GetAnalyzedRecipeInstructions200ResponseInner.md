# SpoonacularApi.GetAnalyzedRecipeInstructions200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**steps** | [**[GetAnalyzedRecipeInstructions200ResponseInnerStepsInner]**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInner.md) |  | [optional] 



# WWW::OpenAPIClient::Object::GetRecipeNutritionWidgetByID200ResponseBadInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetRecipeNutritionWidgetByID200ResponseBadInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | 
**amount** | **string** |  | 
**indented** | **boolean** |  | 
**percent_of_daily_needs** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



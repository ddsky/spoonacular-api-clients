# SpoonacularApi.SearchSiteContent200ResponseArticlesInnerDataPointsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | 
**value** | **String** |  | 



# SpoonacularApi.ParseIngredients200ResponseInnerNutritionNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**amount** | **Number** |  | 
**unit** | **String** |  | 
**percentOfDailyNeeds** | **Number** |  | 



# # GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **object[]** |  |
**likes** | **object[]** |  |
**price** | **object[]** |  |
**protein** | [**\com.spoonacular.client\com.spoonacular.client.model\GetComparableProducts200ResponseComparableProductsProteinInner[]**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  |
**spoonacular_score** | [**\com.spoonacular.client\com.spoonacular.client.model\GetComparableProducts200ResponseComparableProductsProteinInner[]**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  |
**sugar** | **object[]** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

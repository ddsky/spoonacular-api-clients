

# ComputeGlycemicLoadRequest



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**ingredients** | **List&lt;String&gt;** |  |  |




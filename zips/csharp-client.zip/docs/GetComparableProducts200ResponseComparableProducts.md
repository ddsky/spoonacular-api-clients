# Org.OpenAPITools.Model.GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Calories** | **List<Object>** |  | 
**Likes** | **List<Object>** |  | 
**Price** | **List<Object>** |  | 
**Protein** | [**List<GetComparableProducts200ResponseComparableProductsProteinInner>**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**SpoonacularScore** | [**List<GetComparableProducts200ResponseComparableProductsProteinInner>**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**Sugar** | **List<Object>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# Spoonacular.SearchRecipesByNutrients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **Number** |  | 
**carbs** | **String** |  | 
**fat** | **String** |  | 
**id** | **Number** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 
**protein** | **String** |  | 
**title** | **String** |  | 



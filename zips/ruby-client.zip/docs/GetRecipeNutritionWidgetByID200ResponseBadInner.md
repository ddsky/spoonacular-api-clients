# OpenapiClient::GetRecipeNutritionWidgetByID200ResponseBadInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **title** | **String** |  |  |
| **amount** | **String** |  |  |
| **indented** | **Boolean** |  |  |
| **percent_of_daily_needs** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipeNutritionWidgetByID200ResponseBadInner.new(
  title: null,
  amount: null,
  indented: null,
  percent_of_daily_needs: null
)
```


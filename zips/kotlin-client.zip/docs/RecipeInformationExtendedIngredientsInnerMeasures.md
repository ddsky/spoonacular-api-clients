
# RecipeInformationExtendedIngredientsInnerMeasures

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **metric** | [**RecipeInformationExtendedIngredientsInnerMeasuresMetric**](RecipeInformationExtendedIngredientsInnerMeasuresMetric.md) |  |  |
| **us** | [**RecipeInformationExtendedIngredientsInnerMeasuresMetric**](RecipeInformationExtendedIngredientsInnerMeasuresMetric.md) |  |  |




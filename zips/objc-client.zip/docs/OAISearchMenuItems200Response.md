# OAISearchMenuItems200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menuItems** | [**OAISet&lt;OAISearchMenuItems200ResponseMenuItemsInner&gt;***](OAISearchMenuItems200ResponseMenuItemsInner.md) |  | 
**totalMenuItems** | **NSNumber*** |  | 
**type** | **NSString*** |  | 
**offset** | **NSNumber*** |  | 
**number** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



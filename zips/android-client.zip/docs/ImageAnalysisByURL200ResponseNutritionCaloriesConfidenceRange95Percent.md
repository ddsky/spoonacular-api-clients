

# ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | [**BigDecimal**](BigDecimal.md) |  | 
**max** | [**BigDecimal**](BigDecimal.md) |  | 





# SpoonacularApi.ComputeGlycemicLoadRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | **[String]** |  | 



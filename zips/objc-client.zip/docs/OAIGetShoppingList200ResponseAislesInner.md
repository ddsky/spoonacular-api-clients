# OAIGetShoppingList200ResponseAislesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **NSString*** |  | 
**items** | [**OAISet&lt;OAIGetShoppingList200ResponseAislesInnerItemsInner&gt;***](OAIGetShoppingList200ResponseAislesInnerItemsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



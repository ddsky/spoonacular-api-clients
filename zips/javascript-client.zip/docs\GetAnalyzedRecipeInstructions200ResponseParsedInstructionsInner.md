# SpoonacularApi.GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**steps** | [**[GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner]**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional] 



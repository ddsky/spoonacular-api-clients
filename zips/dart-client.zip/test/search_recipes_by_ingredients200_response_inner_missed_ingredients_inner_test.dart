//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner
void main() {
  // final instance = SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner();

  group('test SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner', () {
    // String aisle
    test('to test the property `aisle`', () async {
      // TODO
    });

    // num amount
    test('to test the property `amount`', () async {
      // TODO
    });

    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // List<String> meta (default value: const [])
    test('to test the property `meta`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String extendedName
    test('to test the property `extendedName`', () async {
      // TODO
    });

    // String original
    test('to test the property `original`', () async {
      // TODO
    });

    // String originalName
    test('to test the property `originalName`', () async {
      // TODO
    });

    // String unit
    test('to test the property `unit`', () async {
      // TODO
    });

    // String unitLong
    test('to test the property `unitLong`', () async {
      // TODO
    });

    // String unitShort
    test('to test the property `unitShort`', () async {
      // TODO
    });


  });

}

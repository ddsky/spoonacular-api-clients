
# AnalyzeRecipeRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** |  |  [optional] |
| **servings** | **kotlin.Int** |  |  [optional] |
| **ingredients** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional] |
| **instructions** | **kotlin.String** |  |  [optional] |




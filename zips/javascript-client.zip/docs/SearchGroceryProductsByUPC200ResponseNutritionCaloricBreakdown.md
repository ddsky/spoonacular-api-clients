# Spoonacular.SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentProtein** | **Number** |  | 
**percentFat** | **Number** |  | 
**percentCarbs** | **Number** |  | 





# SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**percentProtein** | **BigDecimal** |  |  |
|**percentFat** | **BigDecimal** |  |  |
|**percentCarbs** | **BigDecimal** |  |  |




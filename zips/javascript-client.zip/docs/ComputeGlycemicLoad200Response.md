# Spoonacular.ComputeGlycemicLoad200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalGlycemicLoad** | **Number** |  | 
**ingredients** | [**[ComputeGlycemicLoad200ResponseIngredientsInner]**](ComputeGlycemicLoad200ResponseIngredientsInner.md) |  | 



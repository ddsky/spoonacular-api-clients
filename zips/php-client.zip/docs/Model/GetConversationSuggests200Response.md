# # GetConversationSuggests200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggests** | [**\OpenAPI\Client\Model\GetConversationSuggests200ResponseSuggests**](GetConversationSuggests200ResponseSuggests.md) |  |
**words** | **mixed[]** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# openapi.model.GetComparableProducts200ResponseComparableProducts

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**List<ComparableProduct>**](ComparableProduct.md) |  | [default to const []]
**likes** | [**List<ComparableProduct>**](ComparableProduct.md) |  | [default to const []]
**price** | [**List<ComparableProduct>**](ComparableProduct.md) |  | [default to const []]
**protein** | [**List<ComparableProduct>**](ComparableProduct.md) |  | [default to const []]
**spoonacularScore** | [**List<ComparableProduct>**](ComparableProduct.md) |  | [default to const []]
**sugar** | [**List<ComparableProduct>**](ComparableProduct.md) |  | [default to const []]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



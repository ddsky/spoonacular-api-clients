# spoonacular.Model.AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Number** | **decimal** |  | 
**Step** | **string** |  | 
**Ingredients** | [**List&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**Equipment** | [**List&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


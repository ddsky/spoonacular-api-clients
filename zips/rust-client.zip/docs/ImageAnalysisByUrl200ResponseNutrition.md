# ImageAnalysisByUrl200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes_used** | **i32** |  | 
**calories** | [**crate::models::ImageAnalysisByUrl200ResponseNutritionCalories**](imageAnalysisByURL_200_response_nutrition_calories.md) |  | 
**fat** | [**crate::models::ImageAnalysisByUrl200ResponseNutritionCalories**](imageAnalysisByURL_200_response_nutrition_calories.md) |  | 
**protein** | [**crate::models::ImageAnalysisByUrl200ResponseNutritionCalories**](imageAnalysisByURL_200_response_nutrition_calories.md) |  | 
**carbs** | [**crate::models::ImageAnalysisByUrl200ResponseNutritionCalories**](imageAnalysisByURL_200_response_nutrition_calories.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



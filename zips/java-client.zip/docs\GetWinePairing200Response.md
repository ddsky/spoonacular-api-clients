

# GetWinePairing200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**pairedWines** | **List&lt;String&gt;** |  |  |
|**pairingText** | **String** |  |  |
|**productMatches** | [**Set&lt;GetWinePairing200ResponseProductMatchesInner&gt;**](GetWinePairing200ResponseProductMatchesInner.md) |  |  |




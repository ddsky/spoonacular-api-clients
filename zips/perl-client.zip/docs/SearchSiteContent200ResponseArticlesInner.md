# WWW::OpenAPIClient::Object::SearchSiteContent200ResponseArticlesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchSiteContent200ResponseArticlesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_points** | [**ARRAY[AnyType]**](AnyType.md) |  | [optional] 
**image** | **string** |  | 
**link** | **string** |  | 
**name** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



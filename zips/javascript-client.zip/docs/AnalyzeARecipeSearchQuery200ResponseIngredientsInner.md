# SpoonacularApi.AnalyzeARecipeSearchQuery200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | 
**include** | **Boolean** |  | 
**name** | **String** |  | 



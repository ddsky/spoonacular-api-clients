
# TalkToChatbot200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answerText** | **kotlin.String** |  | 
**media** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) |  | 




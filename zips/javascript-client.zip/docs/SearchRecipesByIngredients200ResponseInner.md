# SpoonacularApi.SearchRecipesByIngredients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 
**likes** | **Number** |  | 
**missedIngredientCount** | **Number** |  | 
**missedIngredients** | [**[SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner]**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 
**title** | **String** |  | 
**unusedIngredients** | **[Object]** |  | 
**usedIngredientCount** | **Number** |  | 
**usedIngredients** | [**[SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner]**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 



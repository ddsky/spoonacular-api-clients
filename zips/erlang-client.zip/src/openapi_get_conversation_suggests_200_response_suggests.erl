-module(openapi_get_conversation_suggests_200_response_suggests).

-export([encode/1]).

-export_type([openapi_get_conversation_suggests_200_response_suggests/0]).

-type openapi_get_conversation_suggests_200_response_suggests() ::
    #{ '_' := openapi_set:openapi_set()
     }.

encode(#{ '_' := 
        }) ->
    #{ '_' => 
     }.

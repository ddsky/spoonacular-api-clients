# SpoonacularApi.ClassifyCuisine200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cuisine** | **String** |  | 
**cuisines** | **[String]** |  | 
**confidence** | **Number** |  | 



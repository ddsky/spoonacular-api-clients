
# GetMealPlanWeek200ResponseDaysInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **date** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **day** | **kotlin.String** |  |  |
| **nutritionSummary** | [**GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  |  [optional] |
| **nutritionSummaryBreakfast** | [**GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  |  [optional] |
| **nutritionSummaryLunch** | [**GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  |  [optional] |
| **nutritionSummaryDinner** | [**GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  |  [optional] |
| **items** | [**kotlin.collections.Set&lt;GetMealPlanWeek200ResponseDaysInnerItemsInner&gt;**](GetMealPlanWeek200ResponseDaysInnerItemsInner.md) |  |  [optional] |




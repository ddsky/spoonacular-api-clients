# OpenapiClient::AnalyzeRecipeInstructions200ResponseParsedInstructionsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **steps** | [**Array&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AnalyzeRecipeInstructions200ResponseParsedInstructionsInner.new(
  name: null,
  steps: null
)
```


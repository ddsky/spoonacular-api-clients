

# AnalyzeRecipeRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **String** | The input language, either \&quot;en\&quot; or \&quot;de\&quot;. |  [optional]
**includeNutrition** | **Boolean** | Whether nutrition data should be added to correctly parsed ingredients. |  [optional]
**includeTaste** | **Boolean** | Whether taste data should be added to correctly parsed ingredients. |  [optional]





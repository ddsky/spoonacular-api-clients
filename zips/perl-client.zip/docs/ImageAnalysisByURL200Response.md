# WWW::OpenAPIClient::Object::ImageAnalysisByURL200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ImageAnalysisByURL200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition** | [**ImageAnalysisByURL200ResponseNutrition**](ImageAnalysisByURL200ResponseNutrition.md) |  | 
**category** | [**ImageAnalysisByURL200ResponseCategory**](ImageAnalysisByURL200ResponseCategory.md) |  | 
**recipes** | [**ARRAY[ImageAnalysisByURL200ResponseRecipesInner]**](ImageAnalysisByURL200ResponseRecipesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



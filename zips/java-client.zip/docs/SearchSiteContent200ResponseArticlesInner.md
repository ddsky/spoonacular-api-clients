

# SearchSiteContent200ResponseArticlesInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**dataPoints** | **List&lt;Object&gt;** |  |  [optional] |
|**image** | **String** |  |  |
|**link** | **String** |  |  |
|**name** | **String** |  |  |




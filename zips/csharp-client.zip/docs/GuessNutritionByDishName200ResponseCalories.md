# Org.OpenAPITools.Model.GuessNutritionByDishName200ResponseCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ConfidenceRange95Percent** | [**GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent**](GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.md) |  | 
**StandardDeviation** | **decimal?** |  | 
**Unit** | **string** |  | 
**Value** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# Org.OpenAPITools.Model.SearchCustomFoods200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CustomFoods** | [**List<SearchCustomFoods200ResponseCustomFoodsInner>**](SearchCustomFoods200ResponseCustomFoodsInner.md) |  | 
**Type** | **string** |  | 
**Offset** | **int?** |  | 
**Number** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


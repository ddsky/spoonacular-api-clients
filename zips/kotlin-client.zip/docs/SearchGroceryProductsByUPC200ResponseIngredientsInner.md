
# SearchGroceryProductsByUPC200ResponseIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  | 
**description** | [**kotlin.Any**](.md) |  |  [optional]
**safetyLevel** | [**kotlin.Any**](.md) |  |  [optional]




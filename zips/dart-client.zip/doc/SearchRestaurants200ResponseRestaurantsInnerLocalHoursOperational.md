# openapi.model.SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monday** | **String** |  | [optional] 
**tuesday** | **String** |  | [optional] 
**wednesday** | **String** |  | [optional] 
**thursday** | **String** |  | [optional] 
**friday** | **String** |  | [optional] 
**saturday** | **String** |  | [optional] 
**sunday** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



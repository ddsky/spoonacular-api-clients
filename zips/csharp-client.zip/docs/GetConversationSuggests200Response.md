# spoonacular.Model.GetConversationSuggests200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Suggests** | [**GetConversationSuggests200ResponseSuggests**](GetConversationSuggests200ResponseSuggests.md) |  | 
**Words** | **List&lt;Object&gt;** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


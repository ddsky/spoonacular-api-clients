# OpenapiClient::GenerateMealPlan200ResponseNutrients

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **calories** | **Float** |  |  |
| **carbohydrates** | **Float** |  |  |
| **fat** | **Float** |  |  |
| **protein** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GenerateMealPlan200ResponseNutrients.new(
  calories: null,
  carbohydrates: null,
  fat: null,
  protein: null
)
```


# Org.OpenAPITools.Model.AnalyzeARecipeSearchQuery200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dishes** | [**List<AnalyzeARecipeSearchQuery200ResponseDishesInner>**](AnalyzeARecipeSearchQuery200ResponseDishesInner.md) |  | 
**Ingredients** | [**List<AnalyzeARecipeSearchQuery200ResponseIngredientsInner>**](AnalyzeARecipeSearchQuery200ResponseIngredientsInner.md) |  | 
**Cuisines** | **List<string>** |  | 
**Modifiers** | **List<string>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


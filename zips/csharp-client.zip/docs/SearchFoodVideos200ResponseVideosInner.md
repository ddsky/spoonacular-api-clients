# spoonacular.Model.SearchFoodVideos200ResponseVideosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** |  | 
**Length** | **int** |  | 
**Rating** | **decimal** |  | 
**ShortTitle** | **string** |  | 
**Thumbnail** | **string** |  | 
**Views** | **int** |  | 
**YouTubeId** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# spoonacular.Model.GetAnalyzedRecipeInstructions200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | 
**Steps** | [**List&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


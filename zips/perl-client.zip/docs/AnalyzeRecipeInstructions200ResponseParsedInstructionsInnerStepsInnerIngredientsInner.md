# WWW::OpenAPIClient::Object::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **string** |  | 
**localized_name** | **string** |  | 
**image** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# GetRecipeEquipmentById200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**equipment** | [**Vec<models::GetRecipeEquipmentById200ResponseEquipmentInner>**](getRecipeEquipmentByID_200_response_equipment_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



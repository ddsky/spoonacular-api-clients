

# GetMealPlanTemplate200ResponseDaysInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**slot** | **Integer** |  | 
**position** | **Integer** |  | 
**type** | **String** |  | 
**value** | [**GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue**](GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.md) |  |  [optional]





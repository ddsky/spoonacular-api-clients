# Org.OpenAPITools.Model.SearchRecipesByIngredients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | 
**Image** | **string** |  | 
**ImageType** | **string** |  | 
**Likes** | **int?** |  | 
**MissedIngredientCount** | **int?** |  | 
**MissedIngredients** | [**List<SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner>**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 
**Title** | **string** |  | 
**UnusedIngredients** | **List<Object>** |  | 
**UsedIngredientCount** | **decimal?** |  | 
**UsedIngredients** | [**List<SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner>**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# WWW::OpenAPIClient::Object::GetWinePairing200ResponseProductMatchesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetWinePairing200ResponseProductMatchesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **string** |  | 
**average_rating** | **double** |  | 
**description** | [**AnyType**](.md) |  | [optional] 
**image_url** | **string** |  | 
**link** | **string** |  | 
**price** | **string** |  | 
**rating_count** | **int** |  | 
**score** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# spoonacular.Model.GetConversationSuggests200ResponseSuggests

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_** | [**List&lt;GetConversationSuggests200ResponseSuggestsInner&gt;**](GetConversationSuggests200ResponseSuggestsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


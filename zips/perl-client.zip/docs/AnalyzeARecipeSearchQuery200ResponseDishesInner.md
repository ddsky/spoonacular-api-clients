# WWW::OpenAPIClient::Object::AnalyzeARecipeSearchQuery200ResponseDishesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AnalyzeARecipeSearchQuery200ResponseDishesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **string** |  | 
**name** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# SummarizeRecipe200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**summary** | **String** |  | 
**title** | **String** |  | 





# GetWineRecommendation200ResponseRecommendedWinesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** |  | 
**title** | **String** |  | 
**average_rating** | **f32** |  | 
**description** | **String** |  | 
**image_url** | **String** |  | 
**link** | **String** |  | 
**price** | **String** |  | 
**rating_count** | **i32** |  | 
**score** | **f32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



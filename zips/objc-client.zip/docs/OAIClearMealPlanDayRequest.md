# OAIClearMealPlanDayRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **NSString*** | The username. | 
**date** | **NSString*** | The date in the format yyyy-mm-dd. | 
**hash** | **NSString*** | The private hash for the username. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



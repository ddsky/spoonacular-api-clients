# Spoonacular.GetWinePairing200ResponseProductMatchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**averageRating** | **Number** |  | 
**description** | **String** |  | [optional] 
**imageUrl** | **String** |  | 
**link** | **String** |  | 
**price** | **String** |  | 
**ratingCount** | **Number** |  | 
**score** | **Number** |  | 



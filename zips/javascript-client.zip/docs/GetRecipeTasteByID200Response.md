# SpoonacularApi.GetRecipeTasteByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | **Number** |  | 
**saltiness** | **Number** |  | 
**sourness** | **Number** |  | 
**bitterness** | **Number** |  | 
**savoriness** | **Number** |  | 
**fattiness** | **Number** |  | 
**spiciness** | **Number** |  | 



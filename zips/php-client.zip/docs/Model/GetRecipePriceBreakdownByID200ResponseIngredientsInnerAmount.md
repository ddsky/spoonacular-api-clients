# # GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**\com.spoonacular.client\com.spoonacular.client.model\GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  |
**us** | [**\com.spoonacular.client\com.spoonacular.client.model\GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

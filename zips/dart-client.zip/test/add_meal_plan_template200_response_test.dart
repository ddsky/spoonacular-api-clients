//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for AddMealPlanTemplate200Response
void main() {
  // final instance = AddMealPlanTemplate200Response();

  group('test AddMealPlanTemplate200Response', () {
    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // Set<AddMealPlanTemplate200ResponseItemsInner> items (default value: const {})
    test('to test the property `items`', () async {
      // TODO
    });

    // bool publishAsPublic
    test('to test the property `publishAsPublic`', () async {
      // TODO
    });


  });

}

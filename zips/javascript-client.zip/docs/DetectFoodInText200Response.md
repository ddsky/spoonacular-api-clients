# Spoonacular.DetectFoodInText200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotations** | [**[DetectFoodInText200ResponseAnnotationsInner]**](DetectFoodInText200ResponseAnnotationsInner.md) |  | 




# SearchAllFood200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **query** | **kotlin.String** |  |  |
| **totalResults** | **kotlin.Int** |  |  |
| **limit** | **kotlin.Int** |  |  |
| **offset** | **kotlin.Int** |  |  |
| **searchResults** | [**kotlin.collections.Set&lt;SearchAllFood200ResponseSearchResultsInner&gt;**](SearchAllFood200ResponseSearchResultsInner.md) |  |  |




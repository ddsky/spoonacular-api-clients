# WWW::OpenAPIClient::Object::SearchAllFood200ResponseSearchResultsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchAllFood200ResponseSearchResultsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**total_results** | **int** |  | 
**results** | [**ARRAY[SearchResult]**](SearchResult.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# MapIngredientsToGroceryProducts200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** |  | 
**original_name** | **String** |  | 
**ingredient_image** | **String** |  | 
**meta** | **Vec<String>** |  | 
**products** | [**Vec<models::MapIngredientsToGroceryProducts200ResponseInnerProductsInner>**](mapIngredientsToGroceryProducts_200_response_inner_products_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SpoonacularApi.GenerateMealPlan200ResponseNutrients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **Number** |  | 
**carbohydrates** | **Number** |  | 
**fat** | **Number** |  | 
**protein** | **Number** |  | 



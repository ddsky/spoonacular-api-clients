# WWW::OpenAPIClient::Object::SearchRestaurants200ResponseRestaurantsInnerLocalHours

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRestaurants200ResponseRestaurantsInnerLocalHours;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operational** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**delivery** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**pickup** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**dine_in** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



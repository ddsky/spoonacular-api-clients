# # RecipeInformationExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **string** |  |
**amount** | **float** |  |
**consistency** | **string** |  |
**id** | **int** |  |
**image** | **string** |  |
**measures** | [**\OpenAPI\Client\Model\RecipeInformationExtendedIngredientsInnerMeasures**](RecipeInformationExtendedIngredientsInnerMeasures.md) |  | [optional]
**meta** | **string[]** |  | [optional]
**name** | **string** |  |
**original** | **string** |  |
**original_name** | **string** |  |
**unit** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

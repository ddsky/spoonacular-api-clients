# WWW::OpenAPIClient::Object::ConnectUserRequest

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ConnectUserRequest;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** |  | 
**first_name** | **string** |  | 
**last_name** | **string** |  | 
**email** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



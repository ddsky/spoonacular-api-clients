# WWW::OpenAPIClient::Object::GetShoppingList200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetShoppingList200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**ARRAY[GetShoppingList200ResponseAislesInner]**](GetShoppingList200ResponseAislesInner.md) |  | 
**cost** | **double** |  | 
**start_date** | **double** |  | 
**end_date** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



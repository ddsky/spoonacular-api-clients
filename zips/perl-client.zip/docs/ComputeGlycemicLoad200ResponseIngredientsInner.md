# WWW::OpenAPIClient::Object::ComputeGlycemicLoad200ResponseIngredientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ComputeGlycemicLoad200ResponseIngredientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**original** | **string** |  | 
**glycemic_index** | **double** |  | 
**glycemic_load** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OpenapiClient::GetAnalyzedRecipeInstructions200ResponseIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetAnalyzedRecipeInstructions200ResponseIngredientsInner.new(
  id: null,
  name: null
)
```


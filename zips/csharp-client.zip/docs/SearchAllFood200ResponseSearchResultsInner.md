# spoonacular.Model.SearchAllFood200ResponseSearchResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | 
**TotalResults** | **int** |  | 
**Results** | [**List&lt;SearchAllFood200ResponseSearchResultsInnerResultsInner&gt;**](SearchAllFood200ResponseSearchResultsInnerResultsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SearchAllFood200ResponseSearchResultsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  |
| **totalResults** | **kotlin.Int** |  |  |
| **results** | [**kotlin.collections.Set&lt;SearchAllFood200ResponseSearchResultsInnerResultsInner&gt;**](SearchAllFood200ResponseSearchResultsInnerResultsInner.md) |  |  [optional] |




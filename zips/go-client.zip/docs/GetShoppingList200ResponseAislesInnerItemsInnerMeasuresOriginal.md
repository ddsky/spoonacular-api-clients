# GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | **float32** |  | 
**Unit** | **string** |  | 

## Methods

### NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal

`func NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal(amount float32, unit string, ) *GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal`

NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal instantiates a new GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginalWithDefaults

`func NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginalWithDefaults() *GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal`

NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginalWithDefaults instantiates a new GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAmount

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal) GetAmount() float32`

GetAmount returns the Amount field if non-nil, zero value otherwise.

### GetAmountOk

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal) GetAmountOk() (*float32, bool)`

GetAmountOk returns a tuple with the Amount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAmount

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal) SetAmount(v float32)`

SetAmount sets Amount field to given value.


### GetUnit

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal) GetUnit() string`

GetUnit returns the Unit field if non-nil, zero value otherwise.

### GetUnitOk

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal) GetUnitOk() (*string, bool)`

GetUnitOk returns a tuple with the Unit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnit

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal) SetUnit(v string)`

SetUnit sets Unit field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



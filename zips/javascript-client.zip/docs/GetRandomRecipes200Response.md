# SpoonacularApi.GetRandomRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes** | [**[GetRandomRecipes200ResponseRecipesInner]**](GetRandomRecipes200ResponseRecipesInner.md) |  | 



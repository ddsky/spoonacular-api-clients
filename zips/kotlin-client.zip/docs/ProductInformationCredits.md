
# ProductInformationCredits

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **text** | **kotlin.String** |  |  [optional] |
| **link** | **kotlin.String** |  |  [optional] |
| **image** | **kotlin.String** |  |  [optional] |
| **imageLink** | **kotlin.String** |  |  [optional] |




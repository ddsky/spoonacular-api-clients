# SpoonacularApi.IngredientInformationEstimatedCost

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Number** |  | 
**unit** | **String** |  | 



# GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  | 
**Us** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  | 

## Methods

### NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount

`func NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount(metric GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric, us GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric, ) *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount`

NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount instantiates a new GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountWithDefaults

`func NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountWithDefaults() *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount`

NewGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountWithDefaults instantiates a new GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetric

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount) GetMetric() GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric`

GetMetric returns the Metric field if non-nil, zero value otherwise.

### GetMetricOk

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount) GetMetricOk() (*GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric, bool)`

GetMetricOk returns a tuple with the Metric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetric

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount) SetMetric(v GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric)`

SetMetric sets Metric field to given value.


### GetUs

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount) GetUs() GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric`

GetUs returns the Us field if non-nil, zero value otherwise.

### GetUsOk

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount) GetUsOk() (*GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric, bool)`

GetUsOk returns a tuple with the Us field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUs

`func (o *GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount) SetUs(v GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric)`

SetUs sets Us field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



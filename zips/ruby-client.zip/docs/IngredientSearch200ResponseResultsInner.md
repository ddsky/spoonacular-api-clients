# OpenapiClient::IngredientSearch200ResponseResultsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **name** | **String** |  |  |
| **image** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::IngredientSearch200ResponseResultsInner.new(
  id: null,
  name: null,
  image: null
)
```


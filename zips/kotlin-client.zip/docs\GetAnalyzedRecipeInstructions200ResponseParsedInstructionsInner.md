
# GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  | 
**steps** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  |  [optional]




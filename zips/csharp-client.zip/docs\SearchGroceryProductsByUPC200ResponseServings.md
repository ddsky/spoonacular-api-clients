# Org.OpenAPITools.Model.SearchGroceryProductsByUPC200ResponseServings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Number** | **decimal?** |  | 
**Size** | **decimal?** |  | 
**Unit** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


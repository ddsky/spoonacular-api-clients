# GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**amount** | **float** |  | 
**unit** | **str** |  | 
**percent_daily_needs** | **float** |  | 

## Example

```python
from spoonacular.models.get_meal_plan_week200_response_days_inner_nutrition_summary_nutrients_inner import GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner from a JSON string
get_meal_plan_week200_response_days_inner_nutrition_summary_nutrients_inner_instance = GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.from_json(json)
# print the JSON string representation of the object
print GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.to_json()

# convert the object into a dict
get_meal_plan_week200_response_days_inner_nutrition_summary_nutrients_inner_dict = get_meal_plan_week200_response_days_inner_nutrition_summary_nutrients_inner_instance.to_dict()
# create an instance of GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner from a dict
get_meal_plan_week200_response_days_inner_nutrition_summary_nutrients_inner_form_dict = get_meal_plan_week200_response_days_inner_nutrition_summary_nutrients_inner.from_dict(get_meal_plan_week200_response_days_inner_nutrition_summary_nutrients_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



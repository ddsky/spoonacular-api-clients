# Org.OpenAPITools.Model.TalkToChatbot200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnswerText** | **string** |  | 
**Media** | **List<Object>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


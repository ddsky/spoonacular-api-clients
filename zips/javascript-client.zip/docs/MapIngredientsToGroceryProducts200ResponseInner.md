# Spoonacular.MapIngredientsToGroceryProducts200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** |  | 
**originalName** | **String** |  | 
**ingredientImage** | **String** |  | 
**meta** | **[String]** |  | 
**products** | [**[MapIngredientsToGroceryProducts200ResponseInnerProductsInner]**](MapIngredientsToGroceryProducts200ResponseInnerProductsInner.md) |  | 



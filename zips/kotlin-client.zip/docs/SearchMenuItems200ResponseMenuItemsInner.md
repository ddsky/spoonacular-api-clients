
# SearchMenuItems200ResponseMenuItemsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** |  |  |
| **title** | **kotlin.String** |  |  |
| **restaurantChain** | **kotlin.String** |  |  |
| **image** | **kotlin.String** |  |  |
| **imageType** | **kotlin.String** |  |  |
| **servings** | [**SearchGroceryProductsByUPC200ResponseServings**](SearchGroceryProductsByUPC200ResponseServings.md) |  |  [optional] |






# GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**Set&lt;GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner&gt;**](GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.md) |  | 





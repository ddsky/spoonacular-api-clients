
# GetRecipeInformation200ResponseWinePairingProductMatchesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**title** | **kotlin.String** |  | 
**description** | **kotlin.String** |  | 
**price** | **kotlin.String** |  | 
**imageUrl** | **kotlin.String** |  | 
**averageRating** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**ratingCount** | **kotlin.Int** |  | 
**score** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**link** | **kotlin.String** |  | 




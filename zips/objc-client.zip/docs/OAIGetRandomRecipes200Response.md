# OAIGetRandomRecipes200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes** | [**OAISet&lt;OAIGetRandomRecipes200ResponseRecipesInner&gt;***](OAIGetRandomRecipes200ResponseRecipesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



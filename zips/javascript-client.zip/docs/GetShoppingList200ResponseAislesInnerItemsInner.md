# SpoonacularApi.GetShoppingList200ResponseAislesInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | 
**measures** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasures**](GetShoppingList200ResponseAislesInnerItemsInnerMeasures.md) |  | [optional] 
**pantryItem** | **Boolean** |  | 
**aisle** | **String** |  | 
**cost** | **Number** |  | 
**ingredientId** | **Number** |  | 



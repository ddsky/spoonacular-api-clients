# SearchFoodVideos200ResponseVideosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | 
**length** | **i32** |  | 
**rating** | **f64** |  | 
**short_title** | **String** |  | 
**thumbnail** | **String** |  | 
**views** | **i32** |  | 
**you_tube_id** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# GuessNutritionByDishName200ResponseCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confidence_range95_percent** | [**models::GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent**](guessNutritionByDishName_200_response_calories_confidenceRange95Percent.md) |  | 
**standard_deviation** | **f64** |  | 
**unit** | **String** |  | 
**value** | **f64** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



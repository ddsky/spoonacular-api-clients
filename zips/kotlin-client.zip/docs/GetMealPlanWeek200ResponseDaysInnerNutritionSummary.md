
# GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**kotlin.collections.Set&lt;GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner&gt;**](GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.md) |  | 




//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ParseIngredients200ResponseInnerEstimatedCost
void main() {
  // final instance = ParseIngredients200ResponseInnerEstimatedCost();

  group('test ParseIngredients200ResponseInnerEstimatedCost', () {
    // num value
    test('to test the property `value`', () async {
      // TODO
    });

    // String unit
    test('to test the property `unit`', () async {
      // TODO
    });


  });

}

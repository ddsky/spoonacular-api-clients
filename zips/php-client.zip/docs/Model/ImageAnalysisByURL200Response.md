# # ImageAnalysisByURL200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition** | [**\OpenAPI\Client\Model\ImageAnalysisByURL200ResponseNutrition**](ImageAnalysisByURL200ResponseNutrition.md) |  |
**category** | [**\OpenAPI\Client\Model\ImageAnalysisByURL200ResponseCategory**](ImageAnalysisByURL200ResponseCategory.md) |  |
**recipes** | [**\OpenAPI\Client\Model\ImageAnalysisByURL200ResponseRecipesInner[]**](ImageAnalysisByURL200ResponseRecipesInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

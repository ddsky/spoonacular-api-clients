# AddToMealPlanRequestValueIngredientsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 

## Example

```python
from spoonacular.models.add_to_meal_plan_request_value_ingredients_inner import AddToMealPlanRequestValueIngredientsInner

# TODO update the JSON string below
json = "{}"
# create an instance of AddToMealPlanRequestValueIngredientsInner from a JSON string
add_to_meal_plan_request_value_ingredients_inner_instance = AddToMealPlanRequestValueIngredientsInner.from_json(json)
# print the JSON string representation of the object
print(AddToMealPlanRequestValueIngredientsInner.to_json())

# convert the object into a dict
add_to_meal_plan_request_value_ingredients_inner_dict = add_to_meal_plan_request_value_ingredients_inner_instance.to_dict()
# create an instance of AddToMealPlanRequestValueIngredientsInner from a dict
add_to_meal_plan_request_value_ingredients_inner_from_dict = AddToMealPlanRequestValueIngredientsInner.from_dict(add_to_meal_plan_request_value_ingredients_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



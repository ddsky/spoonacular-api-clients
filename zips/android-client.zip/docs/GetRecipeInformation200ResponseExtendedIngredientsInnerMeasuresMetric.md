

# GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**BigDecimal**](BigDecimal.md) |  | 
**unitLong** | **String** |  | 
**unitShort** | **String** |  | 





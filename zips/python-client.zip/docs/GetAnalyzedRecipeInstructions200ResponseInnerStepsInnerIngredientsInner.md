# GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **str** |  | 
**localized_name** | **str** |  | 
**image** | **str** |  | 

## Example

```python
from spoonacular.models.get_analyzed_recipe_instructions200_response_inner_steps_inner_ingredients_inner import GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner from a JSON string
get_analyzed_recipe_instructions200_response_inner_steps_inner_ingredients_inner_instance = GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.from_json(json)
# print the JSON string representation of the object
print(GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.to_json())

# convert the object into a dict
get_analyzed_recipe_instructions200_response_inner_steps_inner_ingredients_inner_dict = get_analyzed_recipe_instructions200_response_inner_steps_inner_ingredients_inner_instance.to_dict()
# create an instance of GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner from a dict
get_analyzed_recipe_instructions200_response_inner_steps_inner_ingredients_inner_from_dict = GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.from_dict(get_analyzed_recipe_instructions200_response_inner_steps_inner_ingredients_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



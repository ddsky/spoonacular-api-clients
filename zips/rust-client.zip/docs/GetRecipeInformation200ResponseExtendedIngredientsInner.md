# GetRecipeInformation200ResponseExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | **f32** |  | 
**consitency** | **String** |  | 
**id** | **i32** |  | 
**image** | **String** |  | 
**measures** | Option<[**crate::models::GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures**](getRecipeInformation_200_response_extendedIngredients_inner_measures.md)> |  | [optional]
**meta** | Option<**Vec<String>**> |  | [optional]
**name** | **String** |  | 
**original** | **String** |  | 
**original_name** | **String** |  | 
**unit** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



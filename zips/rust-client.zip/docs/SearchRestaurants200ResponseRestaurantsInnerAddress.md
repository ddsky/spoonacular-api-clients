# SearchRestaurants200ResponseRestaurantsInnerAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**street_addr** | Option<**String**> |  | [optional]
**city** | Option<**String**> |  | [optional]
**state** | Option<**String**> |  | [optional]
**zipcode** | Option<**String**> |  | [optional]
**country** | Option<**String**> |  | [optional]
**lat** | Option<**f32**> |  | [optional]
**lon** | Option<**f32**> |  | [optional]
**street_addr_2** | Option<**String**> |  | [optional]
**latitude** | Option<**f32**> |  | [optional]
**longitude** | Option<**f32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



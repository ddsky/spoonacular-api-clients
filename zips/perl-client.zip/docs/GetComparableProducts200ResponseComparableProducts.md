# WWW::OpenAPIClient::Object::GetComparableProducts200ResponseComparableProducts

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetComparableProducts200ResponseComparableProducts;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **ARRAY[object]** |  | 
**likes** | **ARRAY[object]** |  | 
**price** | **ARRAY[object]** |  | 
**protein** | [**ARRAY[GetComparableProducts200ResponseComparableProductsProteinInner]**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**spoonacular_score** | [**ARRAY[GetComparableProducts200ResponseComparableProductsProteinInner]**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**sugar** | **ARRAY[object]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SpoonacularApi.GetWineRecommendation200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommendedWines** | [**[GetWineRecommendation200ResponseRecommendedWinesInner]**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  | 
**totalFound** | **Number** |  | 



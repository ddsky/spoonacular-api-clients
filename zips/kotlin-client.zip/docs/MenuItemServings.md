
# MenuItemServings

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **number** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **propertySize** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **unit** | **kotlin.String** |  |  |




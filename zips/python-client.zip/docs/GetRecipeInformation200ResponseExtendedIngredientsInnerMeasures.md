# GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.md) |  | 
**us** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.md) |  | 

## Example

```python
from spoonacular.models.get_recipe_information200_response_extended_ingredients_inner_measures import GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures

# TODO update the JSON string below
json = "{}"
# create an instance of GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures from a JSON string
get_recipe_information200_response_extended_ingredients_inner_measures_instance = GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures.from_json(json)
# print the JSON string representation of the object
print GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures.to_json()

# convert the object into a dict
get_recipe_information200_response_extended_ingredients_inner_measures_dict = get_recipe_information200_response_extended_ingredients_inner_measures_instance.to_dict()
# create an instance of GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures from a dict
get_recipe_information200_response_extended_ingredients_inner_measures_form_dict = get_recipe_information200_response_extended_ingredients_inner_measures.from_dict(get_recipe_information200_response_extended_ingredients_inner_measures_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



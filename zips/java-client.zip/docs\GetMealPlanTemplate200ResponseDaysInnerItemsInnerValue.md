

# GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **BigDecimal** |  |  |
|**title** | **String** |  |  |
|**imageType** | **String** |  |  |




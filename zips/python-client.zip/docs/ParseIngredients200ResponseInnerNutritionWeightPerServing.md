# ParseIngredients200ResponseInnerNutritionWeightPerServing


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **float** |  | 
**unit** | **str** |  | 

## Example

```python
from spoonacular.models.parse_ingredients200_response_inner_nutrition_weight_per_serving import ParseIngredients200ResponseInnerNutritionWeightPerServing

# TODO update the JSON string below
json = "{}"
# create an instance of ParseIngredients200ResponseInnerNutritionWeightPerServing from a JSON string
parse_ingredients200_response_inner_nutrition_weight_per_serving_instance = ParseIngredients200ResponseInnerNutritionWeightPerServing.from_json(json)
# print the JSON string representation of the object
print ParseIngredients200ResponseInnerNutritionWeightPerServing.to_json()

# convert the object into a dict
parse_ingredients200_response_inner_nutrition_weight_per_serving_dict = parse_ingredients200_response_inner_nutrition_weight_per_serving_instance.to_dict()
# create an instance of ParseIngredients200ResponseInnerNutritionWeightPerServing from a dict
parse_ingredients200_response_inner_nutrition_weight_per_serving_form_dict = parse_ingredients200_response_inner_nutrition_weight_per_serving.from_dict(parse_ingredients200_response_inner_nutrition_weight_per_serving_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



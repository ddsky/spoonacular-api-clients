# SpoonacularApi.GetRecipeEquipmentByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**equipment** | [**[GetRecipeEquipmentByID200ResponseEquipmentInner]**](GetRecipeEquipmentByID200ResponseEquipmentInner.md) |  | 



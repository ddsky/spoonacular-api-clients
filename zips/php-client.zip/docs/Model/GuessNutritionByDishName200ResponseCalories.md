# # GuessNutritionByDishName200ResponseCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confidence_range95_percent** | [**\com.spoonacular.client\com.spoonacular.client.model\GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent**](GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.md) |  |
**standard_deviation** | **float** |  |
**unit** | **string** |  |
**value** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

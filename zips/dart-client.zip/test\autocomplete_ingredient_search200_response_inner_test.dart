//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for AutocompleteIngredientSearch200ResponseInner
void main() {
  // final instance = AutocompleteIngredientSearch200ResponseInner();

  group('test AutocompleteIngredientSearch200ResponseInner', () {
    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String aisle
    test('to test the property `aisle`', () async {
      // TODO
    });

    // List<String> possibleUnits (default value: const [])
    test('to test the property `possibleUnits`', () async {
      // TODO
    });


  });

}

# SpoonacularApi.SearchGroceryProductsByUPC200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**[SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner]**](SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner.md) |  | 
**caloricBreakdown** | [**SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown**](SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown.md) |  | 



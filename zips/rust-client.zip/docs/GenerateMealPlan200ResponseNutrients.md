# GenerateMealPlan200ResponseNutrients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **f64** |  | 
**carbohydrates** | **f64** |  | 
**fat** | **f64** |  | 
**protein** | **f64** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Spoonacular.ImageAnalysisByURL200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition** | [**ImageAnalysisByURL200ResponseNutrition**](ImageAnalysisByURL200ResponseNutrition.md) |  | 
**category** | [**ImageAnalysisByURL200ResponseCategory**](ImageAnalysisByURL200ResponseCategory.md) |  | 
**recipes** | [**[ImageAnalysisByURL200ResponseRecipesInner]**](ImageAnalysisByURL200ResponseRecipesInner.md) |  | 



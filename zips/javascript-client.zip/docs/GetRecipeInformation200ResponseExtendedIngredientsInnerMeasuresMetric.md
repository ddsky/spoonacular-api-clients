# SpoonacularApi.GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | 
**unitLong** | **String** |  | 
**unitShort** | **String** |  | 



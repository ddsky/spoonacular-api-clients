# GetComparableProducts200ResponseComparableProductsProteinInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**difference** | **float** |  | 
**id** | **int** |  | 
**image** | **str** |  | 
**title** | **str** |  | 

## Example

```python
from spoonacular.models.get_comparable_products200_response_comparable_products_protein_inner import GetComparableProducts200ResponseComparableProductsProteinInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetComparableProducts200ResponseComparableProductsProteinInner from a JSON string
get_comparable_products200_response_comparable_products_protein_inner_instance = GetComparableProducts200ResponseComparableProductsProteinInner.from_json(json)
# print the JSON string representation of the object
print(GetComparableProducts200ResponseComparableProductsProteinInner.to_json())

# convert the object into a dict
get_comparable_products200_response_comparable_products_protein_inner_dict = get_comparable_products200_response_comparable_products_protein_inner_instance.to_dict()
# create an instance of GetComparableProducts200ResponseComparableProductsProteinInner from a dict
get_comparable_products200_response_comparable_products_protein_inner_from_dict = GetComparableProducts200ResponseComparableProductsProteinInner.from_dict(get_comparable_products200_response_comparable_products_protein_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



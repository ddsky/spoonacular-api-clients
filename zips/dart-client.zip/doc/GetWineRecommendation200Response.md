# openapi.model.GetWineRecommendation200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommendedWines** | [**Set<GetWineRecommendation200ResponseRecommendedWinesInner>**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  | [default to const {}]
**totalFound** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# GetRecipePriceBreakdownByID200ResponseIngredientsInner


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **str** |  | 
**name** | **str** |  | 
**price** | **float** |  | 
**amount** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



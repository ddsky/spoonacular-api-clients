# Org.OpenAPITools.Model.DeleteFromMealPlanRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Username** | **string** | The username. | 
**Id** | **decimal?** | The shopping list item id. | 
**Hash** | **string** | The private hash for the username. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


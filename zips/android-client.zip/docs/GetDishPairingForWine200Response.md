

# GetDishPairingForWine200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairings** | **List&lt;String&gt;** |  | 
**text** | **String** |  | 





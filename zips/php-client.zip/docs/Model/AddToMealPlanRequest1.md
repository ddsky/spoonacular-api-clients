# # AddToMealPlanRequest1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **float** |  |
**slot** | **int** |  |
**position** | **int** |  |
**type** | **string** |  |
**value** | [**\OpenAPI\Client\Model\AddToMealPlanRequest1Value**](AddToMealPlanRequest1Value.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

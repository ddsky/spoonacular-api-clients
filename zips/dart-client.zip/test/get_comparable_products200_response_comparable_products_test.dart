//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GetComparableProducts200ResponseComparableProducts
void main() {
  // final instance = GetComparableProducts200ResponseComparableProducts();

  group('test GetComparableProducts200ResponseComparableProducts', () {
    // List<ComparableProduct> calories (default value: const [])
    test('to test the property `calories`', () async {
      // TODO
    });

    // List<ComparableProduct> likes (default value: const [])
    test('to test the property `likes`', () async {
      // TODO
    });

    // List<ComparableProduct> price (default value: const [])
    test('to test the property `price`', () async {
      // TODO
    });

    // List<ComparableProduct> protein (default value: const [])
    test('to test the property `protein`', () async {
      // TODO
    });

    // List<ComparableProduct> spoonacularScore (default value: const [])
    test('to test the property `spoonacularScore`', () async {
      // TODO
    });

    // List<ComparableProduct> sugar (default value: const [])
    test('to test the property `sugar`', () async {
      // TODO
    });


  });

}

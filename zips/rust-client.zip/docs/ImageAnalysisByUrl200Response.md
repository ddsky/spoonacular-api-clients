# ImageAnalysisByUrl200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition** | [**crate::models::ImageAnalysisByUrl200ResponseNutrition**](imageAnalysisByURL_200_response_nutrition.md) |  | 
**category** | [**crate::models::ImageAnalysisByUrl200ResponseCategory**](imageAnalysisByURL_200_response_category.md) |  | 
**recipes** | [**Vec<crate::models::ImageAnalysisByUrl200ResponseRecipesInner>**](imageAnalysisByURL_200_response_recipes_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OpenapiClient::GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **nutrients** | [**Array&lt;GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner&gt;**](GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetMealPlanWeek200ResponseDaysInnerNutritionSummary.new(
  nutrients: null
)
```




# AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **BigDecimal** |  |  |
|**name** | **String** |  |  |
|**localizedName** | **String** |  |  |
|**image** | **String** |  |  |




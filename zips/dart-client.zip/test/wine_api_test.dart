//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for WineApi
void main() {
  // final instance = WineApi();

  group('tests for WineApi', () {
    // Dish Pairing for Wine
    //
    // Find a dish that goes well with a given wine.
    //
    //Future<GetDishPairingForWine200Response> getDishPairingForWine(String wine) async
    test('test getDishPairingForWine', () async {
      // TODO
    });

    // Wine Description
    //
    // Get a simple description of a certain wine, e.g. \"malbec\", \"riesling\", or \"merlot\".
    //
    //Future<GetWineDescription200Response> getWineDescription(String wine) async
    test('test getWineDescription', () async {
      // TODO
    });

    // Wine Pairing
    //
    // Find a wine that goes well with a food. Food can be a dish name (\"steak\"), an ingredient name (\"salmon\"), or a cuisine (\"italian\").
    //
    //Future<GetWinePairing200Response> getWinePairing(String food, { num maxPrice }) async
    test('test getWinePairing', () async {
      // TODO
    });

    // Wine Recommendation
    //
    // Get a specific wine recommendation (concrete product) for a given wine type, e.g. \"merlot\".
    //
    //Future<GetWineRecommendation200Response> getWineRecommendation(String wine, { num maxPrice, num minRating, num number }) async
    test('test getWineRecommendation', () async {
      // TODO
    });

  });
}

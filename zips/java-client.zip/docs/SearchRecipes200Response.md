

# SearchRecipes200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**offset** | **Integer** |  |  |
|**number** | **Integer** |  |  |
|**results** | [**Set&lt;SearchRecipes200ResponseResultsInner&gt;**](SearchRecipes200ResponseResultsInner.md) |  |  |
|**totalResults** | **Integer** |  |  |




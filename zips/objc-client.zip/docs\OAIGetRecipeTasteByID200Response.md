# OAIGetRecipeTasteByID200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | **NSNumber*** |  | 
**saltiness** | **NSNumber*** |  | 
**sourness** | **NSNumber*** |  | 
**bitterness** | **NSNumber*** |  | 
**savoriness** | **NSNumber*** |  | 
**fattiness** | **NSNumber*** |  | 
**spiciness** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ImageAnalysisByURL200ResponseNutrition


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes_used** | **int** |  | 
**calories** | [**ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  | 
**fat** | [**ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  | 
**protein** | [**ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  | 
**carbs** | [**ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



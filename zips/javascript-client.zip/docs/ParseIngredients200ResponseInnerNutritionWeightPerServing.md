# SpoonacularApi.ParseIngredients200ResponseInnerNutritionWeightPerServing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | 
**unit** | **String** |  | 




# SearchGroceryProductsByUPC200ResponseNutrition

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **nutrients** | [**kotlin.collections.Set&lt;SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner&gt;**](SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner.md) |  |  |
| **caloricBreakdown** | [**SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown**](SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown.md) |  |  |




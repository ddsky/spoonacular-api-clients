# Spoonacular.GetRecipePriceBreakdownByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**[GetRecipePriceBreakdownByID200ResponseIngredientsInner]**](GetRecipePriceBreakdownByID200ResponseIngredientsInner.md) |  | 
**totalCost** | **Number** |  | 
**totalCostPerServing** | **Number** |  | 



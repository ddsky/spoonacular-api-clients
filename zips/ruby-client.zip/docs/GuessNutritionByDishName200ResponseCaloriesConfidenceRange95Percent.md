# OpenapiClient::GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **max** | **Float** |  |  |
| **min** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.new(
  max: null,
  min: null
)
```


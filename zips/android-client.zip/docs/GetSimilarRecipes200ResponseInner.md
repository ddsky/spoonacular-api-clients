

# GetSimilarRecipes200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 
**readyInMinutes** | **Integer** |  | 
**servings** | [**BigDecimal**](BigDecimal.md) |  | 
**sourceUrl** | **String** |  | 





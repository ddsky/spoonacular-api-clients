# OpenapiClient::GetWineDescription200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **wine_description** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetWineDescription200Response.new(
  wine_description: null
)
```


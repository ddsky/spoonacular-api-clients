# Spoonacular.GenerateMealPlan200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meals** | [**[GetSimilarRecipes200ResponseInner]**](GetSimilarRecipes200ResponseInner.md) |  | 
**nutrients** | [**GenerateMealPlan200ResponseNutrients**](GenerateMealPlan200ResponseNutrients.md) |  | 



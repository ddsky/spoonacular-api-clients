# # SearchMenuItems200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menu_items** | [**\OpenAPI\Client\Model\MenuItem[]**](MenuItem.md) |  |
**total_menu_items** | **int** |  |
**type** | **string** |  |
**offset** | **int** |  |
**number** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

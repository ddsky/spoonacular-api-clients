
# ImageAnalysisByURL200ResponseCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  | 
**probability** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 




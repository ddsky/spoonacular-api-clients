
# GetRecipeNutritionWidgetByID200ResponseBadInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** |  |  |
| **amount** | **kotlin.String** |  |  |
| **indented** | **kotlin.Boolean** |  |  |
| **percentOfDailyNeeds** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




# GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**Vec<serde_json::Value>**](serde_json::Value.md) |  | 
**likes** | [**Vec<serde_json::Value>**](serde_json::Value.md) |  | 
**price** | [**Vec<serde_json::Value>**](serde_json::Value.md) |  | 
**protein** | [**Vec<models::GetComparableProducts200ResponseComparableProductsProteinInner>**](getComparableProducts_200_response_comparableProducts_protein_inner.md) |  | 
**spoonacular_score** | [**Vec<models::GetComparableProducts200ResponseComparableProductsProteinInner>**](getComparableProducts_200_response_comparableProducts_protein_inner.md) |  | 
**sugar** | [**Vec<serde_json::Value>**](serde_json::Value.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# openapi.model.GetConversationSuggests200ResponseSuggests

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**underscore** | [**Set<GetConversationSuggests200ResponseSuggestsInner>**](GetConversationSuggests200ResponseSuggestsInner.md) |  | [default to const {}]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



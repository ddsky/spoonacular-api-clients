# # GenerateMealPlan200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meals** | [**\com.spoonacular.client\com.spoonacular.client.model\GetSimilarRecipes200ResponseInner[]**](GetSimilarRecipes200ResponseInner.md) |  |
**nutrients** | [**\com.spoonacular.client\com.spoonacular.client.model\GenerateMealPlan200ResponseNutrients**](GenerateMealPlan200ResponseNutrients.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.md) |  | 
**Us** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.md) |  | 

## Methods

### NewGetRecipeInformation200ResponseExtendedIngredientsInnerMeasures

`func NewGetRecipeInformation200ResponseExtendedIngredientsInnerMeasures(metric GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric, us GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric, ) *GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures`

NewGetRecipeInformation200ResponseExtendedIngredientsInnerMeasures instantiates a new GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresWithDefaults

`func NewGetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresWithDefaults() *GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures`

NewGetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresWithDefaults instantiates a new GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetric

`func (o *GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures) GetMetric() GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric`

GetMetric returns the Metric field if non-nil, zero value otherwise.

### GetMetricOk

`func (o *GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures) GetMetricOk() (*GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric, bool)`

GetMetricOk returns a tuple with the Metric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetric

`func (o *GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures) SetMetric(v GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric)`

SetMetric sets Metric field to given value.


### GetUs

`func (o *GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures) GetUs() GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric`

GetUs returns the Us field if non-nil, zero value otherwise.

### GetUsOk

`func (o *GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures) GetUsOk() (*GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric, bool)`

GetUsOk returns a tuple with the Us field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUs

`func (o *GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures) SetUs(v GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric)`

SetUs sets Us field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# ClearMealPlanDayRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **kotlin.String** | The username. | 
**date** | **kotlin.String** | The date in the format yyyy-mm-dd. | 
**hash** | **kotlin.String** | The private hash for the username. | 




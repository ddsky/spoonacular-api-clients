# Org.OpenAPITools.Model.GenerateMealPlan200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Meals** | [**List<GetSimilarRecipes200ResponseInner>**](GetSimilarRecipes200ResponseInner.md) |  | 
**Nutrients** | [**GenerateMealPlan200ResponseNutrients**](GenerateMealPlan200ResponseNutrients.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# # GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**\OpenAPI\Client\Model\GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  |
**us** | [**\OpenAPI\Client\Model\GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)


# RecipeInformationWinePairing

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **pairedWines** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional] |
| **pairingText** | **kotlin.String** |  |  [optional] |
| **productMatches** | [**kotlin.collections.Set&lt;RecipeInformationWinePairingProductMatchesInner&gt;**](RecipeInformationWinePairingProductMatchesInner.md) |  |  [optional] |




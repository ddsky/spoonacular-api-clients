# OpenapiClient::GetDishPairingForWine200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **pairings** | **Array&lt;String&gt;** |  |  |
| **text** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetDishPairingForWine200Response.new(
  pairings: null,
  text: null
)
```


# Org.OpenAPITools.Model.ComputeGlycemicLoad200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | 
**Original** | **string** |  | 
**GlycemicIndex** | **decimal?** |  | 
**GlycemicLoad** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


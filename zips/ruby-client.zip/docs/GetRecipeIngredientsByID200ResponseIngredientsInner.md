# OpenapiClient::GetRecipeIngredientsByID200ResponseIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.md) |  | [optional] |
| **image** | **String** |  |  |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipeIngredientsByID200ResponseIngredientsInner.new(
  amount: null,
  image: null,
  name: null
)
```


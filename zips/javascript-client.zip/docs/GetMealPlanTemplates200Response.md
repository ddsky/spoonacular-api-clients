# Spoonacular.GetMealPlanTemplates200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**[GetMealPlanTemplates200ResponseTemplatesInner]**](GetMealPlanTemplates200ResponseTemplatesInner.md) |  | 




# GetMealPlanTemplates200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **templates** | [**kotlin.collections.Set&lt;GetMealPlanTemplates200ResponseTemplatesInner&gt;**](GetMealPlanTemplates200ResponseTemplatesInner.md) |  |  |




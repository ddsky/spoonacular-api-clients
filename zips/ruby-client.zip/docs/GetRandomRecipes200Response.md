# OpenapiClient::GetRandomRecipes200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **recipes** | [**Array&lt;GetRandomRecipes200ResponseRecipesInner&gt;**](GetRandomRecipes200ResponseRecipesInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRandomRecipes200Response.new(
  recipes: null
)
```


# Spoonacular.GetMealPlanWeek200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**days** | [**[GetMealPlanWeek200ResponseDaysInner]**](GetMealPlanWeek200ResponseDaysInner.md) |  | 



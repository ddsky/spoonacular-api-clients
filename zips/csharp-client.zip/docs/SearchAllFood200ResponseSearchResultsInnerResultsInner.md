# Org.OpenAPITools.Model.SearchAllFood200ResponseSearchResultsInnerResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | 
**Name** | **string** |  | 
**Image** | **string** |  | 
**Link** | **string** |  | 
**Type** | **string** |  | 
**Relevance** | **decimal?** |  | 
**Content** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


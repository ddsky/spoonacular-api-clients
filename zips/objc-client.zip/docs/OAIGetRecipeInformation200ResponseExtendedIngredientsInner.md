# OAIGetRecipeInformation200ResponseExtendedIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **NSString*** |  | 
**amount** | **NSNumber*** |  | 
**consitency** | **NSString*** |  | 
**_id** | **NSNumber*** |  | 
**image** | **NSString*** |  | 
**measures** | [**OAIGetRecipeInformation200ResponseExtendedIngredientsInnerMeasures***](OAIGetRecipeInformation200ResponseExtendedIngredientsInnerMeasures.md) |  | [optional] 
**meta** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**name** | **NSString*** |  | 
**original** | **NSString*** |  | 
**originalName** | **NSString*** |  | 
**unit** | **NSString*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



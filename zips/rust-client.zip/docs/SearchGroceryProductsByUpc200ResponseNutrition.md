# SearchGroceryProductsByUpc200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**Vec<models::ParseIngredients200ResponseInnerNutritionNutrientsInner>**](parseIngredients_200_response_inner_nutrition_nutrients_inner.md) |  | 
**caloric_breakdown** | [**models::ParseIngredients200ResponseInnerNutritionCaloricBreakdown**](parseIngredients_200_response_inner_nutrition_caloricBreakdown.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | 
**title** | **str** |  | 
**image_type** | **str** |  | 

## Example

```python
from spoonacular.models.get_meal_plan_template200_response_days_inner_items_inner_value import GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue

# TODO update the JSON string below
json = "{}"
# create an instance of GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue from a JSON string
get_meal_plan_template200_response_days_inner_items_inner_value_instance = GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.from_json(json)
# print the JSON string representation of the object
print(GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.to_json())

# convert the object into a dict
get_meal_plan_template200_response_days_inner_items_inner_value_dict = get_meal_plan_template200_response_days_inner_items_inner_value_instance.to_dict()
# create an instance of GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue from a dict
get_meal_plan_template200_response_days_inner_items_inner_value_from_dict = GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.from_dict(get_meal_plan_template200_response_days_inner_items_inner_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Org.OpenAPITools.Model.MapIngredientsToGroceryProducts200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Original** | **string** |  | 
**OriginalName** | **string** |  | 
**IngredientImage** | **string** |  | 
**Meta** | **List<string>** |  | 
**Products** | [**List<MapIngredientsToGroceryProducts200ResponseInnerProductsInner>**](MapIngredientsToGroceryProducts200ResponseInnerProductsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


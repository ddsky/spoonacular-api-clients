
# GetAnalyzedRecipeInstructions200ResponseInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  |
| **steps** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInner.md) |  |  [optional] |




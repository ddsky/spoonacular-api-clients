# SpoonacularApi.GetConversationSuggests200ResponseSuggests

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**u** | [**[GetConversationSuggests200ResponseSuggestsInner]**](GetConversationSuggests200ResponseSuggestsInner.md) |  | 



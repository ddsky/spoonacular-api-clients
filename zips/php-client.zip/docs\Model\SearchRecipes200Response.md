# # SearchRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  |
**number** | **int** |  |
**results** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchRecipes200ResponseResultsInner[]**](SearchRecipes200ResponseResultsInner.md) |  |
**total_results** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

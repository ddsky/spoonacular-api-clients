
# GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  | 
**amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**unit** | **kotlin.String** |  | 
**percentDailyNeeds** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 




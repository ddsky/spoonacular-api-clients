# WWW::OpenAPIClient::Object::SearchFoodVideos200ResponseVideosInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchFoodVideos200ResponseVideosInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | 
**length** | **int** |  | 
**rating** | **double** |  | 
**short_title** | **string** |  | 
**thumbnail** | **string** |  | 
**views** | **int** |  | 
**you_tube_id** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



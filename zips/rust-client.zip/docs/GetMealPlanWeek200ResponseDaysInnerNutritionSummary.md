# GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**Vec<crate::models::GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner>**](getMealPlanWeek_200_response_days_inner_nutritionSummary_nutrients_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SearchSiteContent200ResponseArticlesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_points** | Option<[**Vec<models::SearchSiteContent200ResponseArticlesInnerDataPointsInner>**](searchSiteContent_200_response_Articles_inner_dataPoints_inner.md)> |  | [optional]
**image** | **String** |  | 
**link** | **String** |  | 
**name** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



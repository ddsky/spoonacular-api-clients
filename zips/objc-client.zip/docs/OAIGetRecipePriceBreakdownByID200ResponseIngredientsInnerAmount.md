# OAIGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**OAIGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric***](OAIGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  | 
**us** | [**OAIGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric***](OAIGetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# SearchRecipesByNutrients200ResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**carbs** | **kotlin.String** |  | 
**fat** | **kotlin.String** |  | 
**id** | **kotlin.Int** |  | 
**image** | **kotlin.String** |  | 
**imageType** | **kotlin.String** |  | 
**protein** | **kotlin.String** |  | 
**title** | **kotlin.String** |  | 




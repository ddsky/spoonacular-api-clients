# # SearchFoodVideos200ResponseVideosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  |
**length** | **int** |  |
**rating** | **float** |  |
**short_title** | **string** |  |
**thumbnail** | **string** |  |
**views** | **int** |  |
**you_tube_id** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)



# GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**amount** | [**BigDecimal**](BigDecimal.md) |  | 
**unit** | **String** |  | 
**percentDailyNeeds** | [**BigDecimal**](BigDecimal.md) |  | 





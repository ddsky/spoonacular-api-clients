# OAISearchAllFood200ResponseSearchResultsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **NSString*** |  | 
**totalResults** | **NSNumber*** |  | 
**results** | [**OAISet&lt;OAISearchAllFood200ResponseSearchResultsInnerResultsInner&gt;***](OAISearchAllFood200ResponseSearchResultsInnerResultsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



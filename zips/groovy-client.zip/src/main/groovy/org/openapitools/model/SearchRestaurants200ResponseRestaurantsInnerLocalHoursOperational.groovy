package org.openapitools.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Canonical
class SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational {
    
    String monday
    
    String tuesday
    
    String wednesday
    
    String thursday
    
    String friday
    
    String saturday
    
    String sunday
}

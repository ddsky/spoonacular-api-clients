# OAIGetRecipeEquipmentByID200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**equipment** | [**OAISet&lt;OAIGetRecipeEquipmentByID200ResponseEquipmentInner&gt;***](OAIGetRecipeEquipmentByID200ResponseEquipmentInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



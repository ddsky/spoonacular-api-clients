# OpenapiClient::SearchResultDataPointsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **key** | **String** |  |  |
| **value** | **Object** |  |  |
| **show** | **Boolean** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchResultDataPointsInner.new(
  key: null,
  value: null,
  show: null
)
```


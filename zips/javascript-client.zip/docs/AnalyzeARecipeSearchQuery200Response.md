# Spoonacular.AnalyzeARecipeSearchQuery200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dishes** | [**[AnalyzeARecipeSearchQuery200ResponseDishesInner]**](AnalyzeARecipeSearchQuery200ResponseDishesInner.md) |  | 
**ingredients** | [**[AnalyzeARecipeSearchQuery200ResponseIngredientsInner]**](AnalyzeARecipeSearchQuery200ResponseIngredientsInner.md) |  | 
**cuisines** | **[String]** |  | 
**modifiers** | **[String]** |  | 



# GetAnalyzedRecipeInstructions200ResponseInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **f64** |  | 
**step** | **String** |  | 
**ingredients** | Option<[**Vec<models::GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner>**](getAnalyzedRecipeInstructions_200_response_inner_steps_inner_ingredients_inner.md)> |  | [optional]
**equipment** | Option<[**Vec<models::GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner>**](getAnalyzedRecipeInstructions_200_response_inner_steps_inner_ingredients_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



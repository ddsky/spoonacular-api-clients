# SpoonacularApi.GetShoppingList200ResponseAislesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**items** | [**[GetShoppingList200ResponseAislesInnerItemsInner]**](GetShoppingList200ResponseAislesInnerItemsInner.md) |  | [optional] 



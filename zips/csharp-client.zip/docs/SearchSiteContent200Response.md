# spoonacular.Model.SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Articles** | [**List&lt;SearchSiteContent200ResponseArticlesInner&gt;**](SearchSiteContent200ResponseArticlesInner.md) |  | 
**GroceryProducts** | [**List&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**MenuItems** | [**List&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**Recipes** | [**List&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


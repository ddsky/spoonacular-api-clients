

# GetAnalyzedRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsedInstructions** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**ingredients** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 
**equipment** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 





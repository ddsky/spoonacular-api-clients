# GetMealPlanTemplates200ResponseTemplatesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **str** |  | 

## Example

```python
from spoonacular.models.get_meal_plan_templates200_response_templates_inner import GetMealPlanTemplates200ResponseTemplatesInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetMealPlanTemplates200ResponseTemplatesInner from a JSON string
get_meal_plan_templates200_response_templates_inner_instance = GetMealPlanTemplates200ResponseTemplatesInner.from_json(json)
# print the JSON string representation of the object
print(GetMealPlanTemplates200ResponseTemplatesInner.to_json())

# convert the object into a dict
get_meal_plan_templates200_response_templates_inner_dict = get_meal_plan_templates200_response_templates_inner_instance.to_dict()
# create an instance of GetMealPlanTemplates200ResponseTemplatesInner from a dict
get_meal_plan_templates200_response_templates_inner_from_dict = GetMealPlanTemplates200ResponseTemplatesInner.from_dict(get_meal_plan_templates200_response_templates_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



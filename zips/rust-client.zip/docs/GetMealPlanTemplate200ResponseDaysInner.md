# GetMealPlanTemplate200ResponseDaysInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition_summary** | Option<[**models::GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](getMealPlanWeek_200_response_days_inner_nutritionSummary.md)> |  | [optional]
**nutrition_summary_breakfast** | Option<[**models::GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](getMealPlanWeek_200_response_days_inner_nutritionSummary.md)> |  | [optional]
**nutrition_summary_lunch** | Option<[**models::GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](getMealPlanWeek_200_response_days_inner_nutritionSummary.md)> |  | [optional]
**nutrition_summary_dinner** | Option<[**models::GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](getMealPlanWeek_200_response_days_inner_nutritionSummary.md)> |  | [optional]
**day** | **String** |  | 
**items** | Option<[**Vec<models::GetMealPlanTemplate200ResponseDaysInnerItemsInner>**](getMealPlanTemplate_200_response_days_inner_items_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



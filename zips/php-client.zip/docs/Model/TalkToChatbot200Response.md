# # TalkToChatbot200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answer_text** | **string** |  |
**media** | [**\OpenAPI\Client\Model\TalkToChatbot200ResponseMediaInner[]**](TalkToChatbot200ResponseMediaInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# OpenapiClient::ComputeIngredientAmount200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | **Float** |  |  |
| **unit** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ComputeIngredientAmount200Response.new(
  amount: null,
  unit: null
)
```


# OpenapiClient::MapIngredientsToGroceryProducts200ResponseInnerProductsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **title** | **String** |  |  |
| **upc** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::MapIngredientsToGroceryProducts200ResponseInnerProductsInner.new(
  id: null,
  title: null,
  upc: null
)
```


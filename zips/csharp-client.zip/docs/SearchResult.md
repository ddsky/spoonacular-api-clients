# spoonacular.Model.SearchResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Image** | **string** |  | [optional] 
**Link** | **string** |  | [optional] 
**Name** | **string** |  | 
**Type** | **string** |  | [optional] 
**Kvtable** | **string** |  | [optional] 
**Content** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Relevance** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


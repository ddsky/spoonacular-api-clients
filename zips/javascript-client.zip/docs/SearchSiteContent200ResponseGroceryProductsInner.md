# SpoonacularApi.SearchSiteContent200ResponseGroceryProductsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataPoints** | [**[SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner]**](SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner.md) |  | [optional] 
**image** | **String** |  | 
**link** | **String** |  | 
**name** | **String** |  | 



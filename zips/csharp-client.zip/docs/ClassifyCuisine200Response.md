# spoonacular.Model.ClassifyCuisine200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cuisine** | **string** |  | 
**Cuisines** | **List&lt;string&gt;** |  | 
**Confidence** | **decimal** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


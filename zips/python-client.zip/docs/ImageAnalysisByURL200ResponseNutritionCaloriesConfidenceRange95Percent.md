# ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | **float** |  | 
**max** | **float** |  | 

## Example

```python
from spoonacular.models.image_analysis_by_url200_response_nutrition_calories_confidence_range95_percent import ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent

# TODO update the JSON string below
json = "{}"
# create an instance of ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent from a JSON string
image_analysis_by_url200_response_nutrition_calories_confidence_range95_percent_instance = ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.from_json(json)
# print the JSON string representation of the object
print ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.to_json()

# convert the object into a dict
image_analysis_by_url200_response_nutrition_calories_confidence_range95_percent_dict = image_analysis_by_url200_response_nutrition_calories_confidence_range95_percent_instance.to_dict()
# create an instance of ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent from a dict
image_analysis_by_url200_response_nutrition_calories_confidence_range95_percent_form_dict = image_analysis_by_url200_response_nutrition_calories_confidence_range95_percent.from_dict(image_analysis_by_url200_response_nutrition_calories_confidence_range95_percent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



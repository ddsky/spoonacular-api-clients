# OpenapiClient::SearchFoodVideos200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **videos** | [**Array&lt;SearchFoodVideos200ResponseVideosInner&gt;**](SearchFoodVideos200ResponseVideosInner.md) |  |  |
| **total_results** | **Integer** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchFoodVideos200Response.new(
  videos: null,
  total_results: null
)
```


# OAIGuessNutritionByDishName200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**OAIGuessNutritionByDishName200ResponseCalories***](OAIGuessNutritionByDishName200ResponseCalories.md) |  | 
**carbs** | [**OAIGuessNutritionByDishName200ResponseCalories***](OAIGuessNutritionByDishName200ResponseCalories.md) |  | 
**fat** | [**OAIGuessNutritionByDishName200ResponseCalories***](OAIGuessNutritionByDishName200ResponseCalories.md) |  | 
**protein** | [**OAIGuessNutritionByDishName200ResponseCalories***](OAIGuessNutritionByDishName200ResponseCalories.md) |  | 
**recipesUsed** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



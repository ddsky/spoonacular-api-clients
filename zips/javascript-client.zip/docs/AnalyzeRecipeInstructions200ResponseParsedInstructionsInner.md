# Spoonacular.AnalyzeRecipeInstructions200ResponseParsedInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**steps** | [**[AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional] 



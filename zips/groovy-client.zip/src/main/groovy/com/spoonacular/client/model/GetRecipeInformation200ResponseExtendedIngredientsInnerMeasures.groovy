package com.spoonacular.client.model;

import groovy.transform.Canonical
import com.spoonacular.client.model.GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Canonical
class GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures {
    
    GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric metric
    
    GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric us
}

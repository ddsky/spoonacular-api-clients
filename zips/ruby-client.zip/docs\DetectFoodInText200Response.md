# OpenapiClient::DetectFoodInText200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **annotations** | [**Array&lt;DetectFoodInText200ResponseAnnotationsInner&gt;**](DetectFoodInText200ResponseAnnotationsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::DetectFoodInText200Response.new(
  annotations: null
)
```


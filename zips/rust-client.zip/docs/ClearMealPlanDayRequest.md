# ClearMealPlanDayRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** | The username. | 
**date** | **String** | The date in the format yyyy-mm-dd. | 
**hash** | **String** | The private hash for the username. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



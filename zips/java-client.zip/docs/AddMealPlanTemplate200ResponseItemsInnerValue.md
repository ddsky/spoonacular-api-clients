

# AddMealPlanTemplate200ResponseItemsInnerValue


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  [optional] |
|**servings** | **BigDecimal** |  |  [optional] |
|**title** | **String** |  |  [optional] |
|**imageType** | **String** |  |  [optional] |




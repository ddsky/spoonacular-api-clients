

# RecipeInformationWinePairingProductMatchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**description** | **String** |  | 
**price** | **String** |  | 
**imageUrl** | **String** |  | 
**averageRating** | [**BigDecimal**](BigDecimal.md) |  | 
**ratingCount** | **Integer** |  | 
**score** | [**BigDecimal**](BigDecimal.md) |  | 
**link** | **String** |  | 





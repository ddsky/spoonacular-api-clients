

# AutocompleteRecipeSearch200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 





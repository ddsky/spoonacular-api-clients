# GetWinePairing200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paired_wines** | **Vec<String>** |  | 
**pairing_text** | **String** |  | 
**product_matches** | [**Vec<models::GetWinePairing200ResponseProductMatchesInner>**](getWinePairing_200_response_productMatches_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



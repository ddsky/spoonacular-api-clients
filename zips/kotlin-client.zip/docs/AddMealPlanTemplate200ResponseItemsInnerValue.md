
# AddMealPlanTemplate200ResponseItemsInnerValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  |  [optional]
**servings** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**title** | **kotlin.String** |  |  [optional]
**imageType** | **kotlin.String** |  |  [optional]




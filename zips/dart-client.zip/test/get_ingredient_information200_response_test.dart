//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GetIngredientInformation200Response
void main() {
  // final instance = GetIngredientInformation200Response();

  group('test GetIngredientInformation200Response', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String original
    test('to test the property `original`', () async {
      // TODO
    });

    // String originalName
    test('to test the property `originalName`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String nameClean
    test('to test the property `nameClean`', () async {
      // TODO
    });

    // num amount
    test('to test the property `amount`', () async {
      // TODO
    });

    // String unit
    test('to test the property `unit`', () async {
      // TODO
    });

    // String unitShort
    test('to test the property `unitShort`', () async {
      // TODO
    });

    // String unitLong
    test('to test the property `unitLong`', () async {
      // TODO
    });

    // List<String> possibleUnits (default value: const [])
    test('to test the property `possibleUnits`', () async {
      // TODO
    });

    // ParseIngredients200ResponseInnerEstimatedCost estimatedCost
    test('to test the property `estimatedCost`', () async {
      // TODO
    });

    // String consistency
    test('to test the property `consistency`', () async {
      // TODO
    });

    // List<String> shoppingListUnits (default value: const [])
    test('to test the property `shoppingListUnits`', () async {
      // TODO
    });

    // String aisle
    test('to test the property `aisle`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // List<Object> meta (default value: const [])
    test('to test the property `meta`', () async {
      // TODO
    });

    // GetIngredientInformation200ResponseNutrition nutrition
    test('to test the property `nutrition`', () async {
      // TODO
    });

    // List<String> categoryPath (default value: const [])
    test('to test the property `categoryPath`', () async {
      // TODO
    });


  });

}

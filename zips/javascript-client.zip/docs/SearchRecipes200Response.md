# Spoonacular.SearchRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | 
**number** | **Number** |  | 
**results** | [**[SearchRecipes200ResponseResultsInner]**](SearchRecipes200ResponseResultsInner.md) |  | 
**totalResults** | **Number** |  | 



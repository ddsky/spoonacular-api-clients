
# GetShoppingList200ResponseAislesInnerItemsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**name** | **kotlin.String** |  | 
**pantryItem** | **kotlin.Boolean** |  | 
**aisle** | **kotlin.String** |  | 
**cost** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**ingredientId** | **kotlin.Int** |  | 
**measures** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasures**](GetShoppingList200ResponseAislesInnerItemsInnerMeasures.md) |  |  [optional]




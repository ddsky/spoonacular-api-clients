# OpenapiClient::GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | **Float** |  |  |
| **unit** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.new(
  amount: null,
  unit: null
)
```


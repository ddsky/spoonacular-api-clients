
# DetectFoodInText200ResponseAnnotationsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **&#x60;annotation&#x60;** | **kotlin.String** |  |  |
| **image** | **kotlin.String** |  |  |
| **tag** | **kotlin.String** |  |  |




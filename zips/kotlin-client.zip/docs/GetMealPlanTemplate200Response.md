
# GetMealPlanTemplate200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** |  |  |
| **name** | **kotlin.String** |  |  |
| **days** | [**kotlin.collections.Set&lt;GetMealPlanTemplate200ResponseDaysInner&gt;**](GetMealPlanTemplate200ResponseDaysInner.md) |  |  |




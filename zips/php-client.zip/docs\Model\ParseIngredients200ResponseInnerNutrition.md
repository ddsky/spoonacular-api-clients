# # ParseIngredients200ResponseInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\com.spoonacular.client\com.spoonacular.client.model\ParseIngredients200ResponseInnerNutritionNutrientsInner[]**](ParseIngredients200ResponseInnerNutritionNutrientsInner.md) |  |
**properties** | [**\com.spoonacular.client\com.spoonacular.client.model\ParseIngredients200ResponseInnerNutritionPropertiesInner[]**](ParseIngredients200ResponseInnerNutritionPropertiesInner.md) |  |
**flavonoids** | [**\com.spoonacular.client\com.spoonacular.client.model\ParseIngredients200ResponseInnerNutritionPropertiesInner[]**](ParseIngredients200ResponseInnerNutritionPropertiesInner.md) |  |
**caloric_breakdown** | [**\com.spoonacular.client\com.spoonacular.client.model\ParseIngredients200ResponseInnerNutritionCaloricBreakdown**](ParseIngredients200ResponseInnerNutritionCaloricBreakdown.md) |  |
**weight_per_serving** | [**\com.spoonacular.client\com.spoonacular.client.model\ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# GetShoppingList200ResponseAislesInnerItemsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Original** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  | 
**Metric** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  | 
**Us** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  | 

## Methods

### NewGetShoppingList200ResponseAislesInnerItemsInnerMeasures

`func NewGetShoppingList200ResponseAislesInnerItemsInnerMeasures(original GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal, metric GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal, us GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal, ) *GetShoppingList200ResponseAislesInnerItemsInnerMeasures`

NewGetShoppingList200ResponseAislesInnerItemsInnerMeasures instantiates a new GetShoppingList200ResponseAislesInnerItemsInnerMeasures object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresWithDefaults

`func NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresWithDefaults() *GetShoppingList200ResponseAislesInnerItemsInnerMeasures`

NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresWithDefaults instantiates a new GetShoppingList200ResponseAislesInnerItemsInnerMeasures object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetOriginal

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetOriginal() GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal`

GetOriginal returns the Original field if non-nil, zero value otherwise.

### GetOriginalOk

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetOriginalOk() (*GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal, bool)`

GetOriginalOk returns a tuple with the Original field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOriginal

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) SetOriginal(v GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal)`

SetOriginal sets Original field to given value.


### GetMetric

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetMetric() GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal`

GetMetric returns the Metric field if non-nil, zero value otherwise.

### GetMetricOk

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetMetricOk() (*GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal, bool)`

GetMetricOk returns a tuple with the Metric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetric

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) SetMetric(v GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal)`

SetMetric sets Metric field to given value.


### GetUs

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetUs() GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal`

GetUs returns the Us field if non-nil, zero value otherwise.

### GetUsOk

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetUsOk() (*GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal, bool)`

GetUsOk returns a tuple with the Us field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUs

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) SetUs(v GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal)`

SetUs sets Us field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



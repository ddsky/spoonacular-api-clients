

# SearchCustomFoods200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**customFoods** | [**Set&lt;SearchCustomFoods200ResponseCustomFoodsInner&gt;**](SearchCustomFoods200ResponseCustomFoodsInner.md) |  |  |
|**type** | **String** |  |  |
|**offset** | **Integer** |  |  |
|**number** | **Integer** |  |  |




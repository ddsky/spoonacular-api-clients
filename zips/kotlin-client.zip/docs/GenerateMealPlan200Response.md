
# GenerateMealPlan200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meals** | [**kotlin.collections.Set&lt;GetSimilarRecipes200ResponseInner&gt;**](GetSimilarRecipes200ResponseInner.md) |  | 
**nutrients** | [**GenerateMealPlan200ResponseNutrients**](GenerateMealPlan200ResponseNutrients.md) |  | 




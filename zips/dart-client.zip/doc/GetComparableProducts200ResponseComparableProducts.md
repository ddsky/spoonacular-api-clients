# openapi.model.GetComparableProducts200ResponseComparableProducts

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**List<Object>**](Object.md) |  | [default to const []]
**likes** | [**List<Object>**](Object.md) |  | [default to const []]
**price** | [**List<Object>**](Object.md) |  | [default to const []]
**protein** | [**Set<GetComparableProducts200ResponseComparableProductsProteinInner>**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | [default to const {}]
**spoonacularScore** | [**Set<GetComparableProducts200ResponseComparableProductsProteinInner>**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | [default to const {}]
**sugar** | [**List<Object>**](Object.md) |  | [default to const []]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



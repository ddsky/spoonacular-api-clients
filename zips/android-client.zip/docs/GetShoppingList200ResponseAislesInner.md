

# GetShoppingList200ResponseAislesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**items** | [**Set&lt;GetShoppingList200ResponseAislesInnerItemsInner&gt;**](GetShoppingList200ResponseAislesInnerItemsInner.md) |  |  [optional]





package org.openapitools.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.model.GetComparableProducts200ResponseComparableProducts;

@Canonical
class GetComparableProducts200Response {
    
    GetComparableProducts200ResponseComparableProducts comparableProducts
}

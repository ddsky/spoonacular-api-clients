
# ComputeGlycemicLoadRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **ingredients** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  |




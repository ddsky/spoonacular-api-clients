# GetShoppingList200ResponseAislesInnerItemsInnerMeasures


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 
**metric** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 
**us** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 

## Example

```python
from spoonacular.models.get_shopping_list200_response_aisles_inner_items_inner_measures import GetShoppingList200ResponseAislesInnerItemsInnerMeasures

# TODO update the JSON string below
json = "{}"
# create an instance of GetShoppingList200ResponseAislesInnerItemsInnerMeasures from a JSON string
get_shopping_list200_response_aisles_inner_items_inner_measures_instance = GetShoppingList200ResponseAislesInnerItemsInnerMeasures.from_json(json)
# print the JSON string representation of the object
print GetShoppingList200ResponseAislesInnerItemsInnerMeasures.to_json()

# convert the object into a dict
get_shopping_list200_response_aisles_inner_items_inner_measures_dict = get_shopping_list200_response_aisles_inner_items_inner_measures_instance.to_dict()
# create an instance of GetShoppingList200ResponseAislesInnerItemsInnerMeasures from a dict
get_shopping_list200_response_aisles_inner_items_inner_measures_form_dict = get_shopping_list200_response_aisles_inner_items_inner_measures.from_dict(get_shopping_list200_response_aisles_inner_items_inner_measures_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



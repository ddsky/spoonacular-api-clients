# # IngredientInformationNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\OpenAPI\Client\Model\SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner[]**](SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner.md) |  |
**properties** | [**\OpenAPI\Client\Model\IngredientInformationNutritionPropertiesInner[]**](IngredientInformationNutritionPropertiesInner.md) |  |
**caloric_breakdown** | [**\OpenAPI\Client\Model\SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown**](SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown.md) |  |
**weight_per_serving** | [**\OpenAPI\Client\Model\GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# # SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monday** | **string** |  | [optional]
**tuesday** | **string** |  | [optional]
**wednesday** | **string** |  | [optional]
**thursday** | **string** |  | [optional]
**friday** | **string** |  | [optional]
**saturday** | **string** |  | [optional]
**sunday** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

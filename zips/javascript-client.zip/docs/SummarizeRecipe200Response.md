# Spoonacular.SummarizeRecipe200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**summary** | **String** |  | 
**title** | **String** |  | 




# SearchRestaurants200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **restaurants** | [**kotlin.collections.List&lt;SearchRestaurants200ResponseRestaurantsInner&gt;**](SearchRestaurants200ResponseRestaurantsInner.md) |  |  [optional] |




# Org.OpenAPITools.Model.GetRecipeInformation200ResponseWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PairedWines** | **List<string>** |  | 
**PairingText** | **string** |  | 
**ProductMatches** | [**List<GetRecipeInformation200ResponseWinePairingProductMatchesInner>**](GetRecipeInformation200ResponseWinePairingProductMatchesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


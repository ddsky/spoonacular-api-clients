

# GetIngredientSubstitutes200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**ingredient** | **String** |  |  |
|**substitutes** | **List&lt;String&gt;** |  |  |
|**message** | **String** |  |  |




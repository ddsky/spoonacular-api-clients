# Spoonacular.GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | 
**unit** | **String** |  | 



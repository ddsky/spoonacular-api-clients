

# MapIngredientsToGroceryProducts200ResponseInnerProductsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  |
|**title** | **String** |  |  |
|**upc** | **String** |  |  |




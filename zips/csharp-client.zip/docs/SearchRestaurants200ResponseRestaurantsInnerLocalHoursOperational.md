# spoonacular.Model.SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Monday** | **string** |  | [optional] 
**Tuesday** | **string** |  | [optional] 
**Wednesday** | **string** |  | [optional] 
**Thursday** | **string** |  | [optional] 
**Friday** | **string** |  | [optional] 
**Saturday** | **string** |  | [optional] 
**Sunday** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# Org.OpenAPITools.Model.GetWineRecommendation200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RecommendedWines** | [**List<GetWineRecommendation200ResponseRecommendedWinesInner>**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  | 
**TotalFound** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# spoonacular.Model.GetAnalyzedRecipeInstructions200ResponseInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Number** | **decimal** |  | 
**Step** | **string** |  | 
**Ingredients** | [**List&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  | [optional] 
**Equipment** | [**List&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


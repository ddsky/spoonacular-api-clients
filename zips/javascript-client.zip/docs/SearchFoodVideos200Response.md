# SpoonacularApi.SearchFoodVideos200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**videos** | [**[SearchFoodVideos200ResponseVideosInner]**](SearchFoodVideos200ResponseVideosInner.md) |  | 
**totalResults** | **Number** |  | 



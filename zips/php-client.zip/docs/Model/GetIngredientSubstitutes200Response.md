# # GetIngredientSubstitutes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredient** | **string** |  |
**substitutes** | **string[]** |  |
**message** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

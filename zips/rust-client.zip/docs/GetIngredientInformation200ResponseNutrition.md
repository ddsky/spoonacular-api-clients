# GetIngredientInformation200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**Vec<models::ParseIngredients200ResponseInnerNutritionNutrientsInner>**](parseIngredients_200_response_inner_nutrition_nutrients_inner.md) |  | 
**properties** | [**Vec<models::ParseIngredients200ResponseInnerNutritionPropertiesInner>**](parseIngredients_200_response_inner_nutrition_properties_inner.md) |  | 
**caloric_breakdown** | [**models::ParseIngredients200ResponseInnerNutritionCaloricBreakdown**](parseIngredients_200_response_inner_nutrition_caloricBreakdown.md) |  | 
**weight_per_serving** | [**models::ParseIngredients200ResponseInnerNutritionWeightPerServing**](parseIngredients_200_response_inner_nutrition_weightPerServing.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



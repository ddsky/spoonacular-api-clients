
# GetComparableProducts200ResponseComparableProducts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) |  | 
**likes** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) |  | 
**price** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) |  | 
**protein** | [**kotlin.collections.Set&lt;GetComparableProducts200ResponseComparableProductsProteinInner&gt;**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**spoonacularScore** | [**kotlin.collections.Set&lt;GetComparableProducts200ResponseComparableProductsProteinInner&gt;**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**sugar** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) |  | 




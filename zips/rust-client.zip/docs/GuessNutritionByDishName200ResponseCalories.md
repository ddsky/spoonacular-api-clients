# GuessNutritionByDishName200ResponseCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confidence_range95_percent** | [**crate::models::GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent**](guessNutritionByDishName_200_response_calories_confidenceRange95Percent.md) |  | 
**standard_deviation** | **f32** |  | 
**unit** | **String** |  | 
**value** | **f32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



package com.spoonacular.client.model;

import groovy.transform.Canonical
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.spoonacular.client.model.GetRandomRecipes200ResponseRecipesInner;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Canonical
class GetRandomRecipes200Response {
    
    Set<GetRandomRecipes200ResponseRecipesInner> recipes = new LinkedHashSet<>()
}

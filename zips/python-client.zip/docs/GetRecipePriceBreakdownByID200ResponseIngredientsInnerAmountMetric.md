# GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit** | **str** |  | 
**value** | **float** |  | 

## Example

```python
from spoonacular.models.get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_metric import GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric

# TODO update the JSON string below
json = "{}"
# create an instance of GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric from a JSON string
get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_metric_instance = GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.from_json(json)
# print the JSON string representation of the object
print(GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.to_json())

# convert the object into a dict
get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_metric_dict = get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_metric_instance.to_dict()
# create an instance of GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric from a dict
get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_metric_from_dict = GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.from_dict(get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_metric_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



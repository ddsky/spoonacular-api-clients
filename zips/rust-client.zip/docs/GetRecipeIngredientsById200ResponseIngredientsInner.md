# GetRecipeIngredientsById200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | Option<[**models::GetRecipePriceBreakdownById200ResponseIngredientsInnerAmount**](getRecipePriceBreakdownByID_200_response_ingredients_inner_amount.md)> |  | [optional]
**image** | **String** |  | 
**name** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



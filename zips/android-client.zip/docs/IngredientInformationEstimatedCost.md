

# IngredientInformationEstimatedCost

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**BigDecimal**](BigDecimal.md) |  | 
**unit** | **String** |  | 





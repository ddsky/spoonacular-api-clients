# SpoonacularApi.GenerateShoppingList200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**[GetShoppingList200ResponseAislesInner]**](GetShoppingList200ResponseAislesInner.md) |  | 
**cost** | **Number** |  | 
**startDate** | **Number** |  | 
**endDate** | **Number** |  | 



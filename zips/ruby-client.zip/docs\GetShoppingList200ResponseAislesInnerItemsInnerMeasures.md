# OpenapiClient::GetShoppingList200ResponseAislesInnerItemsInnerMeasures

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **original** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  |  |
| **metric** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  |  |
| **us** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetShoppingList200ResponseAislesInnerItemsInnerMeasures.new(
  original: null,
  metric: null,
  us: null
)
```


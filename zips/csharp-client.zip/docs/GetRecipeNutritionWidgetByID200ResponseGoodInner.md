# spoonacular.Model.GetRecipeNutritionWidgetByID200ResponseGoodInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | **string** |  | 
**Indented** | **bool** |  | 
**PercentOfDailyNeeds** | **decimal** |  | 
**Name** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


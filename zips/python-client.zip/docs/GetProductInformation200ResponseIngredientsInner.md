# GetProductInformation200ResponseIngredientsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **object** |  | [optional] 
**name** | **str** |  | 
**safety_level** | **object** |  | [optional] 

## Example

```python
from spoonacular.models.get_product_information200_response_ingredients_inner import GetProductInformation200ResponseIngredientsInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetProductInformation200ResponseIngredientsInner from a JSON string
get_product_information200_response_ingredients_inner_instance = GetProductInformation200ResponseIngredientsInner.from_json(json)
# print the JSON string representation of the object
print GetProductInformation200ResponseIngredientsInner.to_json()

# convert the object into a dict
get_product_information200_response_ingredients_inner_dict = get_product_information200_response_ingredients_inner_instance.to_dict()
# create an instance of GetProductInformation200ResponseIngredientsInner from a dict
get_product_information200_response_ingredients_inner_form_dict = get_product_information200_response_ingredients_inner.from_dict(get_product_information200_response_ingredients_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



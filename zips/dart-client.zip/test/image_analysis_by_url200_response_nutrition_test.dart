//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ImageAnalysisByURL200ResponseNutrition
void main() {
  // final instance = ImageAnalysisByURL200ResponseNutrition();

  group('test ImageAnalysisByURL200ResponseNutrition', () {
    // int recipesUsed
    test('to test the property `recipesUsed`', () async {
      // TODO
    });

    // ImageAnalysisByURL200ResponseNutritionCalories calories
    test('to test the property `calories`', () async {
      // TODO
    });

    // ImageAnalysisByURL200ResponseNutritionCalories fat
    test('to test the property `fat`', () async {
      // TODO
    });

    // ImageAnalysisByURL200ResponseNutritionCalories protein
    test('to test the property `protein`', () async {
      // TODO
    });

    // ImageAnalysisByURL200ResponseNutritionCalories carbs
    test('to test the property `carbs`', () async {
      // TODO
    });


  });

}

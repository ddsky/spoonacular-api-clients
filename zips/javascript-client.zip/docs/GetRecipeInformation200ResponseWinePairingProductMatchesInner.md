# SpoonacularApi.GetRecipeInformation200ResponseWinePairingProductMatchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**description** | **String** |  | 
**price** | **String** |  | 
**imageUrl** | **String** |  | 
**averageRating** | **Number** |  | 
**ratingCount** | **Number** |  | 
**score** | **Number** |  | 
**link** | **String** |  | 



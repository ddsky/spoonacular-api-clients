# # SearchRestaurants200ResponseRestaurantsInnerLocalHours

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operational** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional]
**delivery** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional]
**pickup** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional]
**dine_in** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

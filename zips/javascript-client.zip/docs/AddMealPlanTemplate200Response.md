# Spoonacular.AddMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**items** | [**[AddMealPlanTemplate200ResponseItemsInner]**](AddMealPlanTemplate200ResponseItemsInner.md) |  | 
**publishAsPublic** | **Boolean** |  | 



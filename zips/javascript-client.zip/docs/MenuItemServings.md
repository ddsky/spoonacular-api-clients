# SpoonacularApi.MenuItemServings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Number** |  | 
**size** | **Number** |  | 
**unit** | **String** |  | 



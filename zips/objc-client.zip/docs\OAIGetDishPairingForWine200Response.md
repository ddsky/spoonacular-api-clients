# OAIGetDishPairingForWine200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairings** | **NSArray&lt;NSString*&gt;*** |  | 
**text** | **NSString*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



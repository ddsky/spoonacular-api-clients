# WWW::OpenAPIClient::Object::GetWineDescription200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetWineDescription200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**wine_description** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# WWW::OpenAPIClient::Object::SearchRecipes200ResponseResultsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRecipes200ResponseResultsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **string** |  | 
**calories** | **double** |  | 
**carbs** | **string** |  | 
**fat** | **string** |  | 
**image** | **string** |  | 
**image_type** | **string** |  | 
**protein** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**Vec<models::SearchSiteContent200ResponseArticlesInner>**](searchSiteContent_200_response_Articles_inner.md) |  | 
**grocery_products** | [**Vec<models::SearchSiteContent200ResponseArticlesInner>**](searchSiteContent_200_response_Articles_inner.md) |  | 
**menu_items** | [**Vec<models::SearchSiteContent200ResponseArticlesInner>**](searchSiteContent_200_response_Articles_inner.md) |  | 
**recipes** | [**Vec<models::SearchSiteContent200ResponseArticlesInner>**](searchSiteContent_200_response_Articles_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# AutocompleteProductSearch200ResponseResultsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**title** | **kotlin.String** |  | 




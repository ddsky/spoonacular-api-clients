# SpoonacularApi.TalkToChatbot200ResponseMediaInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**link** | **String** |  | [optional] 



# ParseIngredients200ResponseInnerNutritionCaloricBreakdown


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_protein** | **float** |  | 
**percent_fat** | **float** |  | 
**percent_carbs** | **float** |  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



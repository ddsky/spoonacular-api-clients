//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GetMealPlanWeek200ResponseDaysInner
void main() {
  // final instance = GetMealPlanWeek200ResponseDaysInner();

  group('test GetMealPlanWeek200ResponseDaysInner', () {
    // GetMealPlanWeek200ResponseDaysInnerNutritionSummary nutritionSummary
    test('to test the property `nutritionSummary`', () async {
      // TODO
    });

    // GetMealPlanWeek200ResponseDaysInnerNutritionSummary nutritionSummaryBreakfast
    test('to test the property `nutritionSummaryBreakfast`', () async {
      // TODO
    });

    // GetMealPlanWeek200ResponseDaysInnerNutritionSummary nutritionSummaryLunch
    test('to test the property `nutritionSummaryLunch`', () async {
      // TODO
    });

    // GetMealPlanWeek200ResponseDaysInnerNutritionSummary nutritionSummaryDinner
    test('to test the property `nutritionSummaryDinner`', () async {
      // TODO
    });

    // num date
    test('to test the property `date`', () async {
      // TODO
    });

    // String day
    test('to test the property `day`', () async {
      // TODO
    });

    // Set<GetMealPlanWeek200ResponseDaysInnerItemsInner> items (default value: const {})
    test('to test the property `items`', () async {
      // TODO
    });


  });

}

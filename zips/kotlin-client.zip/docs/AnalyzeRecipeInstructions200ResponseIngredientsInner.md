
# AnalyzeRecipeInstructions200ResponseIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**name** | **kotlin.String** |  | 






# AddToMealPlanRequestValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**Set&lt;AddToMealPlanRequestValueIngredientsInner&gt;**](AddToMealPlanRequestValueIngredientsInner.md) |  | 





# OpenapiClient::GetComparableProducts200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **comparable_products** | [**GetComparableProducts200ResponseComparableProducts**](GetComparableProducts200ResponseComparableProducts.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetComparableProducts200Response.new(
  comparable_products: null
)
```



# GetDishPairingForWine200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairings** | **kotlin.collections.List&lt;kotlin.String&gt;** |  | 
**text** | **kotlin.String** |  | 




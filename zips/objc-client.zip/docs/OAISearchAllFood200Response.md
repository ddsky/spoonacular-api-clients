# OAISearchAllFood200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **NSString*** |  | 
**totalResults** | **NSNumber*** |  | 
**limit** | **NSNumber*** |  | 
**offset** | **NSNumber*** |  | 
**searchResults** | [**OAISet&lt;OAISearchAllFood200ResponseSearchResultsInner&gt;***](OAISearchAllFood200ResponseSearchResultsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



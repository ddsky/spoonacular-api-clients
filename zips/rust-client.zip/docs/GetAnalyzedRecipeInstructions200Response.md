# GetAnalyzedRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsed_instructions** | [**Vec<models::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner>**](getAnalyzedRecipeInstructions_200_response_parsedInstructions_inner.md) |  | 
**ingredients** | [**Vec<models::GetAnalyzedRecipeInstructions200ResponseIngredientsInner>**](getAnalyzedRecipeInstructions_200_response_ingredients_inner.md) |  | 
**equipment** | [**Vec<models::GetAnalyzedRecipeInstructions200ResponseIngredientsInner>**](getAnalyzedRecipeInstructions_200_response_ingredients_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# WWW::OpenAPIClient::Object::GetMealPlanWeek200ResponseDaysInnerItemsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetMealPlanWeek200ResponseDaysInnerItemsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**slot** | **int** |  | 
**position** | **int** |  | 
**type** | **string** |  | 
**value** | [**GetMealPlanWeek200ResponseDaysInnerItemsInnerValue**](GetMealPlanWeek200ResponseDaysInnerItemsInnerValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# # ConvertAmounts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source_amount** | **float** |  |
**source_unit** | **string** |  |
**target_amount** | **float** |  |
**target_unit** | **string** |  |
**answer** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

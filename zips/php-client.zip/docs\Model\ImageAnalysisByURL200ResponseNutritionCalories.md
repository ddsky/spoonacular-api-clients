# # ImageAnalysisByURL200ResponseNutritionCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **float** |  |
**unit** | **string** |  |
**confidence_range95_percent** | [**\com.spoonacular.client\com.spoonacular.client.model\ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent**](ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.md) |  |
**standard_deviation** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

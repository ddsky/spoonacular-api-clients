# WWW::OpenAPIClient::Object::ParseIngredients200ResponseInnerNutritionWeightPerServing

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ParseIngredients200ResponseInnerNutritionWeightPerServing;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **double** |  | 
**unit** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



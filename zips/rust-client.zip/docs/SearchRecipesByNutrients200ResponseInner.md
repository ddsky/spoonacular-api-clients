# SearchRecipesByNutrients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **f32** |  | 
**carbs** | **String** |  | 
**fat** | **String** |  | 
**id** | **i32** |  | 
**image** | **String** |  | 
**image_type** | **String** |  | 
**protein** | **String** |  | 
**title** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



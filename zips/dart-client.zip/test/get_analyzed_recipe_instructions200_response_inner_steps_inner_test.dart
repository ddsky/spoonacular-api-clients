//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GetAnalyzedRecipeInstructions200ResponseInnerStepsInner
void main() {
  // final instance = GetAnalyzedRecipeInstructions200ResponseInnerStepsInner();

  group('test GetAnalyzedRecipeInstructions200ResponseInnerStepsInner', () {
    // num number
    test('to test the property `number`', () async {
      // TODO
    });

    // String step
    test('to test the property `step`', () async {
      // TODO
    });

    // Set<GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner> ingredients (default value: const {})
    test('to test the property `ingredients`', () async {
      // TODO
    });

    // Set<GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner> equipment (default value: const {})
    test('to test the property `equipment`', () async {
      // TODO
    });


  });

}

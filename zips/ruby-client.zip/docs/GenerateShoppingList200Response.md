# OpenapiClient::GenerateShoppingList200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **aisles** | [**Array&lt;GetShoppingList200ResponseAislesInner&gt;**](GetShoppingList200ResponseAislesInner.md) |  |  |
| **cost** | **Float** |  |  |
| **start_date** | **Float** |  |  |
| **end_date** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GenerateShoppingList200Response.new(
  aisles: null,
  cost: null,
  start_date: null,
  end_date: null
)
```


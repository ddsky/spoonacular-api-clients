# # AnalyzeRecipeRequest1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [optional]
**servings** | **int** |  | [optional]
**ingredients** | **string[]** |  | [optional]
**instructions** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# OAIAddMealPlanTemplate200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **NSString*** |  | 
**items** | [**OAISet&lt;OAIAddMealPlanTemplate200ResponseItemsInner&gt;***](OAIAddMealPlanTemplate200ResponseItemsInner.md) |  | 
**publishAsPublic** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



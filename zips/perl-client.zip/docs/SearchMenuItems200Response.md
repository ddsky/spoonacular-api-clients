# WWW::OpenAPIClient::Object::SearchMenuItems200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchMenuItems200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menu_items** | [**ARRAY[MenuItem]**](MenuItem.md) |  | 
**total_menu_items** | **int** |  | 
**type** | **string** |  | 
**offset** | **int** |  | 
**number** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**List&lt;SearchResult&gt;**](SearchResult.md) |  | 
**groceryProducts** | [**List&lt;SearchResult&gt;**](SearchResult.md) |  | 
**menuItems** | [**List&lt;SearchResult&gt;**](SearchResult.md) |  | 
**recipes** | [**List&lt;SearchResult&gt;**](SearchResult.md) |  | 





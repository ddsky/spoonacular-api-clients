

# AddMealPlanTemplate200ResponseItemsInnerValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**servings** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**title** | **String** |  |  [optional]
**imageType** | **String** |  |  [optional]





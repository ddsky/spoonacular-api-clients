# # GetAnalyzedRecipeInstructions200ResponseInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **float** |  |
**step** | **string** |  |
**ingredients** | [**\OpenAPI\Client\Model\GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner[]**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  | [optional]
**equipment** | [**\OpenAPI\Client\Model\GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner[]**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# ParseIngredients200ResponseInnerNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_protein** | **f32** |  | 
**percent_fat** | **f32** |  | 
**percent_carbs** | **f32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SpoonacularApi.ComputeGlycemicLoad200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**original** | **String** |  | 
**glycemicIndex** | **Number** |  | 
**glycemicLoad** | **Number** |  | 



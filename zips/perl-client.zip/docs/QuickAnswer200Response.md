# WWW::OpenAPIClient::Object::QuickAnswer200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::QuickAnswer200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answer** | **string** |  | 
**image** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# # GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\OpenAPI\Client\Model\GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner[]**](GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

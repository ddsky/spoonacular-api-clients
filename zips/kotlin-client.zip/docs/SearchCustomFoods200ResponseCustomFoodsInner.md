
# SearchCustomFoods200ResponseCustomFoodsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** |  |  |
| **title** | **kotlin.String** |  |  |
| **servings** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **imageUrl** | **kotlin.String** |  |  |
| **price** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




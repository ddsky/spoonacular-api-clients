# OpenapiClient::GetRecipeIngredientsByID200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **ingredients** | [**Array&lt;GetRecipeIngredientsByID200ResponseIngredientsInner&gt;**](GetRecipeIngredientsByID200ResponseIngredientsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipeIngredientsByID200Response.new(
  ingredients: null
)
```


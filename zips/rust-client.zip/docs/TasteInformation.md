# TasteInformation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | **f64** |  | 
**saltiness** | **f64** |  | 
**sourness** | **f64** |  | 
**bitterness** | **f64** |  | 
**savoriness** | **f64** |  | 
**fattiness** | **f64** |  | 
**spiciness** | **f64** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



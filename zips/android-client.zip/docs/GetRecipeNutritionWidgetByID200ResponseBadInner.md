

# GetRecipeNutritionWidgetByID200ResponseBadInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | 
**amount** | **String** |  | 
**indented** | **Boolean** |  | 
**percentOfDailyNeeds** | [**BigDecimal**](BigDecimal.md) |  | 






# GetRandomRecipes200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes** | [**kotlin.collections.Set&lt;GetRandomRecipes200ResponseRecipesInner&gt;**](GetRandomRecipes200ResponseRecipesInner.md) |  | 




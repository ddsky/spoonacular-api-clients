
# TalkToChatbot200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **answerText** | **kotlin.String** |  |  |
| **media** | [**kotlin.collections.List&lt;TalkToChatbot200ResponseMediaInner&gt;**](TalkToChatbot200ResponseMediaInner.md) |  |  |




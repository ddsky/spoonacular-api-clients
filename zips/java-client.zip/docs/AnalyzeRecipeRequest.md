

# AnalyzeRecipeRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**title** | **String** |  |  [optional] |
|**servings** | **Integer** |  |  [optional] |
|**ingredients** | **List&lt;String&gt;** |  |  [optional] |
|**instructions** | **String** |  |  [optional] |




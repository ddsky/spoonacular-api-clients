# SpoonacularApi.GetRecipeNutritionWidgetByID200ResponseGoodInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** |  | 
**indented** | **Boolean** |  | 
**percentOfDailyNeeds** | **Number** |  | 
**title** | **String** |  | 



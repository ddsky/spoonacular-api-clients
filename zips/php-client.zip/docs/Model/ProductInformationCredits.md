# # ProductInformationCredits

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **string** |  | [optional]
**link** | **string** |  | [optional]
**image** | **string** |  | [optional]
**image_link** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# GetMealPlanWeek200ResponseDaysInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition_summary** | Option<[**crate::models::GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](getMealPlanWeek_200_response_days_inner_nutritionSummary.md)> |  | [optional]
**nutrition_summary_breakfast** | Option<[**crate::models::GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](getMealPlanWeek_200_response_days_inner_nutritionSummary.md)> |  | [optional]
**nutrition_summary_lunch** | Option<[**crate::models::GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](getMealPlanWeek_200_response_days_inner_nutritionSummary.md)> |  | [optional]
**nutrition_summary_dinner** | Option<[**crate::models::GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](getMealPlanWeek_200_response_days_inner_nutritionSummary.md)> |  | [optional]
**date** | **f32** |  | 
**day** | **String** |  | 
**items** | Option<[**Vec<crate::models::GetMealPlanWeek200ResponseDaysInnerItemsInner>**](getMealPlanWeek_200_response_days_inner_items_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OpenapiClient::ParseIngredients200ResponseInnerNutritionNutrientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **amount** | **Float** |  |  |
| **unit** | **String** |  |  |
| **percent_of_daily_needs** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ParseIngredients200ResponseInnerNutritionNutrientsInner.new(
  name: null,
  amount: null,
  unit: null,
  percent_of_daily_needs: null
)
```


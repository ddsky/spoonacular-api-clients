# SearchAllFood200ResponseSearchResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**total_results** | **i32** |  | 
**results** | Option<[**Vec<models::SearchResult>**](SearchResult.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



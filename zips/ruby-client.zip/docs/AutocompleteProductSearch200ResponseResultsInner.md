# OpenapiClient::AutocompleteProductSearch200ResponseResultsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **title** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AutocompleteProductSearch200ResponseResultsInner.new(
  id: null,
  title: null
)
```


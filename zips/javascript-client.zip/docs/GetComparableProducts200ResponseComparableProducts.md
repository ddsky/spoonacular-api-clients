# SpoonacularApi.GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**[ComparableProduct]**](ComparableProduct.md) |  | 
**likes** | [**[ComparableProduct]**](ComparableProduct.md) |  | 
**price** | [**[ComparableProduct]**](ComparableProduct.md) |  | 
**protein** | [**[ComparableProduct]**](ComparableProduct.md) |  | 
**spoonacularScore** | [**[ComparableProduct]**](ComparableProduct.md) |  | 
**sugar** | [**[ComparableProduct]**](ComparableProduct.md) |  | 



# # SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**\OpenAPI\Client\Model\SearchResult[]**](SearchResult.md) |  |
**grocery_products** | [**\OpenAPI\Client\Model\SearchResult[]**](SearchResult.md) |  |
**menu_items** | [**\OpenAPI\Client\Model\SearchResult[]**](SearchResult.md) |  |
**recipes** | [**\OpenAPI\Client\Model\SearchResult[]**](SearchResult.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)


# GetRecipePriceBreakdownByID200ResponseIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **kotlin.String** |  | 
**name** | **kotlin.String** |  | 
**price** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**amount** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.md) |  |  [optional]




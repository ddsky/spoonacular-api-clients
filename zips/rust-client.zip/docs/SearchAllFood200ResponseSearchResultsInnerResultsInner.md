# SearchAllFood200ResponseSearchResultsInnerResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**name** | **String** |  | 
**image** | Option<**String**> |  | 
**link** | Option<**String**> |  | 
**r#type** | **String** |  | 
**relevance** | **f32** |  | 
**content** | Option<**String**> |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



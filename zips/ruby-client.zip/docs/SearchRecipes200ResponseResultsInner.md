# OpenapiClient::SearchRecipes200ResponseResultsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **title** | **String** |  |  |
| **image** | **String** |  |  |
| **image_type** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRecipes200ResponseResultsInner.new(
  id: null,
  title: null,
  image: null,
  image_type: null
)
```


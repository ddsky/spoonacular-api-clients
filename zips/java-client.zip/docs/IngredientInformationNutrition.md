

# IngredientInformationNutrition


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**nutrients** | [**Set&lt;SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner&gt;**](SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner.md) |  |  |
|**properties** | [**Set&lt;IngredientInformationNutritionPropertiesInner&gt;**](IngredientInformationNutritionPropertiesInner.md) |  |  |
|**caloricBreakdown** | [**SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown**](SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown.md) |  |  |
|**weightPerServing** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  |  |






# SearchFoodVideos200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**videos** | [**Set&lt;SearchFoodVideos200ResponseVideosInner&gt;**](SearchFoodVideos200ResponseVideosInner.md) |  |  |
|**totalResults** | **Integer** |  |  |




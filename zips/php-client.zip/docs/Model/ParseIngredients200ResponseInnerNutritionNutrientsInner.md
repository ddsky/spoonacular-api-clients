# # ParseIngredients200ResponseInnerNutritionNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  |
**amount** | **float** |  |
**unit** | **string** |  |
**percent_of_daily_needs** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

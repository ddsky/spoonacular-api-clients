//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchAllFood200Response
void main() {
  // final instance = SearchAllFood200Response();

  group('test SearchAllFood200Response', () {
    // String query
    test('to test the property `query`', () async {
      // TODO
    });

    // int totalResults
    test('to test the property `totalResults`', () async {
      // TODO
    });

    // int limit
    test('to test the property `limit`', () async {
      // TODO
    });

    // int offset
    test('to test the property `offset`', () async {
      // TODO
    });

    // Set<SearchAllFood200ResponseSearchResultsInner> searchResults (default value: const {})
    test('to test the property `searchResults`', () async {
      // TODO
    });


  });

}

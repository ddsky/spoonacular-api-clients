# # SearchResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_points** | [**\OpenAPI\Client\Model\SearchResultDataPointsInner[]**](SearchResultDataPointsInner.md) |  | [optional]
**image** | **string** |  | [optional]
**link** | **string** |  | [optional]
**name** | **string** |  |
**type** | **string** |  | [optional]
**kvtable** | **string** |  | [optional]
**content** | **string** |  | [optional]
**id** | **int** |  | [optional]
**relevance** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)


# GetRecipePriceBreakdownByID200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**kotlin.collections.Set&lt;GetRecipePriceBreakdownByID200ResponseIngredientsInner&gt;**](GetRecipePriceBreakdownByID200ResponseIngredientsInner.md) |  | 
**totalCost** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**totalCostPerServing** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 




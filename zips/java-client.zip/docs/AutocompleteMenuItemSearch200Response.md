

# AutocompleteMenuItemSearch200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**results** | [**Set&lt;AutocompleteProductSearch200ResponseResultsInner&gt;**](AutocompleteProductSearch200ResponseResultsInner.md) |  |  |




# spoonacular.Model.AddMealPlanTemplate200ResponseItemsInnerValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | [optional] 
**Servings** | **decimal** |  | [optional] 
**Title** | **string** |  | [optional] 
**ImageType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **number** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **step** | **kotlin.String** |  |  |
| **ingredients** | [**kotlin.collections.Set&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
| **equipment** | [**kotlin.collections.Set&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |




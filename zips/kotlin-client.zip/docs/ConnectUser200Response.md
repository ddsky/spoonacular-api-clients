
# ConnectUser200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **username** | **kotlin.String** |  |  |
| **hash** | **kotlin.String** |  |  |




# OAIGetRecipeNutritionWidgetByID200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **NSString*** |  | 
**carbs** | **NSString*** |  | 
**fat** | **NSString*** |  | 
**protein** | **NSString*** |  | 
**bad** | [**OAISet&lt;OAIGetRecipeNutritionWidgetByID200ResponseBadInner&gt;***](OAIGetRecipeNutritionWidgetByID200ResponseBadInner.md) |  | 
**good** | [**OAISet&lt;OAIGetRecipeNutritionWidgetByID200ResponseGoodInner&gt;***](OAIGetRecipeNutritionWidgetByID200ResponseGoodInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



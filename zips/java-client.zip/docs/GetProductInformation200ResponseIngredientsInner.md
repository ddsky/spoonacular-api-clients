

# GetProductInformation200ResponseIngredientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**description** | **Object** |  |  [optional] |
|**name** | **String** |  |  |
|**safetyLevel** | **Object** |  |  [optional] |




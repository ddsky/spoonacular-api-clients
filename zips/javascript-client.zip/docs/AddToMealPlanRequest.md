# SpoonacularApi.AddToMealPlanRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **Number** |  | 
**slot** | **Number** |  | 
**position** | **Number** |  | 
**type** | **String** |  | 
**value** | [**AddToMealPlanRequestValue**](AddToMealPlanRequestValue.md) |  | 



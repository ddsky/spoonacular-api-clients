# # GetRecipeInformation200ResponseWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paired_wines** | **string[]** |  |
**pairing_text** | **string** |  |
**product_matches** | [**\OpenAPI\Client\Model\GetRecipeInformation200ResponseWinePairingProductMatchesInner[]**](GetRecipeInformation200ResponseWinePairingProductMatchesInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

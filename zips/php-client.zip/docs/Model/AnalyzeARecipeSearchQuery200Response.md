# # AnalyzeARecipeSearchQuery200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dishes** | [**\com.spoonacular.client\com.spoonacular.client.model\AnalyzeARecipeSearchQuery200ResponseDishesInner[]**](AnalyzeARecipeSearchQuery200ResponseDishesInner.md) |  |
**ingredients** | [**\com.spoonacular.client\com.spoonacular.client.model\AnalyzeARecipeSearchQuery200ResponseIngredientsInner[]**](AnalyzeARecipeSearchQuery200ResponseIngredientsInner.md) |  |
**cuisines** | **string[]** |  |
**modifiers** | **string[]** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

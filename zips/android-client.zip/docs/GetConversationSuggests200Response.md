

# GetConversationSuggests200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggests** | [**GetConversationSuggests200ResponseSuggests**](GetConversationSuggests200ResponseSuggests.md) |  | 
**words** | [**List&lt;OasAnyTypeNotMapped&gt;**](OasAnyTypeNotMapped.md) |  | 





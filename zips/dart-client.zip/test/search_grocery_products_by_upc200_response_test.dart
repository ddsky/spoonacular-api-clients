//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchGroceryProductsByUPC200Response
void main() {
  // final instance = SearchGroceryProductsByUPC200Response();

  group('test SearchGroceryProductsByUPC200Response', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // List<String> badges (default value: const [])
    test('to test the property `badges`', () async {
      // TODO
    });

    // List<String> importantBadges (default value: const [])
    test('to test the property `importantBadges`', () async {
      // TODO
    });

    // List<String> breadcrumbs (default value: const [])
    test('to test the property `breadcrumbs`', () async {
      // TODO
    });

    // String generatedText
    test('to test the property `generatedText`', () async {
      // TODO
    });

    // String imageType
    test('to test the property `imageType`', () async {
      // TODO
    });

    // int ingredientCount
    test('to test the property `ingredientCount`', () async {
      // TODO
    });

    // String ingredientList
    test('to test the property `ingredientList`', () async {
      // TODO
    });

    // Set<SearchGroceryProductsByUPC200ResponseIngredientsInner> ingredients (default value: const {})
    test('to test the property `ingredients`', () async {
      // TODO
    });

    // num likes
    test('to test the property `likes`', () async {
      // TODO
    });

    // SearchGroceryProductsByUPC200ResponseNutrition nutrition
    test('to test the property `nutrition`', () async {
      // TODO
    });

    // num price
    test('to test the property `price`', () async {
      // TODO
    });

    // SearchGroceryProductsByUPC200ResponseServings servings
    test('to test the property `servings`', () async {
      // TODO
    });

    // num spoonacularScore
    test('to test the property `spoonacularScore`', () async {
      // TODO
    });


  });

}

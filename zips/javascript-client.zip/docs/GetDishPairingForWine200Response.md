# Spoonacular.GetDishPairingForWine200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairings** | **[String]** |  | 
**text** | **String** |  | 



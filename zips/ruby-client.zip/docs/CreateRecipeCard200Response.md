# OpenapiClient::CreateRecipeCard200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **url** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CreateRecipeCard200Response.new(
  url: null
)
```


# SpoonacularApi.AutocompleteProductSearch200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[AutocompleteProductSearch200ResponseResultsInner]**](AutocompleteProductSearch200ResponseResultsInner.md) |  | 



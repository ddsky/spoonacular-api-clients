

# SearchGroceryProductsByUPC200ResponseServings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | [**BigDecimal**](BigDecimal.md) |  | 
**size** | [**BigDecimal**](BigDecimal.md) |  | 
**unit** | **String** |  | 





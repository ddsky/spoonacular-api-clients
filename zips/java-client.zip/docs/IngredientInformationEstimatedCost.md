

# IngredientInformationEstimatedCost


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**value** | **BigDecimal** |  |  |
|**unit** | **String** |  |  |




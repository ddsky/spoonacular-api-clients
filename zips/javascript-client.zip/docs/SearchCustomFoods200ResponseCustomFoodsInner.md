# SpoonacularApi.SearchCustomFoods200ResponseCustomFoodsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**servings** | **Number** |  | 
**imageUrl** | **String** |  | 
**price** | **Number** |  | 



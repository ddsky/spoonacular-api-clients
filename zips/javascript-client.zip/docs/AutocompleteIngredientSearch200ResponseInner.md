# Spoonacular.AutocompleteIngredientSearch200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**image** | **String** |  | 
**id** | **Number** |  | [optional] 
**aisle** | **String** |  | [optional] 
**possibleUnits** | **[String]** |  | [optional] 



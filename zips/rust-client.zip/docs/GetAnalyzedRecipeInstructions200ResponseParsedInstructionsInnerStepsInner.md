# GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **f64** |  | 
**step** | **String** |  | 
**ingredients** | Option<[**Vec<models::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner>**](getAnalyzedRecipeInstructions_200_response_parsedInstructions_inner_steps_inner_ingredients_inner.md)> |  | [optional]
**equipment** | Option<[**Vec<models::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner>**](getAnalyzedRecipeInstructions_200_response_parsedInstructions_inner_steps_inner_ingredients_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



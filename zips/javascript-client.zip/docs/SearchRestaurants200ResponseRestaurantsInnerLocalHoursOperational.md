# Spoonacular.SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monday** | **String** |  | [optional] 
**tuesday** | **String** |  | [optional] 
**wednesday** | **String** |  | [optional] 
**thursday** | **String** |  | [optional] 
**friday** | **String** |  | [optional] 
**saturday** | **String** |  | [optional] 
**sunday** | **String** |  | [optional] 



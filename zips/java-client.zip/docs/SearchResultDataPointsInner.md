

# SearchResultDataPointsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**key** | **String** |  |  |
|**value** | **Object** |  |  |
|**show** | **Boolean** |  |  [optional] |




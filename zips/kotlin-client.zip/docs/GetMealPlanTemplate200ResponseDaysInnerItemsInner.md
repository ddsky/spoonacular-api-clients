
# GetMealPlanTemplate200ResponseDaysInnerItemsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**slot** | **kotlin.Int** |  | 
**position** | **kotlin.Int** |  | 
**type** | **kotlin.String** |  | 
**&#x60;value&#x60;** | [**GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue**](GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.md) |  |  [optional]




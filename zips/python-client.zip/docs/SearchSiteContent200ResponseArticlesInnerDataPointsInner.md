# SearchSiteContent200ResponseArticlesInnerDataPointsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **str** |  | 
**value** | **str** |  | 

## Example

```python
from spoonacular.models.search_site_content200_response_articles_inner_data_points_inner import SearchSiteContent200ResponseArticlesInnerDataPointsInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchSiteContent200ResponseArticlesInnerDataPointsInner from a JSON string
search_site_content200_response_articles_inner_data_points_inner_instance = SearchSiteContent200ResponseArticlesInnerDataPointsInner.from_json(json)
# print the JSON string representation of the object
print(SearchSiteContent200ResponseArticlesInnerDataPointsInner.to_json())

# convert the object into a dict
search_site_content200_response_articles_inner_data_points_inner_dict = search_site_content200_response_articles_inner_data_points_inner_instance.to_dict()
# create an instance of SearchSiteContent200ResponseArticlesInnerDataPointsInner from a dict
search_site_content200_response_articles_inner_data_points_inner_from_dict = SearchSiteContent200ResponseArticlesInnerDataPointsInner.from_dict(search_site_content200_response_articles_inner_data_points_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



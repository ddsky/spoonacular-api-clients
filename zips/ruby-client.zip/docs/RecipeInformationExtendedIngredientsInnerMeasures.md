# OpenapiClient::RecipeInformationExtendedIngredientsInnerMeasures

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **metric** | [**RecipeInformationExtendedIngredientsInnerMeasuresMetric**](RecipeInformationExtendedIngredientsInnerMeasuresMetric.md) |  |  |
| **us** | [**RecipeInformationExtendedIngredientsInnerMeasuresMetric**](RecipeInformationExtendedIngredientsInnerMeasuresMetric.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RecipeInformationExtendedIngredientsInnerMeasures.new(
  metric: null,
  us: null
)
```


# GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**crate::models::GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](getRecipeInformation_200_response_extendedIngredients_inner_measures_metric.md) |  | 
**us** | [**crate::models::GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](getRecipeInformation_200_response_extendedIngredients_inner_measures_metric.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



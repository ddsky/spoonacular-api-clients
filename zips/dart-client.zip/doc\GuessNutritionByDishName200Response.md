# openapi.model.GuessNutritionByDishName200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  | 
**carbs** | [**GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  | 
**fat** | [**GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  | 
**protein** | [**GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  | 
**recipesUsed** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



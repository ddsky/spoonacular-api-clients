# SpoonacularApi.GetRandomRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes** | [**[RecipeInformation]**](RecipeInformation.md) |  | 



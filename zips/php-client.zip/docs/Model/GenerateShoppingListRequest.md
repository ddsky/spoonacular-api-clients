# # GenerateShoppingListRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** | The username. |
**start_date** | **string** | The start date in the format yyyy-mm-dd. |
**end_date** | **string** | The end date in the format yyyy-mm-dd. |
**hash** | **string** | The private hash for the username. |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

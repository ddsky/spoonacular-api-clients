//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ImageAnalysisByURL200Response
void main() {
  // final instance = ImageAnalysisByURL200Response();

  group('test ImageAnalysisByURL200Response', () {
    // ImageAnalysisByURL200ResponseNutrition nutrition
    test('to test the property `nutrition`', () async {
      // TODO
    });

    // ImageAnalysisByURL200ResponseCategory category
    test('to test the property `category`', () async {
      // TODO
    });

    // Set<ImageAnalysisByURL200ResponseRecipesInner> recipes (default value: const {})
    test('to test the property `recipes`', () async {
      // TODO
    });


  });

}

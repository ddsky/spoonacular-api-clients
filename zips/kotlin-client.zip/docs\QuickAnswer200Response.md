
# QuickAnswer200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answer** | **kotlin.String** |  | 
**image** | **kotlin.String** |  | 




# GetConversationSuggests200ResponseSuggestsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 

## Example

```python
from spoonacular.models.get_conversation_suggests200_response_suggests_inner import GetConversationSuggests200ResponseSuggestsInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetConversationSuggests200ResponseSuggestsInner from a JSON string
get_conversation_suggests200_response_suggests_inner_instance = GetConversationSuggests200ResponseSuggestsInner.from_json(json)
# print the JSON string representation of the object
print(GetConversationSuggests200ResponseSuggestsInner.to_json())

# convert the object into a dict
get_conversation_suggests200_response_suggests_inner_dict = get_conversation_suggests200_response_suggests_inner_instance.to_dict()
# create an instance of GetConversationSuggests200ResponseSuggestsInner from a dict
get_conversation_suggests200_response_suggests_inner_from_dict = GetConversationSuggests200ResponseSuggestsInner.from_dict(get_conversation_suggests200_response_suggests_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



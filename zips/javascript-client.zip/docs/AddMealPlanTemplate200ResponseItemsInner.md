# Spoonacular.AddMealPlanTemplate200ResponseItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**day** | **Number** |  | 
**slot** | **Number** |  | 
**position** | **Number** |  | 
**type** | **String** |  | 
**value** | [**AddMealPlanTemplate200ResponseItemsInnerValue**](AddMealPlanTemplate200ResponseItemsInnerValue.md) |  | [optional] 



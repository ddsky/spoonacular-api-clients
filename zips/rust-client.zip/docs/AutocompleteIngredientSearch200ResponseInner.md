# AutocompleteIngredientSearch200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**image** | **String** |  | 
**id** | Option<**i32**> |  | [optional]
**aisle** | Option<**String**> |  | [optional]
**possible_units** | Option<**Vec<String>**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Org.OpenAPITools.Model.GetShoppingList200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Aisles** | [**List<GetShoppingList200ResponseAislesInner>**](GetShoppingList200ResponseAislesInner.md) |  | 
**Cost** | **decimal?** |  | 
**StartDate** | **decimal?** |  | 
**EndDate** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# WWW::OpenAPIClient::Object::AutocompleteIngredientSearch200ResponseInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AutocompleteIngredientSearch200ResponseInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**image** | **string** |  | 
**id** | **int** |  | [optional] 
**aisle** | **string** |  | [optional] 
**possible_units** | **ARRAY[string]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



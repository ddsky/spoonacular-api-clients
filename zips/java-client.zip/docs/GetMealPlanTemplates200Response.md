

# GetMealPlanTemplates200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**templates** | [**Set&lt;GetMealPlanTemplates200ResponseTemplatesInner&gt;**](GetMealPlanTemplates200ResponseTemplatesInner.md) |  |  |




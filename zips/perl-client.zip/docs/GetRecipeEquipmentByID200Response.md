# WWW::OpenAPIClient::Object::GetRecipeEquipmentByID200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetRecipeEquipmentByID200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**equipment** | [**ARRAY[GetRecipeEquipmentByID200ResponseEquipmentInner]**](GetRecipeEquipmentByID200ResponseEquipmentInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



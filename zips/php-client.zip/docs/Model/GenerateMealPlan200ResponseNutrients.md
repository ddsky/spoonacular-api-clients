# # GenerateMealPlan200ResponseNutrients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **float** |  |
**carbohydrates** | **float** |  |
**fat** | **float** |  |
**protein** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

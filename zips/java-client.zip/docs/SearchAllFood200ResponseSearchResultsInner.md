

# SearchAllFood200ResponseSearchResultsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  |
|**totalResults** | **Integer** |  |  |
|**results** | [**Set&lt;SearchResult&gt;**](SearchResult.md) |  |  [optional] |




# openapi.model.RecipeInformationWinePairingProductMatchesInner

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **String** |  | 
**description** | **String** |  | 
**price** | **String** |  | 
**imageUrl** | **String** |  | 
**averageRating** | **num** |  | 
**ratingCount** | **int** |  | 
**score** | **num** |  | 
**link** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **aisle** | **kotlin.String** |  |  |
| **amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **id** | **kotlin.Int** |  |  |
| **image** | **kotlin.String** |  |  |
| **name** | **kotlin.String** |  |  |
| **original** | **kotlin.String** |  |  |
| **originalName** | **kotlin.String** |  |  |
| **unit** | **kotlin.String** |  |  |
| **unitLong** | **kotlin.String** |  |  |
| **unitShort** | **kotlin.String** |  |  |
| **meta** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional] |
| **extendedName** | **kotlin.String** |  |  [optional] |




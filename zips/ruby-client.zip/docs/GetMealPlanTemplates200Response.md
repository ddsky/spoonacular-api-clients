# OpenapiClient::GetMealPlanTemplates200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **templates** | [**Array&lt;GetAnalyzedRecipeInstructions200ResponseIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetMealPlanTemplates200Response.new(
  templates: null
)
```


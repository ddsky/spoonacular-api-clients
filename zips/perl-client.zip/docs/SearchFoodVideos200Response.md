# WWW::OpenAPIClient::Object::SearchFoodVideos200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchFoodVideos200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**videos** | [**ARRAY[SearchFoodVideos200ResponseVideosInner]**](SearchFoodVideos200ResponseVideosInner.md) |  | 
**total_results** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



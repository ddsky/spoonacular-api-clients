# openapi.model.GetShoppingList200ResponseAislesInnerItemsInner

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **String** |  | 
**measures** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasures**](GetShoppingList200ResponseAislesInnerItemsInnerMeasures.md) |  | [optional] 
**pantryItem** | **bool** |  | 
**aisle** | **String** |  | 
**cost** | **num** |  | 
**ingredientId** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SpoonacularApi.DetectFoodInText200ResponseAnnotationsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotation** | **String** |  | 
**image** | **String** |  | 
**tag** | **String** |  | 



# SpoonacularApi.GetMealPlanTemplate200ResponseDaysInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**slot** | **Number** |  | 
**position** | **Number** |  | 
**type** | **String** |  | 
**value** | [**GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue**](GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.md) |  | [optional] 



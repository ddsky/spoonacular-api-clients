
# SearchRecipes200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Int** |  |  |
| **number** | **kotlin.Int** |  |  |
| **results** | [**kotlin.collections.Set&lt;SearchRecipes200ResponseResultsInner&gt;**](SearchRecipes200ResponseResultsInner.md) |  |  |
| **totalResults** | **kotlin.Int** |  |  |




# OpenapiClient::GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **unit** | **String** |  |  |
| **value** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.new(
  unit: null,
  value: null
)
```


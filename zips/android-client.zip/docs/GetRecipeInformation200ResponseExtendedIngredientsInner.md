

# GetRecipeInformation200ResponseExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | [**BigDecimal**](BigDecimal.md) |  | 
**consitency** | **String** |  | 
**id** | **Integer** |  | 
**image** | **String** |  | 
**measures** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures.md) |  |  [optional]
**meta** | **List&lt;String&gt;** |  |  [optional]
**name** | **String** |  | 
**original** | **String** |  | 
**originalName** | **String** |  | 
**unit** | **String** |  | 





# spoonacular.Model.RecipeInformationExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Aisle** | **string** |  | 
**Amount** | **decimal** |  | 
**Consistency** | **string** |  | 
**Id** | **int** |  | 
**Image** | **string** |  | 
**Measures** | [**RecipeInformationExtendedIngredientsInnerMeasures**](RecipeInformationExtendedIngredientsInnerMeasures.md) |  | [optional] 
**Meta** | **List&lt;string&gt;** |  | [optional] 
**Name** | **string** |  | 
**Original** | **string** |  | 
**OriginalName** | **string** |  | 
**Unit** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


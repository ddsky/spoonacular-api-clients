# SearchRestaurants200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | Option<[**Vec<crate::models::SearchRestaurants200ResponseRestaurantsInner>**](searchRestaurants_200_response_restaurants_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



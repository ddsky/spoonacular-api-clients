# Org.OpenAPITools.Model.AnalyzeRecipeRequest1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** |  | [optional] 
**Servings** | **int?** |  | [optional] 
**Ingredients** | **List<string>** |  | [optional] 
**Instructions** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


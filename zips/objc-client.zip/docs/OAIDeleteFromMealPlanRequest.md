# OAIDeleteFromMealPlanRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **NSString*** | The username. | 
**_id** | **NSNumber*** | The shopping list item id. | 
**hash** | **NSString*** | The private hash for the username. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



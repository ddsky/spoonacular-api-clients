# OpenapiClient::GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | **Float** |  |  |
| **unit_long** | **String** |  |  |
| **unit_short** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.new(
  amount: null,
  unit_long: null,
  unit_short: null
)
```


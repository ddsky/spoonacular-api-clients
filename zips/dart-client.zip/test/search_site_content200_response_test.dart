//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchSiteContent200Response
void main() {
  // final instance = SearchSiteContent200Response();

  group('test SearchSiteContent200Response', () {
    // List<SearchResult> articles (default value: const [])
    test('to test the property `articles`', () async {
      // TODO
    });

    // List<SearchResult> groceryProducts (default value: const [])
    test('to test the property `groceryProducts`', () async {
      // TODO
    });

    // List<SearchResult> menuItems (default value: const [])
    test('to test the property `menuItems`', () async {
      // TODO
    });

    // List<SearchResult> recipes (default value: const [])
    test('to test the property `recipes`', () async {
      // TODO
    });


  });

}

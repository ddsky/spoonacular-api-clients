# # SearchGroceryProductsByUPC200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\com.spoonacular.client\com.spoonacular.client.model\ParseIngredients200ResponseInnerNutritionNutrientsInner[]**](ParseIngredients200ResponseInnerNutritionNutrientsInner.md) |  |
**caloric_breakdown** | [**\com.spoonacular.client\com.spoonacular.client.model\ParseIngredients200ResponseInnerNutritionCaloricBreakdown**](ParseIngredients200ResponseInnerNutritionCaloricBreakdown.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

package org.openapitools.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.model.GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric;

@Canonical
class GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures {
    
    GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric metric
    
    GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric us
}

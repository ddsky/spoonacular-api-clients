# spoonacular.Model.GetRecipeInformation200ResponseWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PairedWines** | **List&lt;string&gt;** |  | 
**PairingText** | **string** |  | 
**ProductMatches** | [**List&lt;GetRecipeInformation200ResponseWinePairingProductMatchesInner&gt;**](GetRecipeInformation200ResponseWinePairingProductMatchesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


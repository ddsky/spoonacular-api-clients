# # GetRecipeNutritionWidgetByID200ResponseGoodInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **string** |  |
**indented** | **bool** |  |
**percent_of_daily_needs** | **float** |  |
**title** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

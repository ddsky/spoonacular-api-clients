# SpoonacularApi.SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**[SearchSiteContent200ResponseArticlesInner]**](SearchSiteContent200ResponseArticlesInner.md) |  | 
**groceryProducts** | [**[SearchSiteContent200ResponseArticlesInner]**](SearchSiteContent200ResponseArticlesInner.md) |  | 
**menuItems** | [**[SearchSiteContent200ResponseArticlesInner]**](SearchSiteContent200ResponseArticlesInner.md) |  | 
**recipes** | [**[SearchSiteContent200ResponseArticlesInner]**](SearchSiteContent200ResponseArticlesInner.md) |  | 



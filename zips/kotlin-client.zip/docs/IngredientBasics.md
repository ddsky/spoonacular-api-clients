
# IngredientBasics

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **description** | **kotlin.String** |  |  |
| **name** | **kotlin.String** |  |  |
| **safetyLevel** | **kotlin.String** |  |  |




# OpenapiClient::GetComparableProducts200ResponseComparableProductsProteinInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **difference** | **Float** |  |  |
| **id** | **Integer** |  |  |
| **image** | **String** |  |  |
| **title** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetComparableProducts200ResponseComparableProductsProteinInner.new(
  difference: null,
  id: null,
  image: null,
  title: null
)
```


# RecipeInformationExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | **f64** |  | 
**consistency** | **String** |  | 
**id** | **i32** |  | 
**image** | **String** |  | 
**measures** | Option<[**models::RecipeInformationExtendedIngredientsInnerMeasures**](RecipeInformation_extendedIngredients_inner_measures.md)> |  | [optional]
**meta** | Option<**Vec<String>**> |  | [optional]
**name** | **String** |  | 
**original** | **String** |  | 
**original_name** | **String** |  | 
**unit** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



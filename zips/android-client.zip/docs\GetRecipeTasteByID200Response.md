

# GetRecipeTasteByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | [**BigDecimal**](BigDecimal.md) |  | 
**saltiness** | [**BigDecimal**](BigDecimal.md) |  | 
**sourness** | [**BigDecimal**](BigDecimal.md) |  | 
**bitterness** | [**BigDecimal**](BigDecimal.md) |  | 
**savoriness** | [**BigDecimal**](BigDecimal.md) |  | 
**fattiness** | [**BigDecimal**](BigDecimal.md) |  | 
**spiciness** | [**BigDecimal**](BigDecimal.md) |  | 





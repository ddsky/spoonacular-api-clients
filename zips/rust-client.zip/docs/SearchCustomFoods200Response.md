# SearchCustomFoods200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**custom_foods** | [**Vec<crate::models::SearchCustomFoods200ResponseCustomFoodsInner>**](searchCustomFoods_200_response_customFoods_inner.md) |  | 
**r#type** | **String** |  | 
**offset** | **i32** |  | 
**number** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



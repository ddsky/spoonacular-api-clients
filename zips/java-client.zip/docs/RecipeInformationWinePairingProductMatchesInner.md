

# RecipeInformationWinePairingProductMatchesInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  |
|**title** | **String** |  |  |
|**description** | **String** |  |  |
|**price** | **String** |  |  |
|**imageUrl** | **String** |  |  |
|**averageRating** | **BigDecimal** |  |  |
|**ratingCount** | **Integer** |  |  |
|**score** | **BigDecimal** |  |  |
|**link** | **String** |  |  |




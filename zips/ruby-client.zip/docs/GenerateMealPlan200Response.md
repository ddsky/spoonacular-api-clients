# OpenapiClient::GenerateMealPlan200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **meals** | [**Array&lt;GetSimilarRecipes200ResponseInner&gt;**](GetSimilarRecipes200ResponseInner.md) |  |  |
| **nutrients** | [**GenerateMealPlan200ResponseNutrients**](GenerateMealPlan200ResponseNutrients.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GenerateMealPlan200Response.new(
  meals: null,
  nutrients: null
)
```


# WWW::OpenAPIClient::Object::GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**amount** | **double** |  | 
**unit** | **string** |  | 
**percent_daily_needs** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



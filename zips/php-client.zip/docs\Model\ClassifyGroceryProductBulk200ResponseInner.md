# # ClassifyGroceryProductBulk200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clean_title** | **string** |  |
**image** | **string** |  |
**category** | **string** |  |
**breadcrumbs** | **string[]** |  |
**usda_code** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)



# AnalyzeRecipeInstructions200ResponseParsedInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**steps** | [**Set&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  |  [optional]






# AddMealPlanTemplate200ResponseItemsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **day** | **kotlin.Int** |  |  |
| **slot** | **kotlin.Int** |  |  |
| **position** | **kotlin.Int** |  |  |
| **type** | **kotlin.String** |  |  |
| **&#x60;value&#x60;** | [**AddMealPlanTemplate200ResponseItemsInnerValue**](AddMealPlanTemplate200ResponseItemsInnerValue.md) |  |  [optional] |




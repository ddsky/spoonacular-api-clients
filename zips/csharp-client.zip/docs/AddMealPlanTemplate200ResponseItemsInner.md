# Org.OpenAPITools.Model.AddMealPlanTemplate200ResponseItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Day** | **int?** |  | 
**Slot** | **int?** |  | 
**Position** | **int?** |  | 
**Type** | **string** |  | 
**Value** | [**AddMealPlanTemplate200ResponseItemsInnerValue**](AddMealPlanTemplate200ResponseItemsInnerValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# Spoonacular.GetRecipeIngredientsByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**[GetRecipeIngredientsByID200ResponseIngredientsInner]**](GetRecipeIngredientsByID200ResponseIngredientsInner.md) |  | 



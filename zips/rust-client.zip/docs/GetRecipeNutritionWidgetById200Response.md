# GetRecipeNutritionWidgetById200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **String** |  | 
**carbs** | **String** |  | 
**fat** | **String** |  | 
**protein** | **String** |  | 
**bad** | [**Vec<crate::models::GetRecipeNutritionWidgetById200ResponseBadInner>**](getRecipeNutritionWidgetByID_200_response_bad_inner.md) |  | 
**good** | [**Vec<crate::models::GetRecipeNutritionWidgetById200ResponseGoodInner>**](getRecipeNutritionWidgetByID_200_response_good_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



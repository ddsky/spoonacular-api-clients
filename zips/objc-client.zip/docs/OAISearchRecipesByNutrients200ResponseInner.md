# OAISearchRecipesByNutrients200ResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **NSNumber*** |  | 
**carbs** | **NSString*** |  | 
**fat** | **NSString*** |  | 
**_id** | **NSNumber*** |  | 
**image** | **NSString*** |  | 
**imageType** | **NSString*** |  | 
**protein** | **NSString*** |  | 
**title** | **NSString*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



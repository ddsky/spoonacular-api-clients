# OpenapiClient::GetConversationSuggests200ResponseSuggests

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **_** | [**Array&lt;GetConversationSuggests200ResponseSuggestsInner&gt;**](GetConversationSuggests200ResponseSuggestsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetConversationSuggests200ResponseSuggests.new(
  _: null
)
```


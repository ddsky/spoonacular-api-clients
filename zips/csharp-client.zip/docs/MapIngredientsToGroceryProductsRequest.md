# spoonacular.Model.MapIngredientsToGroceryProductsRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ingredients** | **List&lt;string&gt;** |  | 
**Servings** | **decimal** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


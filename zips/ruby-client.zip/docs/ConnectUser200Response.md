# OpenapiClient::ConnectUser200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **username** | **String** |  |  |
| **hash** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ConnectUser200Response.new(
  username: null,
  hash: null
)
```


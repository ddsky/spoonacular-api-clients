# openapi.model.AddMealPlanTemplate200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**items** | [**Set<AddMealPlanTemplate200ResponseItemsInner>**](AddMealPlanTemplate200ResponseItemsInner.md) |  | [default to const {}]
**publishAsPublic** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



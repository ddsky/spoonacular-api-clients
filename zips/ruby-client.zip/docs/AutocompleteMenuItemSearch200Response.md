# OpenapiClient::AutocompleteMenuItemSearch200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **results** | [**Array&lt;AutocompleteProductSearch200ResponseResultsInner&gt;**](AutocompleteProductSearch200ResponseResultsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AutocompleteMenuItemSearch200Response.new(
  results: null
)
```


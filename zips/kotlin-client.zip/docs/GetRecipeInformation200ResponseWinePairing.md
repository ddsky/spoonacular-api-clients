
# GetRecipeInformation200ResponseWinePairing

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **pairedWines** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  |
| **pairingText** | **kotlin.String** |  |  |
| **productMatches** | [**kotlin.collections.Set&lt;GetRecipeInformation200ResponseWinePairingProductMatchesInner&gt;**](GetRecipeInformation200ResponseWinePairingProductMatchesInner.md) |  |  |




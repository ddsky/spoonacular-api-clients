# Org.OpenAPITools.Model.GetRecipeNutritionWidgetByID200ResponseBadInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | 
**Amount** | **string** |  | 
**Indented** | **bool?** |  | 
**PercentOfDailyNeeds** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


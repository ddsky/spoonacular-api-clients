

# GetRecipeTasteByID200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**sweetness** | **BigDecimal** |  |  |
|**saltiness** | **BigDecimal** |  |  |
|**sourness** | **BigDecimal** |  |  |
|**bitterness** | **BigDecimal** |  |  |
|**savoriness** | **BigDecimal** |  |  |
|**fattiness** | **BigDecimal** |  |  |
|**spiciness** | **BigDecimal** |  |  |




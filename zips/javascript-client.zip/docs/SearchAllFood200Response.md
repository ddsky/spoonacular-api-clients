# Spoonacular.SearchAllFood200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **String** |  | 
**totalResults** | **Number** |  | 
**limit** | **Number** |  | 
**offset** | **Number** |  | 
**searchResults** | [**[SearchAllFood200ResponseSearchResultsInner]**](SearchAllFood200ResponseSearchResultsInner.md) |  | 



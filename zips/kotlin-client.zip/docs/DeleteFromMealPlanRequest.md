
# DeleteFromMealPlanRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **kotlin.String** | The username. | 
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The shopping list item id. | 
**hash** | **kotlin.String** | The private hash for the username. | 




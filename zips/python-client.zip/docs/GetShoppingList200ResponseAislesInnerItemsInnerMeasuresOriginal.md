# GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **float** |  | 
**unit** | **str** |  | 

## Example

```python
from spoonacular.models.get_shopping_list200_response_aisles_inner_items_inner_measures_original import GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal

# TODO update the JSON string below
json = "{}"
# create an instance of GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal from a JSON string
get_shopping_list200_response_aisles_inner_items_inner_measures_original_instance = GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.from_json(json)
# print the JSON string representation of the object
print(GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.to_json())

# convert the object into a dict
get_shopping_list200_response_aisles_inner_items_inner_measures_original_dict = get_shopping_list200_response_aisles_inner_items_inner_measures_original_instance.to_dict()
# create an instance of GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal from a dict
get_shopping_list200_response_aisles_inner_items_inner_measures_original_from_dict = GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.from_dict(get_shopping_list200_response_aisles_inner_items_inner_measures_original_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



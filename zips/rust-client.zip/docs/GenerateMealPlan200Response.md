# GenerateMealPlan200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meals** | [**Vec<crate::models::GetSimilarRecipes200ResponseInner>**](getSimilarRecipes_200_response_inner.md) |  | 
**nutrients** | [**crate::models::GenerateMealPlan200ResponseNutrients**](generateMealPlan_200_response_nutrients.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



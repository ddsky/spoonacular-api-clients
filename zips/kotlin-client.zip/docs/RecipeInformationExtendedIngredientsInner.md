
# RecipeInformationExtendedIngredientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **aisle** | **kotlin.String** |  |  |
| **amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **consistency** | **kotlin.String** |  |  |
| **id** | **kotlin.Int** |  |  |
| **image** | **kotlin.String** |  |  |
| **name** | **kotlin.String** |  |  |
| **original** | **kotlin.String** |  |  |
| **originalName** | **kotlin.String** |  |  |
| **unit** | **kotlin.String** |  |  |
| **measures** | [**RecipeInformationExtendedIngredientsInnerMeasures**](RecipeInformationExtendedIngredientsInnerMeasures.md) |  |  [optional] |
| **meta** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional] |




# Org.OpenAPITools.Model.ClassifyGroceryProduct200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CleanTitle** | **string** |  | 
**Image** | **string** |  | 
**Category** | **string** |  | 
**Breadcrumbs** | **List<string>** |  | 
**UsdaCode** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


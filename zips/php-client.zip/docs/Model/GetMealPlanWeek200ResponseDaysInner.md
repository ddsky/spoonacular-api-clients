# # GetMealPlanWeek200ResponseDaysInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition_summary** | [**\OpenAPI\Client\Model\GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional]
**nutrition_summary_breakfast** | [**\OpenAPI\Client\Model\GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional]
**nutrition_summary_lunch** | [**\OpenAPI\Client\Model\GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional]
**nutrition_summary_dinner** | [**\OpenAPI\Client\Model\GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional]
**date** | **float** |  |
**day** | **string** |  |
**items** | [**\OpenAPI\Client\Model\GetMealPlanWeek200ResponseDaysInnerItemsInner[]**](GetMealPlanWeek200ResponseDaysInnerItemsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

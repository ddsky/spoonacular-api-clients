# WWW::OpenAPIClient::Object::AddToMealPlanRequestValueIngredientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AddToMealPlanRequestValueIngredientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



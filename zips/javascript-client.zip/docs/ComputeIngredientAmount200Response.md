# Spoonacular.ComputeIngredientAmount200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | 
**unit** | **String** |  | 



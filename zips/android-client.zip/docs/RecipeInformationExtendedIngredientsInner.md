

# RecipeInformationExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | [**BigDecimal**](BigDecimal.md) |  | 
**consistency** | **String** |  | 
**id** | **Integer** |  | 
**image** | **String** |  | 
**measures** | [**RecipeInformationExtendedIngredientsInnerMeasures**](RecipeInformationExtendedIngredientsInnerMeasures.md) |  |  [optional]
**meta** | **List&lt;String&gt;** |  |  [optional]
**name** | **String** |  | 
**original** | **String** |  | 
**originalName** | **String** |  | 
**unit** | **String** |  | 






# SearchSiteContent200ResponseGroceryProductsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **kotlin.String** |  | 
**link** | **kotlin.String** |  | 
**name** | **kotlin.String** |  | 
**dataPoints** | [**kotlin.collections.Set&lt;SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner.md) |  |  [optional]




# WWW::OpenAPIClient::Object::ConvertAmounts200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ConvertAmounts200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source_amount** | **double** |  | 
**source_unit** | **string** |  | 
**target_amount** | **double** |  | 
**target_unit** | **string** |  | 
**answer** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



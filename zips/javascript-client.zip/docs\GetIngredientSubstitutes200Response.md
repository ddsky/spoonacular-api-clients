# SpoonacularApi.GetIngredientSubstitutes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredient** | **String** |  | 
**substitutes** | **[String]** |  | 
**message** | **String** |  | 



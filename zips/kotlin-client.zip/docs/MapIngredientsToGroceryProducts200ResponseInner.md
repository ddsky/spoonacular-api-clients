
# MapIngredientsToGroceryProducts200ResponseInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **original** | **kotlin.String** |  |  |
| **originalName** | **kotlin.String** |  |  |
| **ingredientImage** | **kotlin.String** |  |  |
| **meta** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  |
| **products** | [**kotlin.collections.Set&lt;MapIngredientsToGroceryProducts200ResponseInnerProductsInner&gt;**](MapIngredientsToGroceryProducts200ResponseInnerProductsInner.md) |  |  |




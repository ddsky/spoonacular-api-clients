# WWW::OpenAPIClient::Object::AnalyzeRecipeInstructions200ResponseParsedInstructionsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AnalyzeRecipeInstructions200ResponseParsedInstructionsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**steps** | [**ARRAY[AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



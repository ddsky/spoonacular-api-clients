# GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **f32** |  | 
**unit_long** | **String** |  | 
**unit_short** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



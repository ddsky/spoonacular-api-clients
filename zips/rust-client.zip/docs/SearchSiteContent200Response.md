# SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**Vec<models::SearchResult>**](SearchResult.md) |  | 
**grocery_products** | [**Vec<models::SearchResult>**](SearchResult.md) |  | 
**menu_items** | [**Vec<models::SearchResult>**](SearchResult.md) |  | 
**recipes** | [**Vec<models::SearchResult>**](SearchResult.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# # ClearMealPlanDayRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** | The username. |
**date** | **string** | The date in the format yyyy-mm-dd. |
**hash** | **string** | The private hash for the username. |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

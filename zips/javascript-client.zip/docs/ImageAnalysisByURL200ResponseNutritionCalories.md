# SpoonacularApi.ImageAnalysisByURL200ResponseNutritionCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Number** |  | 
**unit** | **String** |  | 
**confidenceRange95Percent** | [**ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent**](ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.md) |  | 
**standardDeviation** | **Number** |  | 



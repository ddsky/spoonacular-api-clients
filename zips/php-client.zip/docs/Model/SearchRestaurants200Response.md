# # SearchRestaurants200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchRestaurants200ResponseRestaurantsInner[]**](SearchRestaurants200ResponseRestaurantsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

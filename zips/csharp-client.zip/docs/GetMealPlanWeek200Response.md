# Org.OpenAPITools.Model.GetMealPlanWeek200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List<GetMealPlanWeek200ResponseDaysInner>**](GetMealPlanWeek200ResponseDaysInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


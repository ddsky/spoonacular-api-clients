# # GetRecipeTasteByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | **float** |  |
**saltiness** | **float** |  |
**sourness** | **float** |  |
**bitterness** | **float** |  |
**savoriness** | **float** |  |
**fattiness** | **float** |  |
**spiciness** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

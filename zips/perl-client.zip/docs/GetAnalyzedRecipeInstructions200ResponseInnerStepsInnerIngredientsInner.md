# WWW::OpenAPIClient::Object::GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **string** |  | 
**localized_name** | **string** |  | 
**image** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



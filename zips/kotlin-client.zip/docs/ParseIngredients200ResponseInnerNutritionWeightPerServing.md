
# ParseIngredients200ResponseInnerNutritionWeightPerServing

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**unit** | **kotlin.String** |  | 




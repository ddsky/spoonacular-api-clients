# openapi.model.GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **num** |  | 
**unitLong** | **String** |  | 
**unitShort** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



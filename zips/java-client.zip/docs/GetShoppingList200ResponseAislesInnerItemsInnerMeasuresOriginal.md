

# GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**amount** | **BigDecimal** |  |  |
|**unit** | **String** |  |  |




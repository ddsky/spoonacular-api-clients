

# DetectFoodInText200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotations** | [**Set&lt;DetectFoodInText200ResponseAnnotationsInner&gt;**](DetectFoodInText200ResponseAnnotationsInner.md) |  | 






# GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** |  |  |
| **name** | **kotlin.String** |  |  |
| **localizedName** | **kotlin.String** |  |  |
| **image** | **kotlin.String** |  |  |




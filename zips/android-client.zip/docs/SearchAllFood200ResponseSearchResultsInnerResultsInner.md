

# SearchAllFood200ResponseSearchResultsInnerResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**name** | **String** |  | 
**image** | **String** |  | 
**link** | **String** |  | 
**type** | **String** |  | 
**relevance** | [**BigDecimal**](BigDecimal.md) |  | 
**content** | **String** |  | 





# OpenapiClient::GetRecipeEquipmentByID200ResponseEquipmentInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **image** | **String** |  |  |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipeEquipmentByID200ResponseEquipmentInner.new(
  image: null,
  name: null
)
```


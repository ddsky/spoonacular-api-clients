# SpoonacularApi.GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**amount** | **Number** |  | 
**unit** | **String** |  | 
**percentDailyNeeds** | **Number** |  | 



//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GenerateShoppingListRequest
void main() {
  // final instance = GenerateShoppingListRequest();

  group('test GenerateShoppingListRequest', () {
    // The username.
    // String username
    test('to test the property `username`', () async {
      // TODO
    });

    // The start date in the format yyyy-mm-dd.
    // String startDate
    test('to test the property `startDate`', () async {
      // TODO
    });

    // The end date in the format yyyy-mm-dd.
    // String endDate
    test('to test the property `endDate`', () async {
      // TODO
    });

    // The private hash for the username.
    // String hash
    test('to test the property `hash`', () async {
      // TODO
    });


  });

}

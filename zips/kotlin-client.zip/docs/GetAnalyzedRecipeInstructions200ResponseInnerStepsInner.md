
# GetAnalyzedRecipeInstructions200ResponseInnerStepsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **number** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **step** | **kotlin.String** |  |  |
| **ingredients** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  |  [optional] |
| **equipment** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  |  [optional] |




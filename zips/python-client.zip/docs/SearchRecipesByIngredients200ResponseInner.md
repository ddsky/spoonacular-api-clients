# SearchRecipesByIngredients200ResponseInner


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**image** | **str** |  | 
**image_type** | **str** |  | 
**likes** | **int** |  | 
**missed_ingredient_count** | **int** |  | 
**missed_ingredients** | [**[SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner]**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 
**title** | **str** |  | 
**unused_ingredients** | **[{str: (bool, date, datetime, dict, float, int, list, str, none_type)}]** |  | 
**used_ingredient_count** | **float** |  | 
**used_ingredients** | [**[SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner]**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



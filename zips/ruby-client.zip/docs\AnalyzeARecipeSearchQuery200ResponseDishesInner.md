# OpenapiClient::AnalyzeARecipeSearchQuery200ResponseDishesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **image** | **String** |  |  |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AnalyzeARecipeSearchQuery200ResponseDishesInner.new(
  image: null,
  name: null
)
```


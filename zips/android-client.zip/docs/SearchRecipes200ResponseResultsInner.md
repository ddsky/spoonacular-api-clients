

# SearchRecipes200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**calories** | [**BigDecimal**](BigDecimal.md) |  | 
**carbs** | **String** |  | 
**fat** | **String** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 
**protein** | **String** |  | 





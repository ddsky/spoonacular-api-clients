
# AnalyzeRecipeRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **kotlin.String** | The input language, either \&quot;en\&quot; or \&quot;de\&quot;. |  [optional]
**includeNutrition** | **kotlin.Boolean** | Whether nutrition data should be added to correctly parsed ingredients. |  [optional]
**includeTaste** | **kotlin.Boolean** | Whether taste data should be added to correctly parsed ingredients. |  [optional]




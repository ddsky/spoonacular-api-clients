//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchResult
void main() {
  // final instance = SearchResult();

  group('test SearchResult', () {
    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String link
    test('to test the property `link`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String type
    test('to test the property `type`', () async {
      // TODO
    });

    // String kvtable
    test('to test the property `kvtable`', () async {
      // TODO
    });

    // String content
    test('to test the property `content`', () async {
      // TODO
    });

    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // num relevance
    test('to test the property `relevance`', () async {
      // TODO
    });


  });

}

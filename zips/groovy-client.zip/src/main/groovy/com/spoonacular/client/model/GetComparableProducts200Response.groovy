package com.spoonacular.client.model;

import groovy.transform.Canonical
import com.spoonacular.client.model.GetComparableProducts200ResponseComparableProducts;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Canonical
class GetComparableProducts200Response {
    
    GetComparableProducts200ResponseComparableProducts comparableProducts
}

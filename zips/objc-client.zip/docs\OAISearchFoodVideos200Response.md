# OAISearchFoodVideos200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**videos** | [**OAISet&lt;OAISearchFoodVideos200ResponseVideosInner&gt;***](OAISearchFoodVideos200ResponseVideosInner.md) |  | 
**totalResults** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



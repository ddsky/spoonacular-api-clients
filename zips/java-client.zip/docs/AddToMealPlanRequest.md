

# AddToMealPlanRequest



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**date** | **BigDecimal** |  |  |
|**slot** | **Integer** |  |  |
|**position** | **Integer** |  |  |
|**type** | **String** |  |  |
|**value** | [**AddToMealPlanRequestValue**](AddToMealPlanRequestValue.md) |  |  |




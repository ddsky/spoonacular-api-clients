# Spoonacular.SearchGroceryProducts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**[AutocompleteRecipeSearch200ResponseInner]**](AutocompleteRecipeSearch200ResponseInner.md) |  | 
**totalProducts** | **Number** |  | 
**type** | **String** |  | 
**offset** | **Number** |  | 
**number** | **Number** |  | 



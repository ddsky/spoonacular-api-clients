# AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **f32** |  | 
**step** | **String** |  | 
**ingredients** | Option<[**Vec<crate::models::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner>**](analyzeRecipeInstructions_200_response_parsedInstructions_inner_steps_inner_ingredients_inner.md)> |  | [optional]
**equipment** | Option<[**Vec<crate::models::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner>**](analyzeRecipeInstructions_200_response_parsedInstructions_inner_steps_inner_ingredients_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Spoonacular.ProductInformationCredits

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  | [optional] 
**link** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**imageLink** | **String** |  | [optional] 



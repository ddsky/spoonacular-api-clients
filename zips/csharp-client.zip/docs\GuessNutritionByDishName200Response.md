# Org.OpenAPITools.Model.GuessNutritionByDishName200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Calories** | [**GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  | 
**Carbs** | [**GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  | 
**Fat** | [**GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  | 
**Protein** | [**GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  | 
**RecipesUsed** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


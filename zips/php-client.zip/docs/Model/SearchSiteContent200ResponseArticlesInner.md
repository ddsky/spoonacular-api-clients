# # SearchSiteContent200ResponseArticlesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_points** | [**\OpenAPI\Client\Model\SearchSiteContent200ResponseArticlesInnerDataPointsInner[]**](SearchSiteContent200ResponseArticlesInnerDataPointsInner.md) |  | [optional]
**image** | **string** |  |
**link** | **string** |  |
**name** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

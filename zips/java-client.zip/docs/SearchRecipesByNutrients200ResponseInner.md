

# SearchRecipesByNutrients200ResponseInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**calories** | **BigDecimal** |  |  |
|**carbs** | **String** |  |  |
|**fat** | **String** |  |  |
|**id** | **Integer** |  |  |
|**image** | **String** |  |  |
|**imageType** | **String** |  |  |
|**protein** | **String** |  |  |
|**title** | **String** |  |  |




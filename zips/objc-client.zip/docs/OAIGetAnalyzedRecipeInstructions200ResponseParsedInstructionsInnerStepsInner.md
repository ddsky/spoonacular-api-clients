# OAIGetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **NSNumber*** |  | 
**step** | **NSString*** |  | 
**ingredients** | [**OAISet&lt;OAIGetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;***](OAIGetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | [**OAISet&lt;OAIGetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;***](OAIGetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



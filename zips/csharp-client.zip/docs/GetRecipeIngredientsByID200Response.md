# Org.OpenAPITools.Model.GetRecipeIngredientsByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ingredients** | [**List<GetRecipeIngredientsByID200ResponseIngredientsInner>**](GetRecipeIngredientsByID200ResponseIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


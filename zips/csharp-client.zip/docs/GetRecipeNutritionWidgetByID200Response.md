# spoonacular.Model.GetRecipeNutritionWidgetByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Calories** | **string** |  | 
**Carbs** | **string** |  | 
**Fat** | **string** |  | 
**Protein** | **string** |  | 
**Bad** | [**List&lt;GetRecipeNutritionWidgetByID200ResponseBadInner&gt;**](GetRecipeNutritionWidgetByID200ResponseBadInner.md) |  | 
**Good** | [**List&lt;GetRecipeNutritionWidgetByID200ResponseGoodInner&gt;**](GetRecipeNutritionWidgetByID200ResponseGoodInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


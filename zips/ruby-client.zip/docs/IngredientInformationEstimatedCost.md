# OpenapiClient::IngredientInformationEstimatedCost

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **value** | **Float** |  |  |
| **unit** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::IngredientInformationEstimatedCost.new(
  value: null,
  unit: null
)
```


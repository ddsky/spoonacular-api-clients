
# TalkToChatbot200ResponseMediaInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** |  |  [optional] |
| **image** | **kotlin.String** |  |  [optional] |
| **link** | **kotlin.String** |  |  [optional] |




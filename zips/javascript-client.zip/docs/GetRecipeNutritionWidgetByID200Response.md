# SpoonacularApi.GetRecipeNutritionWidgetByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **String** |  | 
**carbs** | **String** |  | 
**fat** | **String** |  | 
**protein** | **String** |  | 
**bad** | [**[GetRecipeNutritionWidgetByID200ResponseBadInner]**](GetRecipeNutritionWidgetByID200ResponseBadInner.md) |  | 
**good** | [**[GetRecipeNutritionWidgetByID200ResponseGoodInner]**](GetRecipeNutritionWidgetByID200ResponseGoodInner.md) |  | 



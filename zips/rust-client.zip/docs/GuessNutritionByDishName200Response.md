# GuessNutritionByDishName200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**models::GuessNutritionByDishName200ResponseCalories**](guessNutritionByDishName_200_response_calories.md) |  | 
**carbs** | [**models::GuessNutritionByDishName200ResponseCalories**](guessNutritionByDishName_200_response_calories.md) |  | 
**fat** | [**models::GuessNutritionByDishName200ResponseCalories**](guessNutritionByDishName_200_response_calories.md) |  | 
**protein** | [**models::GuessNutritionByDishName200ResponseCalories**](guessNutritionByDishName_200_response_calories.md) |  | 
**recipes_used** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



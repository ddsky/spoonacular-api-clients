
# SearchRecipesByIngredients200ResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**image** | **kotlin.String** |  | 
**imageType** | **kotlin.String** |  | 
**likes** | **kotlin.Int** |  | 
**missedIngredientCount** | **kotlin.Int** |  | 
**missedIngredients** | [**kotlin.collections.Set&lt;SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner&gt;**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 
**title** | **kotlin.String** |  | 
**unusedIngredients** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) |  | 
**usedIngredientCount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**usedIngredients** | [**kotlin.collections.Set&lt;SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner&gt;**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 




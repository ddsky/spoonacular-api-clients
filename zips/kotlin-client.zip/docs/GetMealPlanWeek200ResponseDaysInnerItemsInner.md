
# GetMealPlanWeek200ResponseDaysInnerItemsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** |  |  |
| **slot** | **kotlin.Int** |  |  |
| **position** | **kotlin.Int** |  |  |
| **type** | **kotlin.String** |  |  |
| **&#x60;value&#x60;** | [**GetMealPlanWeek200ResponseDaysInnerItemsInnerValue**](GetMealPlanWeek200ResponseDaysInnerItemsInnerValue.md) |  |  [optional] |




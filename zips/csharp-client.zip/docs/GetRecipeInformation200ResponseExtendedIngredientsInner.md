# Org.OpenAPITools.Model.GetRecipeInformation200ResponseExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Aisle** | **string** |  | 
**Amount** | **decimal?** |  | 
**Consitency** | **string** |  | 
**Id** | **int?** |  | 
**Image** | **string** |  | 
**Measures** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures.md) |  | [optional] 
**Meta** | **List<string>** |  | [optional] 
**Name** | **string** |  | 
**Original** | **string** |  | 
**OriginalName** | **string** |  | 
**Unit** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


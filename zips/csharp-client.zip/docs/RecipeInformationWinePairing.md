# spoonacular.Model.RecipeInformationWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PairedWines** | **List&lt;string&gt;** |  | [optional] 
**PairingText** | **string** |  | [optional] 
**ProductMatches** | [**List&lt;RecipeInformationWinePairingProductMatchesInner&gt;**](RecipeInformationWinePairingProductMatchesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


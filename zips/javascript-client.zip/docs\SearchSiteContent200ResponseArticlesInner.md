# SpoonacularApi.SearchSiteContent200ResponseArticlesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataPoints** | **[Object]** |  | [optional] 
**image** | **String** |  | 
**link** | **String** |  | 
**name** | **String** |  | 



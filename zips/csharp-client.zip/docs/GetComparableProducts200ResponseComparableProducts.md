# spoonacular.Model.GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Calories** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**Likes** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**Price** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**Protein** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**SpoonacularScore** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**Sugar** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


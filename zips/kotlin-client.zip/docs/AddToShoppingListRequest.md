
# AddToShoppingListRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **item** | **kotlin.String** |  |  |
| **aisle** | **kotlin.String** |  |  |
| **parse** | **kotlin.Boolean** |  |  |




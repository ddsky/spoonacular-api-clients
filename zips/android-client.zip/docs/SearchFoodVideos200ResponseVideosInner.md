

# SearchFoodVideos200ResponseVideosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | 
**length** | **Integer** |  | 
**rating** | [**BigDecimal**](BigDecimal.md) |  | 
**shortTitle** | **String** |  | 
**thumbnail** | **String** |  | 
**views** | **Integer** |  | 
**youTubeId** | **String** |  | 





# # GetWineDescription200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**wine_description** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

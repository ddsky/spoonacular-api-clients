
# GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**unitLong** | **kotlin.String** |  | 
**unitShort** | **kotlin.String** |  | 




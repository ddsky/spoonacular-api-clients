

# ComputeIngredientAmount200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**BigDecimal**](BigDecimal.md) |  | 
**unit** | **String** |  | 





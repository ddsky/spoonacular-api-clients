
# AddMealPlanTemplate200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  | 
**items** | [**kotlin.collections.Set&lt;AddMealPlanTemplate200ResponseItemsInner&gt;**](AddMealPlanTemplate200ResponseItemsInner.md) |  | 
**publishAsPublic** | **kotlin.Boolean** |  | 




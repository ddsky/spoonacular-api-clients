
# SearchAllFood200ResponseSearchResultsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  |
| **totalResults** | **kotlin.Int** |  |  |
| **results** | [**kotlin.collections.Set&lt;SearchResult&gt;**](SearchResult.md) |  |  [optional] |




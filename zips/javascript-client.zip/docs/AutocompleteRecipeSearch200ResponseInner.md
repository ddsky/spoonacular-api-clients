# SpoonacularApi.AutocompleteRecipeSearch200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 



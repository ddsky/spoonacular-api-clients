# OAIGetWineRecommendation200ResponseRecommendedWinesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** |  | 
**title** | **NSString*** |  | 
**averageRating** | **NSNumber*** |  | 
**_description** | **NSString*** |  | 
**imageUrl** | **NSString*** |  | 
**link** | **NSString*** |  | 
**price** | **NSString*** |  | 
**ratingCount** | **NSNumber*** |  | 
**score** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



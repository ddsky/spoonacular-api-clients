

# RecipeInformationExtendedIngredientsInnerMeasuresMetric


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**amount** | **BigDecimal** |  |  |
|**unitLong** | **String** |  |  |
|**unitShort** | **String** |  |  |




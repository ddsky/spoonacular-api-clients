# # GetRandomRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes** | [**\com.spoonacular.client\com.spoonacular.client.model\GetRandomRecipes200ResponseRecipesInner[]**](GetRandomRecipes200ResponseRecipesInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

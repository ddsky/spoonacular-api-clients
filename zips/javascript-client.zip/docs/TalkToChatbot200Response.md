# Spoonacular.TalkToChatbot200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answerText** | **String** |  | 
**media** | [**[TalkToChatbot200ResponseMediaInner]**](TalkToChatbot200ResponseMediaInner.md) |  | 



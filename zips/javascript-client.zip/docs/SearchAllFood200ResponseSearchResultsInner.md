# SpoonacularApi.SearchAllFood200ResponseSearchResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**totalResults** | **Number** |  | 
**results** | [**[SearchAllFood200ResponseSearchResultsInnerResultsInner]**](SearchAllFood200ResponseSearchResultsInnerResultsInner.md) |  | [optional] 



# OAIDetectFoodInText200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotations** | [**OAISet&lt;OAIDetectFoodInText200ResponseAnnotationsInner&gt;***](OAIDetectFoodInText200ResponseAnnotationsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



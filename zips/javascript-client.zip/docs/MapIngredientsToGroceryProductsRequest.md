# SpoonacularApi.MapIngredientsToGroceryProductsRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | **[String]** |  | 
**servings** | **Number** |  | 



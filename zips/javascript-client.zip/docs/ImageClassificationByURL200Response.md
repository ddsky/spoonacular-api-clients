# SpoonacularApi.ImageClassificationByURL200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category** | **String** |  | 
**probability** | **Number** |  | 



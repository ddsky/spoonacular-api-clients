# OpenapiClient::SearchRestaurants200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **restaurants** | [**Array&lt;SearchRestaurants200ResponseRestaurantsInner&gt;**](SearchRestaurants200ResponseRestaurantsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRestaurants200Response.new(
  restaurants: null
)
```


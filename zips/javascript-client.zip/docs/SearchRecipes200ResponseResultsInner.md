# Spoonacular.SearchRecipes200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 



# Spoonacular.SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**amount** | **Number** |  | 
**unit** | **String** |  | 
**percentOfDailyNeeds** | **Number** |  | 



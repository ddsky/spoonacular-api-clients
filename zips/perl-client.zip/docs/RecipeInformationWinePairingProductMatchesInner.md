# WWW::OpenAPIClient::Object::RecipeInformationWinePairingProductMatchesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RecipeInformationWinePairingProductMatchesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **string** |  | 
**description** | **string** |  | 
**price** | **string** |  | 
**image_url** | **string** |  | 
**average_rating** | **double** |  | 
**rating_count** | **int** |  | 
**score** | **double** |  | 
**link** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



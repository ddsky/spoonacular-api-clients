# # SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_protein** | **float** |  |
**percent_fat** | **float** |  |
**percent_carbs** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

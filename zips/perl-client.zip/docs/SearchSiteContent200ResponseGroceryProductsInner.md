# WWW::OpenAPIClient::Object::SearchSiteContent200ResponseGroceryProductsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchSiteContent200ResponseGroceryProductsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_points** | [**ARRAY[SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner]**](SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner.md) |  | [optional] 
**image** | **string** |  | 
**link** | **string** |  | 
**name** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



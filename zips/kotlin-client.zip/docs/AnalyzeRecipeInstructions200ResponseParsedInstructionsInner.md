
# AnalyzeRecipeInstructions200ResponseParsedInstructionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  |
| **steps** | [**kotlin.collections.Set&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  |  [optional] |




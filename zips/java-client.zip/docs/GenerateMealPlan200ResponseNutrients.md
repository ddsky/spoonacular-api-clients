

# GenerateMealPlan200ResponseNutrients


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**calories** | **BigDecimal** |  |  |
|**carbohydrates** | **BigDecimal** |  |  |
|**fat** | **BigDecimal** |  |  |
|**protein** | **BigDecimal** |  |  |




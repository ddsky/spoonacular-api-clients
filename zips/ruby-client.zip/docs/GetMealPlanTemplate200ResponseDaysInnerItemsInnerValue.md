# OpenapiClient::GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Float** |  |  |
| **title** | **String** |  |  |
| **image_type** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.new(
  id: null,
  title: null,
  image_type: null
)
```


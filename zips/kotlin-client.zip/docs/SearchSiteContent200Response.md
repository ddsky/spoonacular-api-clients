
# SearchSiteContent200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **articles** | [**kotlin.collections.List&lt;SearchResult&gt;**](SearchResult.md) |  |  |
| **groceryProducts** | [**kotlin.collections.List&lt;SearchResult&gt;**](SearchResult.md) |  |  |
| **menuItems** | [**kotlin.collections.List&lt;SearchResult&gt;**](SearchResult.md) |  |  |
| **recipes** | [**kotlin.collections.List&lt;SearchResult&gt;**](SearchResult.md) |  |  |




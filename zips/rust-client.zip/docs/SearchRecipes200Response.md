# SearchRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **i32** |  | 
**number** | **i32** |  | 
**results** | [**Vec<models::SearchRecipes200ResponseResultsInner>**](searchRecipes_200_response_results_inner.md) |  | 
**total_results** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



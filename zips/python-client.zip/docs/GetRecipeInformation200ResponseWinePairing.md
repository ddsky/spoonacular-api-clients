# GetRecipeInformation200ResponseWinePairing


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paired_wines** | **[str]** |  | 
**pairing_text** | **str** |  | 
**product_matches** | [**[GetRecipeInformation200ResponseWinePairingProductMatchesInner]**](GetRecipeInformation200ResponseWinePairingProductMatchesInner.md) |  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



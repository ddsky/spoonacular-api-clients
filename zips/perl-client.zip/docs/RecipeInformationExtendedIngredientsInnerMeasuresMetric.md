# WWW::OpenAPIClient::Object::RecipeInformationExtendedIngredientsInnerMeasuresMetric

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RecipeInformationExtendedIngredientsInnerMeasuresMetric;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **double** |  | 
**unit_long** | **string** |  | 
**unit_short** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



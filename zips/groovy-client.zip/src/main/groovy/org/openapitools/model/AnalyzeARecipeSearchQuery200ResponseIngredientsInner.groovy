package org.openapitools.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Canonical
class AnalyzeARecipeSearchQuery200ResponseIngredientsInner {
    
    String image
    
    Boolean include
    
    String name
}


# SearchAllFood200ResponseSearchResultsInnerResultsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.String** |  | 
**name** | **kotlin.String** |  | 
**image** | **kotlin.String** |  | 
**link** | **kotlin.String** |  | 
**type** | **kotlin.String** |  | 
**relevance** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**content** | **kotlin.String** |  | 




# OAIImageAnalysisByURL200ResponseNutritionCalories

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **NSNumber*** |  | 
**unit** | **NSString*** |  | 
**confidenceRange95Percent** | [**OAIImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent***](OAIImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.md) |  | 
**standardDeviation** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



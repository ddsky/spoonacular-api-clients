# ComputeGlycemicLoad200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_glycemic_load** | **f64** |  | 
**ingredients** | [**Vec<models::ComputeGlycemicLoad200ResponseIngredientsInner>**](computeGlycemicLoad_200_response_ingredients_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



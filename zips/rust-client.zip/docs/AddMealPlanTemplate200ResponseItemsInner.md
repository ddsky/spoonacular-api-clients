# AddMealPlanTemplate200ResponseItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**day** | **i32** |  | 
**slot** | **i32** |  | 
**position** | **i32** |  | 
**r#type** | **String** |  | 
**value** | Option<[**models::AddMealPlanTemplate200ResponseItemsInnerValue**](addMealPlanTemplate_200_response_items_inner_value.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



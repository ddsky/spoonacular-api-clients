# MapIngredientsToGroceryProducts200ResponseInnerProductsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **str** |  | 
**upc** | **str** |  | 

## Example

```python
from spoonacular.models.map_ingredients_to_grocery_products200_response_inner_products_inner import MapIngredientsToGroceryProducts200ResponseInnerProductsInner

# TODO update the JSON string below
json = "{}"
# create an instance of MapIngredientsToGroceryProducts200ResponseInnerProductsInner from a JSON string
map_ingredients_to_grocery_products200_response_inner_products_inner_instance = MapIngredientsToGroceryProducts200ResponseInnerProductsInner.from_json(json)
# print the JSON string representation of the object
print MapIngredientsToGroceryProducts200ResponseInnerProductsInner.to_json()

# convert the object into a dict
map_ingredients_to_grocery_products200_response_inner_products_inner_dict = map_ingredients_to_grocery_products200_response_inner_products_inner_instance.to_dict()
# create an instance of MapIngredientsToGroceryProducts200ResponseInnerProductsInner from a dict
map_ingredients_to_grocery_products200_response_inner_products_inner_form_dict = map_ingredients_to_grocery_products200_response_inner_products_inner.from_dict(map_ingredients_to_grocery_products200_response_inner_products_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



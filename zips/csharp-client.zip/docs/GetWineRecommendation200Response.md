# spoonacular.Model.GetWineRecommendation200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RecommendedWines** | [**List&lt;GetWineRecommendation200ResponseRecommendedWinesInner&gt;**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  | 
**TotalFound** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


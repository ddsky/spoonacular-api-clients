# # GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  |
**steps** | [**\com.spoonacular.client\com.spoonacular.client.model\GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner[]**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

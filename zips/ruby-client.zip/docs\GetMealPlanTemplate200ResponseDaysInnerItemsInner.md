# OpenapiClient::GetMealPlanTemplate200ResponseDaysInnerItemsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **slot** | **Integer** |  |  |
| **position** | **Integer** |  |  |
| **type** | **String** |  |  |
| **value** | [**GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue**](GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetMealPlanTemplate200ResponseDaysInnerItemsInner.new(
  id: null,
  slot: null,
  position: null,
  type: null,
  value: null
)
```


# # GetWinePairing200ResponseProductMatchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**title** | **string** |  |
**average_rating** | **float** |  |
**description** | **mixed** |  | [optional]
**image_url** | **string** |  |
**link** | **string** |  |
**price** | **string** |  |
**rating_count** | **int** |  |
**score** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

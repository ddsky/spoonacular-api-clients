# OAIGetConversationSuggests200ResponseSuggests

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_** | [**OAISet&lt;OAIGetConversationSuggests200ResponseSuggestsInner&gt;***](OAIGetConversationSuggests200ResponseSuggestsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# AnalyzeARecipeSearchQuery200ResponseDishesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **str** |  | 
**name** | **str** |  | 

## Example

```python
from spoonacular.models.analyze_a_recipe_search_query200_response_dishes_inner import AnalyzeARecipeSearchQuery200ResponseDishesInner

# TODO update the JSON string below
json = "{}"
# create an instance of AnalyzeARecipeSearchQuery200ResponseDishesInner from a JSON string
analyze_a_recipe_search_query200_response_dishes_inner_instance = AnalyzeARecipeSearchQuery200ResponseDishesInner.from_json(json)
# print the JSON string representation of the object
print(AnalyzeARecipeSearchQuery200ResponseDishesInner.to_json())

# convert the object into a dict
analyze_a_recipe_search_query200_response_dishes_inner_dict = analyze_a_recipe_search_query200_response_dishes_inner_instance.to_dict()
# create an instance of AnalyzeARecipeSearchQuery200ResponseDishesInner from a dict
analyze_a_recipe_search_query200_response_dishes_inner_from_dict = AnalyzeARecipeSearchQuery200ResponseDishesInner.from_dict(analyze_a_recipe_search_query200_response_dishes_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



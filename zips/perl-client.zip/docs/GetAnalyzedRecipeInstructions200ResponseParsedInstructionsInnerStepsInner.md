# WWW::OpenAPIClient::Object::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **double** |  | 
**step** | **string** |  | 
**ingredients** | [**ARRAY[GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner]**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | [**ARRAY[GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner]**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchRestaurants200ResponseRestaurantsInnerLocalHours
void main() {
  // final instance = SearchRestaurants200ResponseRestaurantsInnerLocalHours();

  group('test SearchRestaurants200ResponseRestaurantsInnerLocalHours', () {
    // SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational operational
    test('to test the property `operational`', () async {
      // TODO
    });

    // SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational delivery
    test('to test the property `delivery`', () async {
      // TODO
    });

    // SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational pickup
    test('to test the property `pickup`', () async {
      // TODO
    });

    // SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational dineIn
    test('to test the property `dineIn`', () async {
      // TODO
    });


  });

}

# Org.OpenAPITools.Model.GetMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | 
**Name** | **string** |  | 
**Days** | [**List<GetMealPlanTemplate200ResponseDaysInner>**](GetMealPlanTemplate200ResponseDaysInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ClassifyCuisine200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cuisine** | **kotlin.String** |  | 
**cuisines** | **kotlin.collections.List&lt;kotlin.String&gt;** |  | 
**confidence** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 




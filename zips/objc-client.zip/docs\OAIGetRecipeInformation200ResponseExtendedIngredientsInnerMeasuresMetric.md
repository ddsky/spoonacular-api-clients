# OAIGetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **NSNumber*** |  | 
**unitLong** | **NSString*** |  | 
**unitShort** | **NSString*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



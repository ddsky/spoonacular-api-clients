# OpenapiClient::GetRandomRecipes200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **recipes** | [**Array&lt;RecipeInformation&gt;**](RecipeInformation.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRandomRecipes200Response.new(
  recipes: null
)
```


# GetComparableProducts200ResponseComparableProductsProteinInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**difference** | **f64** |  | 
**id** | **i32** |  | 
**image** | **String** |  | 
**title** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



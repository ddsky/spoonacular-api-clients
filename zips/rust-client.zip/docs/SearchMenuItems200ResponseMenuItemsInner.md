# SearchMenuItems200ResponseMenuItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** |  | 
**title** | **String** |  | 
**restaurant_chain** | **String** |  | 
**image** | **String** |  | 
**image_type** | **String** |  | 
**servings** | Option<[**models::SearchGroceryProductsByUpc200ResponseServings**](searchGroceryProductsByUPC_200_response_servings.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# ParseIngredients200ResponseInnerEstimatedCost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**&#x60;value&#x60;** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**unit** | **kotlin.String** |  | 




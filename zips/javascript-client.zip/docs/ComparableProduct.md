# Spoonacular.ComparableProduct

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**difference** | **Number** |  | 
**id** | **Number** |  | 
**image** | **String** |  | 
**title** | **String** |  | 



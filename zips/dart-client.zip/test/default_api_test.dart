//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for DefaultApi
void main() {
  // final instance = DefaultApi();

  group('tests for DefaultApi', () {
    // Analyze Recipe
    //
    // This endpoint allows you to send raw recipe information, such as title, servings, and ingredients, to then see what we compute (badges, diets, nutrition, and more). This is useful if you have your own recipe data and want to enrich it with our semantic analysis.
    //
    //Future<Object> analyzeRecipe(AnalyzeRecipeRequest analyzeRecipeRequest, { String language, bool includeNutrition, bool includeTaste }) async
    test('test analyzeRecipe', () async {
      // TODO
    });

    // Create Recipe Card
    //
    // Generate a recipe card for a recipe.
    //
    //Future<Object> createRecipeCardGet(int id, { String mask, String backgroundImage, String backgroundColor, String fontColor }) async
    test('test createRecipeCardGet', () async {
      // TODO
    });

    // Search Restaurants
    //
    // Search through thousands of restaurants (in North America) by location, cuisine, budget, and more.
    //
    //Future<SearchRestaurants200Response> searchRestaurants({ String query, num lat, num lng, num distance, num budget, String cuisine, num minRating, bool isOpen, String sort, num page }) async
    test('test searchRestaurants', () async {
      // TODO
    });

  });
}

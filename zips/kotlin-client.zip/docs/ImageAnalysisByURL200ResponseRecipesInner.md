
# ImageAnalysisByURL200ResponseRecipesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**title** | **kotlin.String** |  | 
**imageType** | **kotlin.String** |  | 
**url** | **kotlin.String** |  | 




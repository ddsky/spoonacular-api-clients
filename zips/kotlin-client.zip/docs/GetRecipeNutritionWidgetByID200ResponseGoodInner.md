
# GetRecipeNutritionWidgetByID200ResponseGoodInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **kotlin.String** |  | 
**indented** | **kotlin.Boolean** |  | 
**percentOfDailyNeeds** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**name** | **kotlin.String** |  | 




# SpoonacularApi.SearchRestaurants200ResponseRestaurantsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**phoneNumber** | **Number** |  | [optional] 
**address** | [**SearchRestaurants200ResponseRestaurantsInnerAddress**](SearchRestaurants200ResponseRestaurantsInnerAddress.md) |  | [optional] 
**type** | **String** |  | [optional] 
**description** | **String** |  | [optional] 
**localHours** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHours**](SearchRestaurants200ResponseRestaurantsInnerLocalHours.md) |  | [optional] 
**cuisines** | **[String]** |  | [optional] 
**foodPhotos** | **[String]** |  | [optional] 
**logoPhotos** | **[String]** |  | [optional] 
**storePhotos** | **[Object]** |  | [optional] 
**dollarSigns** | **Number** |  | [optional] 
**pickupEnabled** | **Boolean** |  | [optional] 
**deliveryEnabled** | **Boolean** |  | [optional] 
**isOpen** | **Boolean** |  | [optional] 
**offersFirstPartyDelivery** | **Boolean** |  | [optional] 
**offersThirdPartyDelivery** | **Boolean** |  | [optional] 
**miles** | **Number** |  | [optional] 
**weightedRatingValue** | **Number** |  | [optional] 
**aggregatedRatingCount** | **Number** |  | [optional] 



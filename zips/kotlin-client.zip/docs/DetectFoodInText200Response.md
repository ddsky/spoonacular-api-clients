
# DetectFoodInText200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **annotations** | [**kotlin.collections.Set&lt;DetectFoodInText200ResponseAnnotationsInner&gt;**](DetectFoodInText200ResponseAnnotationsInner.md) |  |  |




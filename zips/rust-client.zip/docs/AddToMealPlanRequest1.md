# AddToMealPlanRequest1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **f32** |  | 
**slot** | **i32** |  | 
**position** | **i32** |  | 
**_type** | **String** |  | 
**value** | [**crate::models::AddToMealPlanRequest1Value**](addToMealPlan_request_1_value.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



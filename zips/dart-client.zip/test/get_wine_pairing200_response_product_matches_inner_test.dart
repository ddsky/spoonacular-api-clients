//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GetWinePairing200ResponseProductMatchesInner
void main() {
  // final instance = GetWinePairing200ResponseProductMatchesInner();

  group('test GetWinePairing200ResponseProductMatchesInner', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // num averageRating
    test('to test the property `averageRating`', () async {
      // TODO
    });

    // String description
    test('to test the property `description`', () async {
      // TODO
    });

    // String imageUrl
    test('to test the property `imageUrl`', () async {
      // TODO
    });

    // String link
    test('to test the property `link`', () async {
      // TODO
    });

    // String price
    test('to test the property `price`', () async {
      // TODO
    });

    // int ratingCount
    test('to test the property `ratingCount`', () async {
      // TODO
    });

    // num score
    test('to test the property `score`', () async {
      // TODO
    });


  });

}

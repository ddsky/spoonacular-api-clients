# SpoonacularApi.GetAnalyzedRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsedInstructions** | [**[GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner]**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**ingredients** | [**[GetAnalyzedRecipeInstructions200ResponseIngredientsInner]**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 
**equipment** | [**[GetAnalyzedRecipeInstructions200ResponseIngredientsInner]**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 



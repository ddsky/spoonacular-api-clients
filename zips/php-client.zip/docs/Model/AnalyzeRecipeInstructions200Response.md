# # AnalyzeRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsed_instructions** | [**\OpenAPI\Client\Model\AnalyzeRecipeInstructions200ResponseParsedInstructionsInner[]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInner.md) |  |
**ingredients** | [**\OpenAPI\Client\Model\AnalyzeRecipeInstructions200ResponseIngredientsInner[]**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  |
**equipment** | [**\OpenAPI\Client\Model\AnalyzeRecipeInstructions200ResponseIngredientsInner[]**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# spoonacular.Model.AnalyzeARecipeSearchQuery200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dishes** | [**List&lt;AnalyzeARecipeSearchQuery200ResponseDishesInner&gt;**](AnalyzeARecipeSearchQuery200ResponseDishesInner.md) |  | 
**Ingredients** | [**List&lt;AnalyzeARecipeSearchQuery200ResponseIngredientsInner&gt;**](AnalyzeARecipeSearchQuery200ResponseIngredientsInner.md) |  | 
**Cuisines** | **List&lt;string&gt;** |  | 
**Modifiers** | **List&lt;string&gt;** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


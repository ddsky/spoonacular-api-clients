# openapi.model.AddToMealPlanRequest

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **num** |  | 
**slot** | **int** |  | 
**position** | **int** |  | 
**type** | **String** |  | 
**value** | [**AddToMealPlanRequestValue**](AddToMealPlanRequestValue.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



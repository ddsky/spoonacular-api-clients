

# SearchMenuItems200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**menuItems** | [**Set&lt;SearchMenuItems200ResponseMenuItemsInner&gt;**](SearchMenuItems200ResponseMenuItemsInner.md) |  |  |
|**totalMenuItems** | **Integer** |  |  |
|**type** | **String** |  |  |
|**offset** | **Integer** |  |  |
|**number** | **Integer** |  |  |




# GetWineRecommendation200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommended_wines** | [**Vec<models::GetWineRecommendation200ResponseRecommendedWinesInner>**](getWineRecommendation_200_response_recommendedWines_inner.md) |  | 
**total_found** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



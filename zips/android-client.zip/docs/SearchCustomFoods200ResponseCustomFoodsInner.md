

# SearchCustomFoods200ResponseCustomFoodsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**servings** | [**BigDecimal**](BigDecimal.md) |  | 
**imageUrl** | **String** |  | 
**price** | [**BigDecimal**](BigDecimal.md) |  | 






# GetWinePairing200ResponseProductMatchesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**title** | **kotlin.String** |  | 
**averageRating** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**imageUrl** | **kotlin.String** |  | 
**link** | **kotlin.String** |  | 
**price** | **kotlin.String** |  | 
**ratingCount** | **kotlin.Int** |  | 
**score** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**description** | [**kotlin.Any**](.md) |  |  [optional]




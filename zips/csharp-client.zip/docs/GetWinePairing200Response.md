# spoonacular.Model.GetWinePairing200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PairedWines** | **List&lt;string&gt;** |  | 
**PairingText** | **string** |  | 
**ProductMatches** | [**List&lt;GetWinePairing200ResponseProductMatchesInner&gt;**](GetWinePairing200ResponseProductMatchesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


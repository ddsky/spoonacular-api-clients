package com.spoonacular.client.model;

import groovy.transform.Canonical
import com.spoonacular.client.model.GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Canonical
class GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount {
    
    GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric metric
    
    GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric us
}

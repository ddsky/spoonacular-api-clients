# Spoonacular.GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**[GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner]**](GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.md) |  | 



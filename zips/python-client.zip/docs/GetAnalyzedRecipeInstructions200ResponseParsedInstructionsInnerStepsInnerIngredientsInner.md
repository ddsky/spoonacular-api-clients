# GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **str** |  | 
**localized_name** | **str** |  | 
**image** | **str** |  | 

## Example

```python
from spoonacular.models.get_analyzed_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner import GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner from a JSON string
get_analyzed_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_instance = GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.from_json(json)
# print the JSON string representation of the object
print(GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.to_json())

# convert the object into a dict
get_analyzed_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_dict = get_analyzed_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_instance.to_dict()
# create an instance of GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner from a dict
get_analyzed_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_from_dict = GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.from_dict(get_analyzed_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



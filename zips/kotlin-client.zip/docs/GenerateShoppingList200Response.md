
# GenerateShoppingList200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**kotlin.collections.Set&lt;GetShoppingList200ResponseAislesInner&gt;**](GetShoppingList200ResponseAislesInner.md) |  | 
**cost** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**startDate** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**endDate** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 




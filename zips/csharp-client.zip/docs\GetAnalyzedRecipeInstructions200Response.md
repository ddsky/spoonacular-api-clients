# Org.OpenAPITools.Model.GetAnalyzedRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParsedInstructions** | [**List<GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner>**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**Ingredients** | [**List<GetAnalyzedRecipeInstructions200ResponseIngredientsInner>**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 
**Equipment** | [**List<GetAnalyzedRecipeInstructions200ResponseIngredientsInner>**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


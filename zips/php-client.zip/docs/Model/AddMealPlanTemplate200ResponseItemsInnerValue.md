# # AddMealPlanTemplate200ResponseItemsInnerValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional]
**servings** | **float** |  | [optional]
**title** | **string** |  | [optional]
**image_type** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

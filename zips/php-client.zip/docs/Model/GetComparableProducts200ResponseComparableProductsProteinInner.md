# # GetComparableProducts200ResponseComparableProductsProteinInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**difference** | **float** |  |
**id** | **int** |  |
**image** | **string** |  |
**title** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)



# GetProductInformation200ResponseIngredientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**description** | **String** |  |  [optional] |
|**name** | **String** |  |  |
|**safetyLevel** | **String** |  |  [optional] |




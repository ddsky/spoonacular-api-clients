# SpoonacularApi.AnalyzeRecipeRequest1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | [optional] 
**servings** | **Number** |  | [optional] 
**ingredients** | **[String]** |  | [optional] 
**instructions** | **String** |  | [optional] 



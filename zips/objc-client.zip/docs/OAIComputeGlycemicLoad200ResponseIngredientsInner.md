# OAIComputeGlycemicLoad200ResponseIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** |  | 
**original** | **NSString*** |  | 
**glycemicIndex** | **NSNumber*** |  | 
**glycemicLoad** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



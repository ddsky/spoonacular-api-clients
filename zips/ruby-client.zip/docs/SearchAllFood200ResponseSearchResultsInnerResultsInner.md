# OpenapiClient::SearchAllFood200ResponseSearchResultsInnerResultsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **String** |  |  |
| **name** | **String** |  |  |
| **image** | **String** |  |  |
| **link** | **String** |  |  |
| **type** | **String** |  |  |
| **relevance** | **Float** |  |  |
| **content** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchAllFood200ResponseSearchResultsInnerResultsInner.new(
  id: null,
  name: null,
  image: null,
  link: null,
  type: null,
  relevance: null,
  content: null
)
```


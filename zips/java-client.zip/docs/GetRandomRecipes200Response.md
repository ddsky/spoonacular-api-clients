

# GetRandomRecipes200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**recipes** | [**Set&lt;RecipeInformation&gt;**](RecipeInformation.md) |  |  |




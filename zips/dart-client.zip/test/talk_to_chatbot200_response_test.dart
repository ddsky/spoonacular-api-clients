//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for TalkToChatbot200Response
void main() {
  // final instance = TalkToChatbot200Response();

  group('test TalkToChatbot200Response', () {
    // String answerText
    test('to test the property `answerText`', () async {
      // TODO
    });

    // List<TalkToChatbot200ResponseMediaInner> media (default value: const [])
    test('to test the property `media`', () async {
      // TODO
    });


  });

}

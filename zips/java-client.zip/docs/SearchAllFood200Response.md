

# SearchAllFood200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**query** | **String** |  |  |
|**totalResults** | **Integer** |  |  |
|**limit** | **Integer** |  |  |
|**offset** | **Integer** |  |  |
|**searchResults** | [**Set&lt;SearchAllFood200ResponseSearchResultsInner&gt;**](SearchAllFood200ResponseSearchResultsInner.md) |  |  |




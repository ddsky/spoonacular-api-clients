# # SearchMenuItems200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menu_items** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchMenuItems200ResponseMenuItemsInner[]**](SearchMenuItems200ResponseMenuItemsInner.md) |  |
**total_menu_items** | **int** |  |
**type** | **string** |  |
**offset** | **int** |  |
**number** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

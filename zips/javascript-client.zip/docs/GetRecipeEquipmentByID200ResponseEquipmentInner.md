# Spoonacular.GetRecipeEquipmentByID200ResponseEquipmentInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | 
**name** | **String** |  | 



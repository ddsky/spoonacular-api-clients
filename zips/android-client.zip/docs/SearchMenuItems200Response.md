

# SearchMenuItems200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menuItems** | [**Set&lt;MenuItem&gt;**](MenuItem.md) |  | 
**totalMenuItems** | **Integer** |  | 
**type** | **String** |  | 
**offset** | **Integer** |  | 
**number** | **Integer** |  | 





# Org.OpenAPITools.Model.GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | 
**Amount** | **decimal?** |  | 
**Unit** | **string** |  | 
**PercentDailyNeeds** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


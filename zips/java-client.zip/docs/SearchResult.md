

# SearchResult



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**dataPoints** | [**List&lt;SearchResultDataPointsInner&gt;**](SearchResultDataPointsInner.md) |  |  [optional] |
|**image** | **String** |  |  [optional] |
|**link** | **String** |  |  [optional] |
|**name** | **String** |  |  |
|**type** | **String** |  |  [optional] |
|**kvtable** | **String** |  |  [optional] |
|**content** | **String** |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**relevance** | **BigDecimal** |  |  [optional] |






# SearchRecipes200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 





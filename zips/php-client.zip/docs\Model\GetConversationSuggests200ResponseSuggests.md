# # GetConversationSuggests200ResponseSuggests

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_** | [**\com.spoonacular.client\com.spoonacular.client.model\GetConversationSuggests200ResponseSuggestsInner[]**](GetConversationSuggests200ResponseSuggestsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

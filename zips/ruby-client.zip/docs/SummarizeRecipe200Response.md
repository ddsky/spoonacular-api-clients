# OpenapiClient::SummarizeRecipe200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **summary** | **String** |  |  |
| **title** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SummarizeRecipe200Response.new(
  id: null,
  summary: null,
  title: null
)
```


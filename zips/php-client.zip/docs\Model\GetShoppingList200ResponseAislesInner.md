# # GetShoppingList200ResponseAislesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **string** |  |
**items** | [**\com.spoonacular.client\com.spoonacular.client.model\GetShoppingList200ResponseAislesInnerItemsInner[]**](GetShoppingList200ResponseAislesInnerItemsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

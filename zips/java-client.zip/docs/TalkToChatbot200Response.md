

# TalkToChatbot200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**answerText** | **String** |  |  |
|**media** | **List&lt;Object&gt;** |  |  |






# GetAnalyzedRecipeInstructions200ResponseInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | [**BigDecimal**](BigDecimal.md) |  | 
**step** | **String** |  | 
**ingredients** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  |  [optional]
**equipment** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  |  [optional]





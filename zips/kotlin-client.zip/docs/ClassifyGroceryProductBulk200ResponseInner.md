
# ClassifyGroceryProductBulk200ResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cleanTitle** | **kotlin.String** |  | 
**image** | **kotlin.String** |  | 
**category** | **kotlin.String** |  | 
**breadcrumbs** | **kotlin.collections.List&lt;kotlin.String&gt;** |  | 
**usdaCode** | **kotlin.Int** |  | 




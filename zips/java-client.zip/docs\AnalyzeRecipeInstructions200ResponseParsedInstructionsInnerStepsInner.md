

# AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**number** | **BigDecimal** |  |  |
|**step** | **String** |  |  |
|**ingredients** | [**Set&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
|**equipment** | [**Set&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |




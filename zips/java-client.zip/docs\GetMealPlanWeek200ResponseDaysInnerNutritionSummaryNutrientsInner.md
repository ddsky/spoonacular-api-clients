

# GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  |
|**amount** | **BigDecimal** |  |  |
|**unit** | **String** |  |  |
|**percentDailyNeeds** | **BigDecimal** |  |  |




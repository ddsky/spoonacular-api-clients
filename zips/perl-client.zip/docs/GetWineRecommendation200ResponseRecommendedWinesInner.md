# WWW::OpenAPIClient::Object::GetWineRecommendation200ResponseRecommendedWinesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetWineRecommendation200ResponseRecommendedWinesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **string** |  | 
**average_rating** | **double** |  | 
**description** | **string** |  | 
**image_url** | **string** |  | 
**link** | **string** |  | 
**price** | **string** |  | 
**rating_count** | **int** |  | 
**score** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



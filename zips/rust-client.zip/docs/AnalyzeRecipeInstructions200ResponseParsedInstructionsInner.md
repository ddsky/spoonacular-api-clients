# AnalyzeRecipeInstructions200ResponseParsedInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**steps** | Option<[**Vec<crate::models::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner>**](analyzeRecipeInstructions_200_response_parsedInstructions_inner_steps_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



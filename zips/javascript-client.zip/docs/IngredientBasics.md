# SpoonacularApi.IngredientBasics

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  | 
**name** | **String** |  | 
**safetyLevel** | **String** |  | 



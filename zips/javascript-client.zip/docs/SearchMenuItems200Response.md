# SpoonacularApi.SearchMenuItems200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menuItems** | [**[SearchMenuItems200ResponseMenuItemsInner]**](SearchMenuItems200ResponseMenuItemsInner.md) |  | 
**totalMenuItems** | **Number** |  | 
**type** | **String** |  | 
**offset** | **Number** |  | 
**number** | **Number** |  | 



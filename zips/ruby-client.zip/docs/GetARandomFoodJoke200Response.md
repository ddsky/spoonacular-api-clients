# OpenapiClient::GetARandomFoodJoke200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **text** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetARandomFoodJoke200Response.new(
  text: null
)
```


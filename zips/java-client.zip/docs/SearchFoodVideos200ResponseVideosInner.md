

# SearchFoodVideos200ResponseVideosInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**title** | **String** |  |  |
|**length** | **Integer** |  |  |
|**rating** | **BigDecimal** |  |  |
|**shortTitle** | **String** |  |  |
|**thumbnail** | **String** |  |  |
|**views** | **Integer** |  |  |
|**youTubeId** | **String** |  |  |




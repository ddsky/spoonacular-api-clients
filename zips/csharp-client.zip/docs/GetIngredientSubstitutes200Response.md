# spoonacular.Model.GetIngredientSubstitutes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ingredient** | **string** |  | 
**Substitutes** | **List&lt;string&gt;** |  | 
**Message** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# # SearchSiteContent200ResponseGroceryProductsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_points** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner[]**](SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner.md) |  | [optional]
**image** | **string** |  |
**link** | **string** |  |
**name** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# OpenapiClient::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Float** |  |  |
| **name** | **String** |  |  |
| **localized_name** | **String** |  |  |
| **image** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.new(
  id: null,
  name: null,
  localized_name: null,
  image: null
)
```


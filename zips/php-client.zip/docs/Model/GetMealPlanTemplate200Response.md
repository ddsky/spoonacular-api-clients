# # GetMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**name** | **string** |  |
**days** | [**\OpenAPI\Client\Model\GetMealPlanTemplate200ResponseDaysInner[]**](GetMealPlanTemplate200ResponseDaysInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

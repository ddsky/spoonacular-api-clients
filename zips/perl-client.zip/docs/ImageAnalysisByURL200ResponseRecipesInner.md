# WWW::OpenAPIClient::Object::ImageAnalysisByURL200ResponseRecipesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ImageAnalysisByURL200ResponseRecipesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **string** |  | 
**image_type** | **string** |  | 
**url** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



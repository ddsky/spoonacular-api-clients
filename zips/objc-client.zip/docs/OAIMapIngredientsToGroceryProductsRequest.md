# OAIMapIngredientsToGroceryProductsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | **NSArray&lt;NSString*&gt;*** |  | 
**servings** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



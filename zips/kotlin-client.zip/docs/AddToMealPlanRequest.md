
# AddToMealPlanRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **date** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **slot** | **kotlin.Int** |  |  |
| **position** | **kotlin.Int** |  |  |
| **type** | **kotlin.String** |  |  |
| **&#x60;value&#x60;** | [**AddToMealPlanRequestValue**](AddToMealPlanRequestValue.md) |  |  |




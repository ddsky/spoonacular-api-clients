# Org.OpenAPITools.Model.GetIngredientInformation200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nutrients** | [**List<ParseIngredients200ResponseInnerNutritionNutrientsInner>**](ParseIngredients200ResponseInnerNutritionNutrientsInner.md) |  | 
**Properties** | [**List<ParseIngredients200ResponseInnerNutritionPropertiesInner>**](ParseIngredients200ResponseInnerNutritionPropertiesInner.md) |  | 
**CaloricBreakdown** | [**ParseIngredients200ResponseInnerNutritionCaloricBreakdown**](ParseIngredients200ResponseInnerNutritionCaloricBreakdown.md) |  | 
**WeightPerServing** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


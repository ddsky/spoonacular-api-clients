# OAISearchRecipesByIngredients200ResponseInnerMissedIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **NSString*** |  | 
**amount** | **NSNumber*** |  | 
**_id** | **NSNumber*** |  | 
**image** | **NSString*** |  | 
**meta** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**name** | **NSString*** |  | 
**original** | **NSString*** |  | 
**originalName** | **NSString*** |  | 
**unit** | **NSString*** |  | 
**unitLong** | **NSString*** |  | 
**unitShort** | **NSString*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



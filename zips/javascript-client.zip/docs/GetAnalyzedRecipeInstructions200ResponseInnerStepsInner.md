# Spoonacular.GetAnalyzedRecipeInstructions200ResponseInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Number** |  | 
**step** | **String** |  | 
**ingredients** | [**[GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner]**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | [**[GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner]**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner.md) |  | [optional] 



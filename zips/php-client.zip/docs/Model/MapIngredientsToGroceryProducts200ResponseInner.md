# # MapIngredientsToGroceryProducts200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **string** |  |
**original_name** | **string** |  |
**ingredient_image** | **string** |  |
**meta** | **string[]** |  |
**products** | [**\OpenAPI\Client\Model\MapIngredientsToGroceryProducts200ResponseInnerProductsInner[]**](MapIngredientsToGroceryProducts200ResponseInnerProductsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# GetRecipeNutritionWidgetByID200ResponseGoodInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **str** |  | 
**indented** | **bool** |  | 
**percent_of_daily_needs** | **float** |  | 
**name** | **str** |  | 

## Example

```python
from spoonacular.models.get_recipe_nutrition_widget_by_id200_response_good_inner import GetRecipeNutritionWidgetByID200ResponseGoodInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetRecipeNutritionWidgetByID200ResponseGoodInner from a JSON string
get_recipe_nutrition_widget_by_id200_response_good_inner_instance = GetRecipeNutritionWidgetByID200ResponseGoodInner.from_json(json)
# print the JSON string representation of the object
print GetRecipeNutritionWidgetByID200ResponseGoodInner.to_json()

# convert the object into a dict
get_recipe_nutrition_widget_by_id200_response_good_inner_dict = get_recipe_nutrition_widget_by_id200_response_good_inner_instance.to_dict()
# create an instance of GetRecipeNutritionWidgetByID200ResponseGoodInner from a dict
get_recipe_nutrition_widget_by_id200_response_good_inner_form_dict = get_recipe_nutrition_widget_by_id200_response_good_inner.from_dict(get_recipe_nutrition_widget_by_id200_response_good_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



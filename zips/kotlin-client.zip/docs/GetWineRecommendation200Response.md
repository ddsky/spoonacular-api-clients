
# GetWineRecommendation200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **recommendedWines** | [**kotlin.collections.Set&lt;GetWineRecommendation200ResponseRecommendedWinesInner&gt;**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  |  |
| **totalFound** | **kotlin.Int** |  |  |




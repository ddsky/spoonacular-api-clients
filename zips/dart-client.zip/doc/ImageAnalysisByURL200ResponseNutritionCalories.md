# openapi.model.ImageAnalysisByURL200ResponseNutritionCalories

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **num** |  | 
**unit** | **String** |  | 
**confidenceRange95Percent** | [**ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent**](ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.md) |  | 
**standardDeviation** | **num** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# # GetRecipeInformation200ResponseExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **string** |  |
**amount** | **float** |  |
**consitency** | **string** |  |
**id** | **int** |  |
**image** | **string** |  |
**measures** | [**\com.spoonacular.client\com.spoonacular.client.model\GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures.md) |  | [optional]
**meta** | **string[]** |  | [optional]
**name** | **string** |  |
**original** | **string** |  |
**original_name** | **string** |  |
**unit** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

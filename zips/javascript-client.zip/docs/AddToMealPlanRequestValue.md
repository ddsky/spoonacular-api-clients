# Spoonacular.AddToMealPlanRequestValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**[AddToMealPlanRequestValueIngredientsInner]**](AddToMealPlanRequestValueIngredientsInner.md) |  | 



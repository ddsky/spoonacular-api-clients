
# MapIngredientsToGroceryProducts200ResponseInnerProductsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**title** | **kotlin.String** |  | 
**upc** | **kotlin.String** |  | 




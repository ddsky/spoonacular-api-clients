# ImageAnalysisByUrl200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes_used** | **i32** |  | 
**calories** | [**models::ImageAnalysisByUrl200ResponseNutritionCalories**](imageAnalysisByURL_200_response_nutrition_calories.md) |  | 
**fat** | [**models::ImageAnalysisByUrl200ResponseNutritionCalories**](imageAnalysisByURL_200_response_nutrition_calories.md) |  | 
**protein** | [**models::ImageAnalysisByUrl200ResponseNutritionCalories**](imageAnalysisByURL_200_response_nutrition_calories.md) |  | 
**carbs** | [**models::ImageAnalysisByUrl200ResponseNutritionCalories**](imageAnalysisByURL_200_response_nutrition_calories.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



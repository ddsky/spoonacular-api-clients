# OAISearchRestaurants200ResponseRestaurantsInnerLocalHours

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operational** | [**OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational***](OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**delivery** | [**OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational***](OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**pickup** | [**OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational***](OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**dineIn** | [**OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational***](OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# openapi.model.GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**steps** | [**Set<GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner>**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional] [default to const {}]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



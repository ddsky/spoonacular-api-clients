# OAISearchSiteContent200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**OAISet&lt;OAISearchSiteContent200ResponseArticlesInner&gt;***](OAISearchSiteContent200ResponseArticlesInner.md) |  | 
**groceryProducts** | [**OAISet&lt;OAISearchSiteContent200ResponseGroceryProductsInner&gt;***](OAISearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**menuItems** | [**OAISet&lt;OAISearchSiteContent200ResponseGroceryProductsInner&gt;***](OAISearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**recipes** | [**OAISet&lt;OAISearchSiteContent200ResponseGroceryProductsInner&gt;***](OAISearchSiteContent200ResponseGroceryProductsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



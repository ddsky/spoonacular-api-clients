
# AddToMealPlanRequest1Value

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**kotlin.collections.Set&lt;AddToMealPlanRequest1ValueIngredientsInner&gt;**](AddToMealPlanRequest1ValueIngredientsInner.md) |  | 




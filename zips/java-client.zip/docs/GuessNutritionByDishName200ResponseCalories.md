

# GuessNutritionByDishName200ResponseCalories


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**confidenceRange95Percent** | [**GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent**](GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.md) |  |  |
|**standardDeviation** | **BigDecimal** |  |  |
|**unit** | **String** |  |  |
|**value** | **BigDecimal** |  |  |




# OpenapiClient::AddToMealPlanRequestValueIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AddToMealPlanRequestValueIngredientsInner.new(
  name: null
)
```


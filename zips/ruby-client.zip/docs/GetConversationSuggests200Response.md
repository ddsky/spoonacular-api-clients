# OpenapiClient::GetConversationSuggests200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **suggests** | [**GetConversationSuggests200ResponseSuggests**](GetConversationSuggests200ResponseSuggests.md) |  |  |
| **words** | **Array&lt;Object&gt;** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetConversationSuggests200Response.new(
  suggests: null,
  words: null
)
```


# # SearchRecipesByIngredients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**image** | **string** |  |
**image_type** | **string** |  |
**likes** | **int** |  |
**missed_ingredient_count** | **int** |  |
**missed_ingredients** | [**\OpenAPI\Client\Model\SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner[]**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  |
**title** | **string** |  |
**unused_ingredients** | **object[]** |  |
**used_ingredient_count** | **float** |  |
**used_ingredients** | [**\OpenAPI\Client\Model\SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner[]**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

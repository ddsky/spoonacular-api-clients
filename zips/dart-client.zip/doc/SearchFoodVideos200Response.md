# openapi.model.SearchFoodVideos200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**videos** | [**Set<SearchFoodVideos200ResponseVideosInner>**](SearchFoodVideos200ResponseVideosInner.md) |  | [default to const {}]
**totalResults** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SpoonacularApi.AddMealPlanTemplate200ResponseItemsInnerValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**servings** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 
**imageType** | **String** |  | [optional] 



# # AddMealPlanTemplate200ResponseItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**day** | **int** |  |
**slot** | **int** |  |
**position** | **int** |  |
**type** | **string** |  |
**value** | [**\com.spoonacular.client\com.spoonacular.client.model\AddMealPlanTemplate200ResponseItemsInnerValue**](AddMealPlanTemplate200ResponseItemsInnerValue.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

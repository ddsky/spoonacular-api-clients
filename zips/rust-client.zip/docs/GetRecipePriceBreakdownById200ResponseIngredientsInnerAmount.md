# GetRecipePriceBreakdownById200ResponseIngredientsInnerAmount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**models::GetRecipePriceBreakdownById200ResponseIngredientsInnerAmountMetric**](getRecipePriceBreakdownByID_200_response_ingredients_inner_amount_metric.md) |  | 
**us** | [**models::GetRecipePriceBreakdownById200ResponseIngredientsInnerAmountMetric**](getRecipePriceBreakdownByID_200_response_ingredients_inner_amount_metric.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Org.OpenAPITools.Model.GetMealPlanTemplate200ResponseDaysInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | 
**Slot** | **int?** |  | 
**Position** | **int?** |  | 
**Type** | **string** |  | 
**Value** | [**GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue**](GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


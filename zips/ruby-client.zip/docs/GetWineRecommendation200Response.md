# OpenapiClient::GetWineRecommendation200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **recommended_wines** | [**Array&lt;GetWineRecommendation200ResponseRecommendedWinesInner&gt;**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  |  |
| **total_found** | **Integer** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetWineRecommendation200Response.new(
  recommended_wines: null,
  total_found: null
)
```


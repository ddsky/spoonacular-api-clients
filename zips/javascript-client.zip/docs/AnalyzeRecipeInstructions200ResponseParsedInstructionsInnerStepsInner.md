# Spoonacular.AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Number** |  | 
**step** | **String** |  | 
**ingredients** | [**[AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | [**[AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 



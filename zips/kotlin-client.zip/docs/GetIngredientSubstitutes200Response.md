
# GetIngredientSubstitutes200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **ingredient** | **kotlin.String** |  |  |
| **substitutes** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  |
| **message** | **kotlin.String** |  |  |




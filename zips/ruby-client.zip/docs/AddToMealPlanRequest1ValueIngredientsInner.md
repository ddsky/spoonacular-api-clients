# OpenapiClient::AddToMealPlanRequest1ValueIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AddToMealPlanRequest1ValueIngredientsInner.new(
  name: null
)
```


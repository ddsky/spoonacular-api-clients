# spoonacular.Model.GetAnalyzedRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParsedInstructions** | [**List&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**Ingredients** | [**List&lt;GetAnalyzedRecipeInstructions200ResponseIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 
**Equipment** | [**List&lt;GetAnalyzedRecipeInstructions200ResponseIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# GetShoppingList200ResponseAislesInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** |  | 
**name** | **String** |  | 
**measures** | Option<[**crate::models::GetShoppingList200ResponseAislesInnerItemsInnerMeasures**](getShoppingList_200_response_aisles_inner_items_inner_measures.md)> |  | [optional]
**pantry_item** | **bool** |  | 
**aisle** | **String** |  | 
**cost** | **f32** |  | 
**ingredient_id** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



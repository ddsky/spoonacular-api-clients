
# SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **percentProtein** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **percentFat** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **percentCarbs** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




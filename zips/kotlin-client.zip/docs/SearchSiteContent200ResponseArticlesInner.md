
# SearchSiteContent200ResponseArticlesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **image** | **kotlin.String** |  |  |
| **link** | **kotlin.String** |  |  |
| **name** | **kotlin.String** |  |  |
| **dataPoints** | [**kotlin.collections.Set&lt;SearchSiteContent200ResponseArticlesInnerDataPointsInner&gt;**](SearchSiteContent200ResponseArticlesInnerDataPointsInner.md) |  |  [optional] |




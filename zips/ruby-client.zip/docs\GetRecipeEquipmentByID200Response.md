# OpenapiClient::GetRecipeEquipmentByID200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **equipment** | [**Array&lt;GetRecipeEquipmentByID200ResponseEquipmentInner&gt;**](GetRecipeEquipmentByID200ResponseEquipmentInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipeEquipmentByID200Response.new(
  equipment: null
)
```


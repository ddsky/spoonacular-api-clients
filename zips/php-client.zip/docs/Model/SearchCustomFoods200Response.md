# # SearchCustomFoods200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**custom_foods** | [**\OpenAPI\Client\Model\SearchCustomFoods200ResponseCustomFoodsInner[]**](SearchCustomFoods200ResponseCustomFoodsInner.md) |  |
**type** | **string** |  |
**offset** | **int** |  |
**number** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

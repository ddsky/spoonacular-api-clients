

# GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  |
|**name** | **String** |  |  |
|**localizedName** | **String** |  |  |
|**image** | **String** |  |  |




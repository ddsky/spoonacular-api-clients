# GetRecipeEquipmentByID200ResponseEquipmentInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **str** |  | 
**name** | **str** |  | 

## Example

```python
from spoonacular.models.get_recipe_equipment_by_id200_response_equipment_inner import GetRecipeEquipmentByID200ResponseEquipmentInner

# TODO update the JSON string below
json = "{}"
# create an instance of GetRecipeEquipmentByID200ResponseEquipmentInner from a JSON string
get_recipe_equipment_by_id200_response_equipment_inner_instance = GetRecipeEquipmentByID200ResponseEquipmentInner.from_json(json)
# print the JSON string representation of the object
print GetRecipeEquipmentByID200ResponseEquipmentInner.to_json()

# convert the object into a dict
get_recipe_equipment_by_id200_response_equipment_inner_dict = get_recipe_equipment_by_id200_response_equipment_inner_instance.to_dict()
# create an instance of GetRecipeEquipmentByID200ResponseEquipmentInner from a dict
get_recipe_equipment_by_id200_response_equipment_inner_form_dict = get_recipe_equipment_by_id200_response_equipment_inner.from_dict(get_recipe_equipment_by_id200_response_equipment_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SpoonacularApi.AnalyzeARecipeSearchQuery200ResponseDishesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | 
**name** | **String** |  | 



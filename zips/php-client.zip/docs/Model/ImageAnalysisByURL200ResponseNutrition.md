# # ImageAnalysisByURL200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes_used** | **int** |  |
**calories** | [**\OpenAPI\Client\Model\ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |
**fat** | [**\OpenAPI\Client\Model\ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |
**protein** | [**\OpenAPI\Client\Model\ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |
**carbs** | [**\OpenAPI\Client\Model\ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

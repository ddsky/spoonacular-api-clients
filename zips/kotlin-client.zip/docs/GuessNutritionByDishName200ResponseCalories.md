
# GuessNutritionByDishName200ResponseCalories

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **confidenceRange95Percent** | [**GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent**](GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.md) |  |  |
| **standardDeviation** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **unit** | **kotlin.String** |  |  |
| **&#x60;value&#x60;** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




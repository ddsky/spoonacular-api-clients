# ProductInformationCredits

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | Option<**String**> |  | [optional]
**link** | Option<**String**> |  | [optional]
**image** | Option<**String**> |  | [optional]
**image_link** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



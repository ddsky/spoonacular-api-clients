# # SearchAllFood200ResponseSearchResultsInnerResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  |
**name** | **string** |  |
**image** | **string** |  |
**link** | **string** |  |
**type** | **string** |  |
**relevance** | **float** |  |
**content** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

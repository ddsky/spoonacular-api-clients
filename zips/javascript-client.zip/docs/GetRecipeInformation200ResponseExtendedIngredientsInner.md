# SpoonacularApi.GetRecipeInformation200ResponseExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | **Number** |  | 
**consitency** | **String** |  | 
**id** | **Number** |  | 
**image** | **String** |  | 
**measures** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures.md) |  | [optional] 
**meta** | **[String]** |  | [optional] 
**name** | **String** |  | 
**original** | **String** |  | 
**originalName** | **String** |  | 
**unit** | **String** |  | 



# # GetShoppingList200ResponseAislesInnerItemsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | [**\OpenAPI\Client\Model\GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  |
**metric** | [**\OpenAPI\Client\Model\GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  |
**us** | [**\OpenAPI\Client\Model\GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

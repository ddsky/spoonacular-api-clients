//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ClassifyGroceryProduct200Response
void main() {
  // final instance = ClassifyGroceryProduct200Response();

  group('test ClassifyGroceryProduct200Response', () {
    // String cleanTitle
    test('to test the property `cleanTitle`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String category
    test('to test the property `category`', () async {
      // TODO
    });

    // List<String> breadcrumbs (default value: const [])
    test('to test the property `breadcrumbs`', () async {
      // TODO
    });

    // int usdaCode
    test('to test the property `usdaCode`', () async {
      // TODO
    });


  });

}

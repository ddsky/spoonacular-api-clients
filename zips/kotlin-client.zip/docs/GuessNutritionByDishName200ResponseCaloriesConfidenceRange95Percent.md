
# GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **max** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **min** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




# OAIGetIngredientInformation200ResponseNutrition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**OAISet&lt;OAIParseIngredients200ResponseInnerNutritionNutrientsInner&gt;***](OAIParseIngredients200ResponseInnerNutritionNutrientsInner.md) |  | 
**properties** | [**OAISet&lt;OAIParseIngredients200ResponseInnerNutritionPropertiesInner&gt;***](OAIParseIngredients200ResponseInnerNutritionPropertiesInner.md) |  | 
**caloricBreakdown** | [**OAIParseIngredients200ResponseInnerNutritionCaloricBreakdown***](OAIParseIngredients200ResponseInnerNutritionCaloricBreakdown.md) |  | 
**weightPerServing** | [**OAIParseIngredients200ResponseInnerNutritionWeightPerServing***](OAIParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



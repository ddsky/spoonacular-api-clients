

# AddToMealPlanRequest1



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**date** | **BigDecimal** |  |  |
|**slot** | **Integer** |  |  |
|**position** | **Integer** |  |  |
|**type** | **String** |  |  |
|**value** | [**AddToMealPlanRequest1Value**](AddToMealPlanRequest1Value.md) |  |  |




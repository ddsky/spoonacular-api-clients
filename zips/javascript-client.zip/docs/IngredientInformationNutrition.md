# Spoonacular.IngredientInformationNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**[SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner]**](SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner.md) |  | 
**properties** | [**[IngredientInformationNutritionPropertiesInner]**](IngredientInformationNutritionPropertiesInner.md) |  | 
**caloricBreakdown** | [**SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown**](SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown.md) |  | 
**weightPerServing** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal.md) |  | 



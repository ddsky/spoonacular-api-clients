# Org.OpenAPITools.Model.SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Aisle** | **string** |  | 
**Amount** | **decimal?** |  | 
**Id** | **int?** |  | 
**Image** | **string** |  | 
**Meta** | **List<string>** |  | [optional] 
**Name** | **string** |  | 
**Original** | **string** |  | 
**OriginalName** | **string** |  | 
**Unit** | **string** |  | 
**UnitLong** | **string** |  | 
**UnitShort** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# spoonacular.Model.IngredientSearch200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Results** | [**List&lt;IngredientSearch200ResponseResultsInner&gt;**](IngredientSearch200ResponseResultsInner.md) |  | 
**Offset** | **int** |  | 
**Number** | **int** |  | 
**TotalResults** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


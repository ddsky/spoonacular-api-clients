
# AnalyzeARecipeSearchQuery200ResponseIngredientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **image** | **kotlin.String** |  |  |
| **include** | **kotlin.Boolean** |  |  |
| **name** | **kotlin.String** |  |  |




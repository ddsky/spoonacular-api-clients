

# TalkToChatbot200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answerText** | **String** |  | 
**media** | [**List&lt;TalkToChatbot200ResponseMediaInner&gt;**](TalkToChatbot200ResponseMediaInner.md) |  | 





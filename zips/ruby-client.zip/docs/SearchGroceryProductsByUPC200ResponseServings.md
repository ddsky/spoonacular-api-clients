# OpenapiClient::SearchGroceryProductsByUPC200ResponseServings

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **number** | **Float** |  |  |
| **size** | **Float** |  |  |
| **unit** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGroceryProductsByUPC200ResponseServings.new(
  number: null,
  size: null,
  unit: null
)
```


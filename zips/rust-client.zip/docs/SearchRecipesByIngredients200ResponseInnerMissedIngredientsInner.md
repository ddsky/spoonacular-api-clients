# SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | **f64** |  | 
**id** | **i32** |  | 
**image** | **String** |  | 
**meta** | Option<**Vec<String>**> |  | [optional]
**name** | **String** |  | 
**extended_name** | Option<**String**> |  | [optional]
**original** | **String** |  | 
**original_name** | **String** |  | 
**unit** | **String** |  | 
**unit_long** | **String** |  | 
**unit_short** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | [**BigDecimal**](BigDecimal.md) |  | 
**step** | **String** |  | 
**ingredients** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional]
**equipment** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional]





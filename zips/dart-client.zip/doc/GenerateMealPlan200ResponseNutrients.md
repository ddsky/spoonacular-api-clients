# openapi.model.GenerateMealPlan200ResponseNutrients

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **num** |  | 
**carbohydrates** | **num** |  | 
**fat** | **num** |  | 
**protein** | **num** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



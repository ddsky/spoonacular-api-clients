# SpoonacularApi.GetWinePairing200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **[String]** |  | 
**pairingText** | **String** |  | 
**productMatches** | [**[GetWinePairing200ResponseProductMatchesInner]**](GetWinePairing200ResponseProductMatchesInner.md) |  | 



# OpenapiClient::MenuItemServings

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **number** | **Float** |  |  |
| **size** | **Float** |  |  |
| **unit** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::MenuItemServings.new(
  number: null,
  size: null,
  unit: null
)
```


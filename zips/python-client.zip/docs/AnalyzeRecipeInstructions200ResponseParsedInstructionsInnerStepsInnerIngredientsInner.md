# AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **str** |  | 
**localized_name** | **str** |  | 
**image** | **str** |  | 

## Example

```python
from spoonacular.models.analyze_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner import AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner

# TODO update the JSON string below
json = "{}"
# create an instance of AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner from a JSON string
analyze_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_instance = AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.from_json(json)
# print the JSON string representation of the object
print(AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.to_json())

# convert the object into a dict
analyze_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_dict = analyze_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_instance.to_dict()
# create an instance of AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner from a dict
analyze_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_from_dict = AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner.from_dict(analyze_recipe_instructions200_response_parsed_instructions_inner_steps_inner_ingredients_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



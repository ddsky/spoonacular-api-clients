# Org.OpenAPITools.Model.SearchSiteContent200ResponseGroceryProductsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DataPoints** | [**List<SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner>**](SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner.md) |  | [optional] 
**Image** | **string** |  | 
**Link** | **string** |  | 
**Name** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


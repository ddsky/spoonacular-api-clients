# OpenapiClient::SearchRestaurants200ResponseRestaurantsInnerLocalHours

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **operational** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] |
| **delivery** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] |
| **pickup** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] |
| **dine_in** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRestaurants200ResponseRestaurantsInnerLocalHours.new(
  operational: null,
  delivery: null,
  pickup: null,
  dine_in: null
)
```


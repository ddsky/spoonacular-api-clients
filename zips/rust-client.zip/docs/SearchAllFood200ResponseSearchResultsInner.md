# SearchAllFood200ResponseSearchResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**total_results** | **i32** |  | 
**results** | Option<[**Vec<models::SearchAllFood200ResponseSearchResultsInnerResultsInner>**](searchAllFood_200_response_searchResults_inner_results_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



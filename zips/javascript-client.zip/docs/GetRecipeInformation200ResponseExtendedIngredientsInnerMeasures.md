# SpoonacularApi.GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.md) |  | 
**us** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.md) |  | 



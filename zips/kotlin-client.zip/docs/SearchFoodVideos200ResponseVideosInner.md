
# SearchFoodVideos200ResponseVideosInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** |  |  |
| **length** | **kotlin.Int** |  |  |
| **rating** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **shortTitle** | **kotlin.String** |  |  |
| **thumbnail** | **kotlin.String** |  |  |
| **views** | **kotlin.Int** |  |  |
| **youTubeId** | **kotlin.String** |  |  |




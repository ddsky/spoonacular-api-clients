

# MapIngredientsToGroceryProductsRequest



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**ingredients** | **List&lt;String&gt;** |  |  |
|**servings** | **BigDecimal** |  |  |




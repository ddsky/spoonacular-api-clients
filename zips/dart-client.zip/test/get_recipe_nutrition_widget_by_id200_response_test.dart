//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GetRecipeNutritionWidgetByID200Response
void main() {
  // final instance = GetRecipeNutritionWidgetByID200Response();

  group('test GetRecipeNutritionWidgetByID200Response', () {
    // String calories
    test('to test the property `calories`', () async {
      // TODO
    });

    // String carbs
    test('to test the property `carbs`', () async {
      // TODO
    });

    // String fat
    test('to test the property `fat`', () async {
      // TODO
    });

    // String protein
    test('to test the property `protein`', () async {
      // TODO
    });

    // Set<GetRecipeNutritionWidgetByID200ResponseBadInner> bad (default value: const {})
    test('to test the property `bad`', () async {
      // TODO
    });

    // Set<GetRecipeNutritionWidgetByID200ResponseGoodInner> good (default value: const {})
    test('to test the property `good`', () async {
      // TODO
    });


  });

}



# GetAnalyzedRecipeInstructions200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**steps** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInner.md) |  |  [optional]





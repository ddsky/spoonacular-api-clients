# # GuessNutritionByDishName200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**\com.spoonacular.client\com.spoonacular.client.model\GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  |
**carbs** | [**\com.spoonacular.client\com.spoonacular.client.model\GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  |
**fat** | [**\com.spoonacular.client\com.spoonacular.client.model\GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  |
**protein** | [**\com.spoonacular.client\com.spoonacular.client.model\GuessNutritionByDishName200ResponseCalories**](GuessNutritionByDishName200ResponseCalories.md) |  |
**recipes_used** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

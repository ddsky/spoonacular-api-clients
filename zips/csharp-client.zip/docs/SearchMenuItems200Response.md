# Org.OpenAPITools.Model.SearchMenuItems200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MenuItems** | [**List<SearchMenuItems200ResponseMenuItemsInner>**](SearchMenuItems200ResponseMenuItemsInner.md) |  | 
**TotalMenuItems** | **int?** |  | 
**Type** | **string** |  | 
**Offset** | **int?** |  | 
**Number** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GenerateMealPlan200ResponseNutrients
void main() {
  // final instance = GenerateMealPlan200ResponseNutrients();

  group('test GenerateMealPlan200ResponseNutrients', () {
    // num calories
    test('to test the property `calories`', () async {
      // TODO
    });

    // num carbohydrates
    test('to test the property `carbohydrates`', () async {
      // TODO
    });

    // num fat
    test('to test the property `fat`', () async {
      // TODO
    });

    // num protein
    test('to test the property `protein`', () async {
      // TODO
    });


  });

}

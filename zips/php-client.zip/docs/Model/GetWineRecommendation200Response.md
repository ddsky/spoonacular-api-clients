# # GetWineRecommendation200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommended_wines** | [**\OpenAPI\Client\Model\GetWineRecommendation200ResponseRecommendedWinesInner[]**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  |
**total_found** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

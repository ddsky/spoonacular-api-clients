# openapi.model.GetWineRecommendation200ResponseRecommendedWinesInner

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **String** |  | 
**averageRating** | **num** |  | 
**description** | **String** |  | 
**imageUrl** | **String** |  | 
**link** | **String** |  | 
**price** | **String** |  | 
**ratingCount** | **int** |  | 
**score** | **num** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



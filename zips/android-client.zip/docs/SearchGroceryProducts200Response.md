

# SearchGroceryProducts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**Set&lt;AutocompleteRecipeSearch200ResponseInner&gt;**](AutocompleteRecipeSearch200ResponseInner.md) |  | 
**totalProducts** | **Integer** |  | 
**type** | **String** |  | 
**offset** | **Integer** |  | 
**number** | **Integer** |  | 





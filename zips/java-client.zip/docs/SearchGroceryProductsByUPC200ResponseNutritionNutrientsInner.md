

# SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  |
|**amount** | **BigDecimal** |  |  |
|**unit** | **String** |  |  |
|**percentOfDailyNeeds** | **BigDecimal** |  |  |




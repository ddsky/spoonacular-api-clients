
# GetAnalyzedRecipeInstructions200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **parsedInstructions** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner.md) |  |  |
| **ingredients** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  |  |
| **equipment** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  |  |




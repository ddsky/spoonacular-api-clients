# # GetComparableProducts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comparable_products** | [**\com.spoonacular.client\com.spoonacular.client.model\GetComparableProducts200ResponseComparableProducts**](GetComparableProducts200ResponseComparableProducts.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# GetComparableProducts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comparable_products** | [**models::GetComparableProducts200ResponseComparableProducts**](getComparableProducts_200_response_comparableProducts.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



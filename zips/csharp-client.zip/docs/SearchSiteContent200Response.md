# Org.OpenAPITools.Model.SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Articles** | [**List<SearchSiteContent200ResponseArticlesInner>**](SearchSiteContent200ResponseArticlesInner.md) |  | 
**GroceryProducts** | [**List<SearchSiteContent200ResponseGroceryProductsInner>**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**MenuItems** | [**List<SearchSiteContent200ResponseGroceryProductsInner>**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**Recipes** | [**List<SearchSiteContent200ResponseGroceryProductsInner>**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


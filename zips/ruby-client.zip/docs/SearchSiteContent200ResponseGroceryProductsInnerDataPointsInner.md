# OpenapiClient::SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **key** | **String** |  |  |
| **value** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner.new(
  key: null,
  value: null
)
```


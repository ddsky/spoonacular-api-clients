# SearchAllFood200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **String** |  | 
**total_results** | **i32** |  | 
**limit** | **i32** |  | 
**offset** | **i32** |  | 
**search_results** | [**Vec<crate::models::SearchAllFood200ResponseSearchResultsInner>**](searchAllFood_200_response_searchResults_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



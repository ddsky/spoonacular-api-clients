# Org.OpenAPITools.Model.GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nutrients** | [**List<GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner>**](GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


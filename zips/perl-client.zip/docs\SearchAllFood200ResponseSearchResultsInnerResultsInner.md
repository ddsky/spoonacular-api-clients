# WWW::OpenAPIClient::Object::SearchAllFood200ResponseSearchResultsInnerResultsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchAllFood200ResponseSearchResultsInnerResultsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | 
**name** | **string** |  | 
**image** | **string** |  | 
**link** | **string** |  | 
**type** | **string** |  | 
**relevance** | **double** |  | 
**content** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



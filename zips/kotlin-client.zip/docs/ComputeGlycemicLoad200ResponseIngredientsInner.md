
# ComputeGlycemicLoad200ResponseIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**original** | **kotlin.String** |  | 
**glycemicIndex** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**glycemicLoad** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 




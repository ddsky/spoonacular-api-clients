# OpenapiClient::ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **min** | **Float** |  |  |
| **max** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.new(
  min: null,
  max: null
)
```




# AddToMealPlanRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** | The username. | 
**hash** | **String** | The private hash for the username. | 





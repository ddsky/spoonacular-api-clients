# GetRecipeTasteById200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | **f32** |  | 
**saltiness** | **f32** |  | 
**sourness** | **f32** |  | 
**bitterness** | **f32** |  | 
**savoriness** | **f32** |  | 
**fattiness** | **f32** |  | 
**spiciness** | **f32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# spoonacular.Model.GetComparableProducts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ComparableProducts** | [**GetComparableProducts200ResponseComparableProducts**](GetComparableProducts200ResponseComparableProducts.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


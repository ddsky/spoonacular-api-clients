# Spoonacular.SearchResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | [optional] 
**link** | **String** |  | [optional] 
**name** | **String** |  | 
**type** | **String** |  | [optional] 
**kvtable** | **String** |  | [optional] 
**content** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**relevance** | **Number** |  | [optional] 



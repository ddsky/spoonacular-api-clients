# # GetMealPlanWeek200ResponseDaysInnerNutritionSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\com.spoonacular.client\com.spoonacular.client.model\GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner[]**](GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)


# AddToMealPlanRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **kotlin.String** | The username. | 
**hash** | **kotlin.String** | The private hash for the username. | 




# OpenapiClient::ParseIngredients200ResponseInnerNutritionPropertiesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **amount** | **Float** |  |  |
| **unit** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ParseIngredients200ResponseInnerNutritionPropertiesInner.new(
  name: null,
  amount: null,
  unit: null
)
```


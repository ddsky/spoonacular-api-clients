# Spoonacular.MapIngredientsToGroceryProducts200ResponseInnerProductsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**upc** | **String** |  | 



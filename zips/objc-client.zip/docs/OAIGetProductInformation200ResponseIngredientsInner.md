# OAIGetProductInformation200ResponseIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_description** | [**OAIAnyType***](.md) |  | [optional] 
**name** | **NSString*** |  | 
**safetyLevel** | [**OAIAnyType***](.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



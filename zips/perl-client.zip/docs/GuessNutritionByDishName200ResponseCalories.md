# WWW::OpenAPIClient::Object::GuessNutritionByDishName200ResponseCalories

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GuessNutritionByDishName200ResponseCalories;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confidence_range95_percent** | [**GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent**](GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.md) |  | 
**standard_deviation** | **double** |  | 
**unit** | **string** |  | 
**value** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_protein** | **double** |  | 
**percent_fat** | **double** |  | 
**percent_carbs** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# # GetShoppingList200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**\OpenAPI\Client\Model\GetShoppingList200ResponseAislesInner[]**](GetShoppingList200ResponseAislesInner.md) |  |
**cost** | **float** |  |
**start_date** | **float** |  |
**end_date** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

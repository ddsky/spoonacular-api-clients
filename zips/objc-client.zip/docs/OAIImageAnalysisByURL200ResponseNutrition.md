# OAIImageAnalysisByURL200ResponseNutrition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipesUsed** | **NSNumber*** |  | 
**calories** | [**OAIImageAnalysisByURL200ResponseNutritionCalories***](OAIImageAnalysisByURL200ResponseNutritionCalories.md) |  | 
**fat** | [**OAIImageAnalysisByURL200ResponseNutritionCalories***](OAIImageAnalysisByURL200ResponseNutritionCalories.md) |  | 
**protein** | [**OAIImageAnalysisByURL200ResponseNutritionCalories***](OAIImageAnalysisByURL200ResponseNutritionCalories.md) |  | 
**carbs** | [**OAIImageAnalysisByURL200ResponseNutritionCalories***](OAIImageAnalysisByURL200ResponseNutritionCalories.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SearchMenuItems200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menu_items** | [**Vec<models::SearchMenuItems200ResponseMenuItemsInner>**](searchMenuItems_200_response_menuItems_inner.md) |  | 
**total_menu_items** | **i32** |  | 
**r#type** | **String** |  | 
**offset** | **i32** |  | 
**number** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



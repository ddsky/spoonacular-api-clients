
# ImageAnalysisByURL200ResponseNutritionCalories

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **&#x60;value&#x60;** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **unit** | **kotlin.String** |  |  |
| **confidenceRange95Percent** | [**ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent**](ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.md) |  |  |
| **standardDeviation** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




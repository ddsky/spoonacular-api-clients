
# SearchCustomFoods200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **customFoods** | [**kotlin.collections.Set&lt;SearchCustomFoods200ResponseCustomFoodsInner&gt;**](SearchCustomFoods200ResponseCustomFoodsInner.md) |  |  |
| **type** | **kotlin.String** |  |  |
| **offset** | **kotlin.Int** |  |  |
| **number** | **kotlin.Int** |  |  |




# SpoonacularApi.SearchCustomFoods200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customFoods** | [**[SearchCustomFoods200ResponseCustomFoodsInner]**](SearchCustomFoods200ResponseCustomFoodsInner.md) |  | 
**type** | **String** |  | 
**offset** | **Number** |  | 
**number** | **Number** |  | 



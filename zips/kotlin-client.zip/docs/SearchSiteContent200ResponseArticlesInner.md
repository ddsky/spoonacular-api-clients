
# SearchSiteContent200ResponseArticlesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **kotlin.String** |  | 
**link** | **kotlin.String** |  | 
**name** | **kotlin.String** |  | 
**dataPoints** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) |  |  [optional]




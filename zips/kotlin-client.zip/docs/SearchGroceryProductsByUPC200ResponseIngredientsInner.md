
# SearchGroceryProductsByUPC200ResponseIngredientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  |
| **description** | **kotlin.String** |  |  [optional] |
| **safetyLevel** | **kotlin.String** |  |  [optional] |






# ParseIngredients200ResponseInnerNutritionWeightPerServing


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**amount** | **BigDecimal** |  |  |
|**unit** | **String** |  |  |




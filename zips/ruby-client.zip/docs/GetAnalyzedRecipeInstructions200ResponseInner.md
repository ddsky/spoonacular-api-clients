# OpenapiClient::GetAnalyzedRecipeInstructions200ResponseInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **steps** | [**Array&lt;GetAnalyzedRecipeInstructions200ResponseInnerStepsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseInnerStepsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetAnalyzedRecipeInstructions200ResponseInner.new(
  name: null,
  steps: null
)
```


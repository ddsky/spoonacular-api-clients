
# GetRandomRecipes200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **recipes** | [**kotlin.collections.Set&lt;RecipeInformation&gt;**](RecipeInformation.md) |  |  |




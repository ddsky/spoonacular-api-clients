
# AnalyzeRecipeInstructions200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsedInstructions** | [**kotlin.collections.Set&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**ingredients** | [**kotlin.collections.Set&lt;AnalyzeRecipeInstructions200ResponseIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 
**equipment** | [**kotlin.collections.Set&lt;AnalyzeRecipeInstructions200ResponseIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 




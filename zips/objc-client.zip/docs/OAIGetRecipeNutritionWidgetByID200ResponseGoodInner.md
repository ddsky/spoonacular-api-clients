# OAIGetRecipeNutritionWidgetByID200ResponseGoodInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **NSString*** |  | 
**indented** | **NSNumber*** |  | 
**percentOfDailyNeeds** | **NSNumber*** |  | 
**name** | **NSString*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



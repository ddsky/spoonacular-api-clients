# Org.OpenAPITools.Model.GetWinePairing200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PairedWines** | **List<string>** |  | 
**PairingText** | **string** |  | 
**ProductMatches** | [**List<GetWinePairing200ResponseProductMatchesInner>**](GetWinePairing200ResponseProductMatchesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


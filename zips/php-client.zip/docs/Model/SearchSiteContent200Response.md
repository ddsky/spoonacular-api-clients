# # SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**\OpenAPI\Client\Model\SearchSiteContent200ResponseArticlesInner[]**](SearchSiteContent200ResponseArticlesInner.md) |  |
**grocery_products** | [**\OpenAPI\Client\Model\SearchSiteContent200ResponseGroceryProductsInner[]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  |
**menu_items** | [**\OpenAPI\Client\Model\SearchSiteContent200ResponseGroceryProductsInner[]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  |
**recipes** | [**\OpenAPI\Client\Model\SearchSiteContent200ResponseGroceryProductsInner[]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

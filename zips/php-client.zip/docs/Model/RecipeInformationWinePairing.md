# # RecipeInformationWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paired_wines** | **string[]** |  | [optional]
**pairing_text** | **string** |  | [optional]
**product_matches** | [**\OpenAPI\Client\Model\RecipeInformationWinePairingProductMatchesInner[]**](RecipeInformationWinePairingProductMatchesInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

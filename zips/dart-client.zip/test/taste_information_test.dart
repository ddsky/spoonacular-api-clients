//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for TasteInformation
void main() {
  // final instance = TasteInformation();

  group('test TasteInformation', () {
    // num sweetness
    test('to test the property `sweetness`', () async {
      // TODO
    });

    // num saltiness
    test('to test the property `saltiness`', () async {
      // TODO
    });

    // num sourness
    test('to test the property `sourness`', () async {
      // TODO
    });

    // num bitterness
    test('to test the property `bitterness`', () async {
      // TODO
    });

    // num savoriness
    test('to test the property `savoriness`', () async {
      // TODO
    });

    // num fattiness
    test('to test the property `fattiness`', () async {
      // TODO
    });

    // num spiciness
    test('to test the property `spiciness`', () async {
      // TODO
    });


  });

}

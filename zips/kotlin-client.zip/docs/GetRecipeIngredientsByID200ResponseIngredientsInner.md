
# GetRecipeIngredientsByID200ResponseIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **kotlin.String** |  | 
**name** | **kotlin.String** |  | 
**amount** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.md) |  |  [optional]






# SearchResultDataPointsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | 
**value** | [**OasAnyTypeNotMapped**](.md) |  | 
**show** | **Boolean** |  |  [optional]





# spoonacular.Model.AddToMealPlanRequest1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Date** | **decimal** |  | 
**Slot** | **int** |  | 
**Position** | **int** |  | 
**Type** | **string** |  | 
**Value** | [**AddToMealPlanRequest1Value**](AddToMealPlanRequest1Value.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


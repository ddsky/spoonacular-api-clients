# Org.OpenAPITools.Model.GetSimilarRecipes200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | 
**Title** | **string** |  | 
**ImageType** | **string** |  | 
**ReadyInMinutes** | **int?** |  | 
**Servings** | **decimal?** |  | 
**SourceUrl** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


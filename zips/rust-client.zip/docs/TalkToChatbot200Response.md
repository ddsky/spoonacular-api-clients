# TalkToChatbot200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answer_text** | **String** |  | 
**media** | [**Vec<models::TalkToChatbot200ResponseMediaInner>**](talkToChatbot_200_response_media_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



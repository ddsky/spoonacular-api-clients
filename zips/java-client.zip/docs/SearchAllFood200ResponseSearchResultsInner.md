

# SearchAllFood200ResponseSearchResultsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  |
|**totalResults** | **Integer** |  |  |
|**results** | [**Set&lt;SearchAllFood200ResponseSearchResultsInnerResultsInner&gt;**](SearchAllFood200ResponseSearchResultsInnerResultsInner.md) |  |  [optional] |




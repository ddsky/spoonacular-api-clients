# OAIGetComparableProducts200ResponseComparableProducts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **NSArray&lt;NSObject*&gt;*** |  | 
**likes** | **NSArray&lt;NSObject*&gt;*** |  | 
**price** | **NSArray&lt;NSObject*&gt;*** |  | 
**protein** | [**OAISet&lt;OAIGetComparableProducts200ResponseComparableProductsProteinInner&gt;***](OAIGetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**spoonacularScore** | [**OAISet&lt;OAIGetComparableProducts200ResponseComparableProductsProteinInner&gt;***](OAIGetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**sugar** | **NSArray&lt;NSObject*&gt;*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# GetRecipePriceBreakdownByID200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**ingredients** | [**Set&lt;GetRecipePriceBreakdownByID200ResponseIngredientsInner&gt;**](GetRecipePriceBreakdownByID200ResponseIngredientsInner.md) |  |  |
|**totalCost** | **BigDecimal** |  |  |
|**totalCostPerServing** | **BigDecimal** |  |  |




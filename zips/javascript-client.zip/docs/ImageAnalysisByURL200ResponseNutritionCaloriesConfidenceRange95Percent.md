# SpoonacularApi.ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | **Number** |  | 
**max** | **Number** |  | 



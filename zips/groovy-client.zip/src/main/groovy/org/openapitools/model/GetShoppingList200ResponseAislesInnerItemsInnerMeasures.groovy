package org.openapitools.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.model.ParseIngredients200ResponseInnerNutritionWeightPerServing;

@Canonical
class GetShoppingList200ResponseAislesInnerItemsInnerMeasures {
    
    ParseIngredients200ResponseInnerNutritionWeightPerServing original
    
    ParseIngredients200ResponseInnerNutritionWeightPerServing metric
    
    ParseIngredients200ResponseInnerNutritionWeightPerServing us
}

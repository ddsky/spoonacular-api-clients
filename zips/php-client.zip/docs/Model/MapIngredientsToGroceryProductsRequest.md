# # MapIngredientsToGroceryProductsRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | **string[]** |  |
**servings** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

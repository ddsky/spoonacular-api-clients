# AddMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**items** | [**Vec<crate::models::AddMealPlanTemplate200ResponseItemsInner>**](addMealPlanTemplate_200_response_items_inner.md) |  | 
**publish_as_public** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# # ImageAnalysisByURL200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition** | [**\com.spoonacular.client\com.spoonacular.client.model\ImageAnalysisByURL200ResponseNutrition**](ImageAnalysisByURL200ResponseNutrition.md) |  |
**category** | [**\com.spoonacular.client\com.spoonacular.client.model\ImageAnalysisByURL200ResponseCategory**](ImageAnalysisByURL200ResponseCategory.md) |  |
**recipes** | [**\com.spoonacular.client\com.spoonacular.client.model\ImageAnalysisByURL200ResponseRecipesInner[]**](ImageAnalysisByURL200ResponseRecipesInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)



# GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**likes** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**price** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**protein** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**spoonacularScore** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 
**sugar** | [**List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  | 





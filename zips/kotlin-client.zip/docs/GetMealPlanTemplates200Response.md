
# GetMealPlanTemplates200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**kotlin.collections.Set&lt;GetAnalyzedRecipeInstructions200ResponseIngredientsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  | 





# SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **monday** | **kotlin.String** |  |  [optional] |
| **tuesday** | **kotlin.String** |  |  [optional] |
| **wednesday** | **kotlin.String** |  |  [optional] |
| **thursday** | **kotlin.String** |  |  [optional] |
| **friday** | **kotlin.String** |  |  [optional] |
| **saturday** | **kotlin.String** |  |  [optional] |
| **sunday** | **kotlin.String** |  |  [optional] |




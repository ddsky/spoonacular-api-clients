
# SearchResultDataPointsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **key** | **kotlin.String** |  |  |
| **&#x60;value&#x60;** | [**kotlin.Any**](.md) |  |  |
| **show** | **kotlin.Boolean** |  |  [optional] |




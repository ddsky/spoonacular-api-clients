//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchFoodVideos200ResponseVideosInner
void main() {
  // final instance = SearchFoodVideos200ResponseVideosInner();

  group('test SearchFoodVideos200ResponseVideosInner', () {
    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // int length
    test('to test the property `length`', () async {
      // TODO
    });

    // num rating
    test('to test the property `rating`', () async {
      // TODO
    });

    // String shortTitle
    test('to test the property `shortTitle`', () async {
      // TODO
    });

    // String thumbnail
    test('to test the property `thumbnail`', () async {
      // TODO
    });

    // int views
    test('to test the property `views`', () async {
      // TODO
    });

    // String youTubeId
    test('to test the property `youTubeId`', () async {
      // TODO
    });


  });

}

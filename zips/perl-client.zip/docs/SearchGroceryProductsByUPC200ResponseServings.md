# WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseServings

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseServings;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **double** |  | 
**size** | **double** |  | 
**unit** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



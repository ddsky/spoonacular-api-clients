# RecipeInformationWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paired_wines** | Option<**Vec<String>**> |  | [optional]
**pairing_text** | Option<**String**> |  | [optional]
**product_matches** | Option<[**Vec<models::RecipeInformationWinePairingProductMatchesInner>**](RecipeInformation_winePairing_productMatches_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



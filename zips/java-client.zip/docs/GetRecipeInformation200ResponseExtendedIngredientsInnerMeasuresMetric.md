

# GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**amount** | **BigDecimal** |  |  |
|**unitLong** | **String** |  |  |
|**unitShort** | **String** |  |  |




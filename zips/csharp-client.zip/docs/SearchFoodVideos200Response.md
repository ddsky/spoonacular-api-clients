# spoonacular.Model.SearchFoodVideos200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Videos** | [**List&lt;SearchFoodVideos200ResponseVideosInner&gt;**](SearchFoodVideos200ResponseVideosInner.md) |  | 
**TotalResults** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# # AnalyzeRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsed_instructions** | [**\com.spoonacular.client\com.spoonacular.client.model\AnalyzeRecipeInstructions200ResponseParsedInstructionsInner[]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInner.md) |  |
**ingredients** | [**\com.spoonacular.client\com.spoonacular.client.model\AnalyzeRecipeInstructions200ResponseIngredientsInner[]**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  |
**equipment** | [**\com.spoonacular.client\com.spoonacular.client.model\AnalyzeRecipeInstructions200ResponseIngredientsInner[]**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

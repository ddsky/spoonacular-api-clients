# OpenapiClient::ImageAnalysisByURL200ResponseCategory

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **probability** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ImageAnalysisByURL200ResponseCategory.new(
  name: null,
  probability: null
)
```


# OpenapiClient::GetMealPlanWeek200ResponseDaysInnerItemsInnerValue

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **servings** | **Float** |  |  |
| **id** | **Float** |  |  |
| **title** | **String** |  |  |
| **image_type** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetMealPlanWeek200ResponseDaysInnerItemsInnerValue.new(
  servings: null,
  id: null,
  title: null,
  image_type: null
)
```


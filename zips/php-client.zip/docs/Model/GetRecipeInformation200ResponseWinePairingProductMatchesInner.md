# # GetRecipeInformation200ResponseWinePairingProductMatchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**title** | **string** |  |
**description** | **string** |  |
**price** | **string** |  |
**image_url** | **string** |  |
**average_rating** | **float** |  |
**rating_count** | **int** |  |
**score** | **float** |  |
**link** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

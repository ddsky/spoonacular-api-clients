//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchGroceryProducts200Response
void main() {
  // final instance = SearchGroceryProducts200Response();

  group('test SearchGroceryProducts200Response', () {
    // Set<AutocompleteRecipeSearch200ResponseInner> products (default value: const {})
    test('to test the property `products`', () async {
      // TODO
    });

    // int totalProducts
    test('to test the property `totalProducts`', () async {
      // TODO
    });

    // String type
    test('to test the property `type`', () async {
      // TODO
    });

    // int offset
    test('to test the property `offset`', () async {
      // TODO
    });

    // int number
    test('to test the property `number`', () async {
      // TODO
    });


  });

}

# # SearchMenuItems200ResponseMenuItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**title** | **string** |  |
**restaurant_chain** | **string** |  |
**image** | **string** |  |
**image_type** | **string** |  |
**servings** | [**\OpenAPI\Client\Model\SearchGroceryProductsByUPC200ResponseServings**](SearchGroceryProductsByUPC200ResponseServings.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

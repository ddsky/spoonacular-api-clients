# OAIAnalyzeRecipeRequest1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **NSString*** |  | [optional] 
**servings** | **NSNumber*** |  | [optional] 
**ingredients** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**instructions** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OAISearchRestaurants200ResponseRestaurantsInnerAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streetAddr** | **NSString*** |  | [optional] 
**city** | **NSString*** |  | [optional] 
**state** | **NSString*** |  | [optional] 
**zipcode** | **NSString*** |  | [optional] 
**country** | **NSString*** |  | [optional] 
**lat** | **NSNumber*** |  | [optional] 
**lon** | **NSNumber*** |  | [optional] 
**streetAddr2** | **NSString*** |  | [optional] 
**latitude** | **NSNumber*** |  | [optional] 
**longitude** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



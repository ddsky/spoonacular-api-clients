# Org.OpenAPITools.Model.SearchFoodVideos200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Videos** | [**List<SearchFoodVideos200ResponseVideosInner>**](SearchFoodVideos200ResponseVideosInner.md) |  | 
**TotalResults** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


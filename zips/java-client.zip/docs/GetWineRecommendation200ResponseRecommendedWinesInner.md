

# GetWineRecommendation200ResponseRecommendedWinesInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  |
|**title** | **String** |  |  |
|**averageRating** | **BigDecimal** |  |  |
|**description** | **String** |  |  |
|**imageUrl** | **String** |  |  |
|**link** | **String** |  |  |
|**price** | **String** |  |  |
|**ratingCount** | **Integer** |  |  |
|**score** | **BigDecimal** |  |  |




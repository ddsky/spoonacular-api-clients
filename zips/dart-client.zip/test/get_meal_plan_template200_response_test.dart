//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GetMealPlanTemplate200Response
void main() {
  // final instance = GetMealPlanTemplate200Response();

  group('test GetMealPlanTemplate200Response', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // Set<GetMealPlanTemplate200ResponseDaysInner> days (default value: const {})
    test('to test the property `days`', () async {
      // TODO
    });


  });

}

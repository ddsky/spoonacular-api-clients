# spoonacular.Model.GenerateMealPlan200ResponseNutrients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Calories** | **decimal** |  | 
**Carbohydrates** | **decimal** |  | 
**Fat** | **decimal** |  | 
**Protein** | **decimal** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


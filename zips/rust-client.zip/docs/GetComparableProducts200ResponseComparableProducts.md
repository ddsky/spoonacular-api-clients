# GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**Vec<models::ComparableProduct>**](ComparableProduct.md) |  | 
**likes** | [**Vec<models::ComparableProduct>**](ComparableProduct.md) |  | 
**price** | [**Vec<models::ComparableProduct>**](ComparableProduct.md) |  | 
**protein** | [**Vec<models::ComparableProduct>**](ComparableProduct.md) |  | 
**spoonacular_score** | [**Vec<models::ComparableProduct>**](ComparableProduct.md) |  | 
**sugar** | [**Vec<models::ComparableProduct>**](ComparableProduct.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SpoonacularApi.SearchMenuItems200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menuItems** | [**[MenuItem]**](MenuItem.md) |  | 
**totalMenuItems** | **Number** |  | 
**type** | **String** |  | 
**offset** | **Number** |  | 
**number** | **Number** |  | 



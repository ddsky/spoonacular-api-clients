# OpenapiClient::GetMealPlanTemplates200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **templates** | [**Array&lt;GetMealPlanTemplates200ResponseTemplatesInner&gt;**](GetMealPlanTemplates200ResponseTemplatesInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetMealPlanTemplates200Response.new(
  templates: null
)
```


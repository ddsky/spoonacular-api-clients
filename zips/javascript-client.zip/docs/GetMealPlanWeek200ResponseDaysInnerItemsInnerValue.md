# SpoonacularApi.GetMealPlanWeek200ResponseDaysInnerItemsInnerValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**servings** | **Number** |  | 
**id** | **Number** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 



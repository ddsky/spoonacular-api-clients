

# GetRecipeIngredientsByID200ResponseIngredientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**amount** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.md) |  |  [optional] |
|**image** | **String** |  |  |
|**name** | **String** |  |  |




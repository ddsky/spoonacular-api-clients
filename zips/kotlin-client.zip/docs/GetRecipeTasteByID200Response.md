
# GetRecipeTasteByID200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**saltiness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**sourness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**bitterness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**savoriness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**fattiness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**spiciness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 




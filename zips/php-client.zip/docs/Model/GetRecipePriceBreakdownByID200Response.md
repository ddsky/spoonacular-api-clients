# # GetRecipePriceBreakdownByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**\OpenAPI\Client\Model\GetRecipePriceBreakdownByID200ResponseIngredientsInner[]**](GetRecipePriceBreakdownByID200ResponseIngredientsInner.md) |  |
**total_cost** | **float** |  |
**total_cost_per_serving** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

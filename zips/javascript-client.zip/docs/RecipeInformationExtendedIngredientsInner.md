# Spoonacular.RecipeInformationExtendedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**amount** | **Number** |  | 
**consistency** | **String** |  | 
**id** | **Number** |  | 
**image** | **String** |  | 
**measures** | [**RecipeInformationExtendedIngredientsInnerMeasures**](RecipeInformationExtendedIngredientsInnerMeasures.md) |  | [optional] 
**meta** | **[String]** |  | [optional] 
**name** | **String** |  | 
**original** | **String** |  | 
**originalName** | **String** |  | 
**unit** | **String** |  | 



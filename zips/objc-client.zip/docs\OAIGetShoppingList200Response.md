# OAIGetShoppingList200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**OAISet&lt;OAIGetShoppingList200ResponseAislesInner&gt;***](OAIGetShoppingList200ResponseAislesInner.md) |  | 
**cost** | **NSNumber*** |  | 
**startDate** | **NSNumber*** |  | 
**endDate** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



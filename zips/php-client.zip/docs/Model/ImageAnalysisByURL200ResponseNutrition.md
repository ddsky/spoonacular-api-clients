# # ImageAnalysisByURL200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes_used** | **int** |  |
**calories** | [**\com.spoonacular.client\com.spoonacular.client.model\ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |
**fat** | [**\com.spoonacular.client\com.spoonacular.client.model\ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |
**protein** | [**\com.spoonacular.client\com.spoonacular.client.model\ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |
**carbs** | [**\com.spoonacular.client\com.spoonacular.client.model\ImageAnalysisByURL200ResponseNutritionCalories**](ImageAnalysisByURL200ResponseNutritionCalories.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

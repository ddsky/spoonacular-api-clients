# OpenapiClient::AddToMealPlanRequest1Value

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **ingredients** | [**Array&lt;AddToMealPlanRequest1ValueIngredientsInner&gt;**](AddToMealPlanRequest1ValueIngredientsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AddToMealPlanRequest1Value.new(
  ingredients: null
)
```


# SpoonacularApi.SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**[SearchSiteContent200ResponseArticlesInner]**](SearchSiteContent200ResponseArticlesInner.md) |  | 
**groceryProducts** | [**[SearchSiteContent200ResponseGroceryProductsInner]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**menuItems** | [**[SearchSiteContent200ResponseGroceryProductsInner]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**recipes** | [**[SearchSiteContent200ResponseGroceryProductsInner]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 



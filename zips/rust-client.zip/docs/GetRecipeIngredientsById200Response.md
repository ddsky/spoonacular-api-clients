# GetRecipeIngredientsById200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**Vec<crate::models::GetRecipeIngredientsById200ResponseIngredientsInner>**](getRecipeIngredientsByID_200_response_ingredients_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



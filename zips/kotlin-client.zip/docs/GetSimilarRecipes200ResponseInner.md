
# GetSimilarRecipes200ResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**title** | **kotlin.String** |  | 
**imageType** | **kotlin.String** |  | 
**readyInMinutes** | **kotlin.Int** |  | 
**servings** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**sourceUrl** | **kotlin.String** |  | 




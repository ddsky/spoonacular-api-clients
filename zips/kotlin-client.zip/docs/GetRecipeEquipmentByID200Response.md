
# GetRecipeEquipmentByID200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **equipment** | [**kotlin.collections.Set&lt;GetRecipeEquipmentByID200ResponseEquipmentInner&gt;**](GetRecipeEquipmentByID200ResponseEquipmentInner.md) |  |  |




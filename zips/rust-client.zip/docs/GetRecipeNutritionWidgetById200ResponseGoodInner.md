# GetRecipeNutritionWidgetById200ResponseGoodInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** |  | 
**indented** | **bool** |  | 
**percent_of_daily_needs** | **f64** |  | 
**name** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



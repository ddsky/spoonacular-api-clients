# OpenapiClient::ParseIngredients200ResponseInnerEstimatedCost

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **value** | **Float** |  |  |
| **unit** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ParseIngredients200ResponseInnerEstimatedCost.new(
  value: null,
  unit: null
)
```


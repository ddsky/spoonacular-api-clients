# WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseIngredientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseIngredientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **object** |  | [optional] 
**name** | **string** |  | 
**safety_level** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



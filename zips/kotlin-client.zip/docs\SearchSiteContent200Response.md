
# SearchSiteContent200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**kotlin.collections.Set&lt;SearchSiteContent200ResponseArticlesInner&gt;**](SearchSiteContent200ResponseArticlesInner.md) |  | 
**groceryProducts** | [**kotlin.collections.Set&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**menuItems** | [**kotlin.collections.Set&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**recipes** | [**kotlin.collections.Set&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 




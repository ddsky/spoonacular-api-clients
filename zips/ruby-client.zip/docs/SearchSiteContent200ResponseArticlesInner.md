# OpenapiClient::SearchSiteContent200ResponseArticlesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **data_points** | **Array&lt;Object&gt;** |  | [optional] |
| **image** | **String** |  |  |
| **link** | **String** |  |  |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchSiteContent200ResponseArticlesInner.new(
  data_points: null,
  image: null,
  link: null,
  name: null
)
```


# WWW::OpenAPIClient::Object::AddToMealPlanRequest1

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AddToMealPlanRequest1;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **double** |  | 
**slot** | **int** |  | 
**position** | **int** |  | 
**type** | **string** |  | 
**value** | [**AddToMealPlanRequest1Value**](AddToMealPlanRequest1Value.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



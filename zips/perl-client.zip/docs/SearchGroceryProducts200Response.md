# WWW::OpenAPIClient::Object::SearchGroceryProducts200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGroceryProducts200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**ARRAY[AutocompleteRecipeSearch200ResponseInner]**](AutocompleteRecipeSearch200ResponseInner.md) |  | 
**total_products** | **int** |  | 
**type** | **string** |  | 
**offset** | **int** |  | 
**number** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



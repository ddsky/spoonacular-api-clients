# spoonacular.Model.GenerateShoppingListRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Username** | **string** | The username. | 
**StartDate** | **string** | The start date in the format yyyy-mm-dd. | 
**EndDate** | **string** | The end date in the format yyyy-mm-dd. | 
**Hash** | **string** | The private hash for the username. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# OAIGetShoppingList200ResponseAislesInnerItemsInnerMeasures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | [**OAIParseIngredients200ResponseInnerNutritionWeightPerServing***](OAIParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 
**metric** | [**OAIParseIngredients200ResponseInnerNutritionWeightPerServing***](OAIParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 
**us** | [**OAIParseIngredients200ResponseInnerNutritionWeightPerServing***](OAIParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



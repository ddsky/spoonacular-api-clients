# # GetRecipeNutritionWidgetByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **string** |  |
**carbs** | **string** |  |
**fat** | **string** |  |
**protein** | **string** |  |
**bad** | [**\OpenAPI\Client\Model\GetRecipeNutritionWidgetByID200ResponseBadInner[]**](GetRecipeNutritionWidgetByID200ResponseBadInner.md) |  |
**good** | [**\OpenAPI\Client\Model\GetRecipeNutritionWidgetByID200ResponseGoodInner[]**](GetRecipeNutritionWidgetByID200ResponseGoodInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

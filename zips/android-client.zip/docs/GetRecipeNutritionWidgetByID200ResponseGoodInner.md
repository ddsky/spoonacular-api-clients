

# GetRecipeNutritionWidgetByID200ResponseGoodInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** |  | 
**indented** | **Boolean** |  | 
**percentOfDailyNeeds** | [**BigDecimal**](BigDecimal.md) |  | 
**title** | **String** |  | 





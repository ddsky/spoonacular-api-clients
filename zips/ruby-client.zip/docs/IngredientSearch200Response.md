# OpenapiClient::IngredientSearch200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **results** | [**Array&lt;IngredientSearch200ResponseResultsInner&gt;**](IngredientSearch200ResponseResultsInner.md) |  |  |
| **offset** | **Integer** |  |  |
| **number** | **Integer** |  |  |
| **total_results** | **Integer** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::IngredientSearch200Response.new(
  results: null,
  offset: null,
  number: null,
  total_results: null
)
```


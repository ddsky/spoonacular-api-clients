# WWW::OpenAPIClient::Object::SearchRecipes200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRecipes200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  | 
**number** | **int** |  | 
**results** | [**ARRAY[SearchRecipes200ResponseResultsInner]**](SearchRecipes200ResponseResultsInner.md) |  | 
**total_results** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



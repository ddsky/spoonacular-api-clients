
# ConnectUserRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **username** | **kotlin.String** |  |  |
| **firstName** | **kotlin.String** |  |  |
| **lastName** | **kotlin.String** |  |  |
| **email** | **kotlin.String** |  |  |




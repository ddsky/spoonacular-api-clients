

# GetMealPlanWeek200ResponseDaysInnerItemsInnerValue


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**servings** | **BigDecimal** |  |  |
|**id** | **BigDecimal** |  |  |
|**title** | **String** |  |  |
|**imageType** | **String** |  |  |




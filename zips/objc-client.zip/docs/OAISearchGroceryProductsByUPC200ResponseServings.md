# OAISearchGroceryProductsByUPC200ResponseServings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **NSNumber*** |  | 
**size** | **NSNumber*** |  | 
**unit** | **NSString*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



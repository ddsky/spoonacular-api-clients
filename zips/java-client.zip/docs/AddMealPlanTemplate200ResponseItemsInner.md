

# AddMealPlanTemplate200ResponseItemsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**day** | **Integer** |  |  |
|**slot** | **Integer** |  |  |
|**position** | **Integer** |  |  |
|**type** | **String** |  |  |
|**value** | [**AddMealPlanTemplate200ResponseItemsInnerValue**](AddMealPlanTemplate200ResponseItemsInnerValue.md) |  |  [optional] |




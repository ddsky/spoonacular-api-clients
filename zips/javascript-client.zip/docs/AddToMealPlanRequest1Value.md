# SpoonacularApi.AddToMealPlanRequest1Value

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**[AddToMealPlanRequest1ValueIngredientsInner]**](AddToMealPlanRequest1ValueIngredientsInner.md) |  | 



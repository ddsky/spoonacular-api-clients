# WWW::OpenAPIClient::Object::AddToShoppingListRequest

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AddToShoppingListRequest;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item** | **string** |  | 
**aisle** | **string** |  | 
**parse** | **boolean** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



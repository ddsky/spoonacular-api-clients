# # GetMenuItemInformation200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**title** | **string** |  |
**restaurant_chain** | **string** |  |
**nutrition** | [**\OpenAPI\Client\Model\SearchGroceryProductsByUPC200ResponseNutrition**](SearchGroceryProductsByUPC200ResponseNutrition.md) |  |
**badges** | **string[]** |  |
**breadcrumbs** | **string[]** |  |
**generated_text** | **string** |  | [optional]
**image_type** | **string** |  |
**likes** | **float** |  |
**servings** | [**\OpenAPI\Client\Model\SearchGroceryProductsByUPC200ResponseServings**](SearchGroceryProductsByUPC200ResponseServings.md) |  |
**price** | **float** |  | [optional]
**spoonacular_score** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

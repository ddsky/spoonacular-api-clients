

# RecipeInformationWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **List&lt;String&gt;** |  |  [optional]
**pairingText** | **String** |  |  [optional]
**productMatches** | [**Set&lt;RecipeInformationWinePairingProductMatchesInner&gt;**](RecipeInformationWinePairingProductMatchesInner.md) |  |  [optional]





# # GetMealPlanTemplate200ResponseDaysInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrition_summary** | [**\com.spoonacular.client\com.spoonacular.client.model\GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional]
**nutrition_summary_breakfast** | [**\com.spoonacular.client\com.spoonacular.client.model\GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional]
**nutrition_summary_lunch** | [**\com.spoonacular.client\com.spoonacular.client.model\GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional]
**nutrition_summary_dinner** | [**\com.spoonacular.client\com.spoonacular.client.model\GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional]
**day** | **string** |  |
**items** | [**\com.spoonacular.client\com.spoonacular.client.model\GetMealPlanTemplate200ResponseDaysInnerItemsInner[]**](GetMealPlanTemplate200ResponseDaysInnerItemsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for AnalyzeARecipeSearchQuery200ResponseIngredientsInner
void main() {
  // final instance = AnalyzeARecipeSearchQuery200ResponseIngredientsInner();

  group('test AnalyzeARecipeSearchQuery200ResponseIngredientsInner', () {
    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // bool include
    test('to test the property `include`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });


  });

}

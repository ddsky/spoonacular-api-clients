# GuessNutritionByDishName200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**crate::models::GuessNutritionByDishName200ResponseCalories**](guessNutritionByDishName_200_response_calories.md) |  | 
**carbs** | [**crate::models::GuessNutritionByDishName200ResponseCalories**](guessNutritionByDishName_200_response_calories.md) |  | 
**fat** | [**crate::models::GuessNutritionByDishName200ResponseCalories**](guessNutritionByDishName_200_response_calories.md) |  | 
**protein** | [**crate::models::GuessNutritionByDishName200ResponseCalories**](guessNutritionByDishName_200_response_calories.md) |  | 
**recipes_used** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# GetIngredientInformation200ResponseNutrition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**kotlin.collections.Set&lt;ParseIngredients200ResponseInnerNutritionNutrientsInner&gt;**](ParseIngredients200ResponseInnerNutritionNutrientsInner.md) |  | 
**properties** | [**kotlin.collections.Set&lt;ParseIngredients200ResponseInnerNutritionPropertiesInner&gt;**](ParseIngredients200ResponseInnerNutritionPropertiesInner.md) |  | 
**caloricBreakdown** | [**ParseIngredients200ResponseInnerNutritionCaloricBreakdown**](ParseIngredients200ResponseInnerNutritionCaloricBreakdown.md) |  | 
**weightPerServing** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 




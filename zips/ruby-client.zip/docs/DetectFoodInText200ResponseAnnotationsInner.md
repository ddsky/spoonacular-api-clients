# OpenapiClient::DetectFoodInText200ResponseAnnotationsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **annotation** | **String** |  |  |
| **image** | **String** |  |  |
| **tag** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::DetectFoodInText200ResponseAnnotationsInner.new(
  annotation: null,
  image: null,
  tag: null
)
```


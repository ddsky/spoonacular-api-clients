# # SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **string** |  |
**amount** | **float** |  |
**id** | **int** |  |
**image** | **string** |  |
**meta** | **string[]** |  | [optional]
**name** | **string** |  |
**original** | **string** |  |
**original_name** | **string** |  |
**unit** | **string** |  |
**unit_long** | **string** |  |
**unit_short** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# ParseIngredients200ResponseInnerNutritionPropertiesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**amount** | **float** |  | 
**unit** | **str** |  | 

## Example

```python
from spoonacular.models.parse_ingredients200_response_inner_nutrition_properties_inner import ParseIngredients200ResponseInnerNutritionPropertiesInner

# TODO update the JSON string below
json = "{}"
# create an instance of ParseIngredients200ResponseInnerNutritionPropertiesInner from a JSON string
parse_ingredients200_response_inner_nutrition_properties_inner_instance = ParseIngredients200ResponseInnerNutritionPropertiesInner.from_json(json)
# print the JSON string representation of the object
print(ParseIngredients200ResponseInnerNutritionPropertiesInner.to_json())

# convert the object into a dict
parse_ingredients200_response_inner_nutrition_properties_inner_dict = parse_ingredients200_response_inner_nutrition_properties_inner_instance.to_dict()
# create an instance of ParseIngredients200ResponseInnerNutritionPropertiesInner from a dict
parse_ingredients200_response_inner_nutrition_properties_inner_from_dict = ParseIngredients200ResponseInnerNutritionPropertiesInner.from_dict(parse_ingredients200_response_inner_nutrition_properties_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



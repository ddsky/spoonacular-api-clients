

# AnalyzeARecipeSearchQuery200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**dishes** | [**Set&lt;AnalyzeARecipeSearchQuery200ResponseDishesInner&gt;**](AnalyzeARecipeSearchQuery200ResponseDishesInner.md) |  |  |
|**ingredients** | [**Set&lt;AnalyzeARecipeSearchQuery200ResponseIngredientsInner&gt;**](AnalyzeARecipeSearchQuery200ResponseIngredientsInner.md) |  |  |
|**cuisines** | **List&lt;String&gt;** |  |  |
|**modifiers** | **List&lt;String&gt;** |  |  |




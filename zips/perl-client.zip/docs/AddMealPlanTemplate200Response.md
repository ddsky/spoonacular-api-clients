# WWW::OpenAPIClient::Object::AddMealPlanTemplate200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AddMealPlanTemplate200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**items** | [**ARRAY[AddMealPlanTemplate200ResponseItemsInner]**](AddMealPlanTemplate200ResponseItemsInner.md) |  | 
**publish_as_public** | **boolean** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



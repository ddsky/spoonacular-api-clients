# WWW::OpenAPIClient::Object::GetDishPairingForWine200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetDishPairingForWine200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairings** | **ARRAY[string]** |  | 
**text** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



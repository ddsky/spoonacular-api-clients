
# SearchGroceryProducts200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **products** | [**kotlin.collections.Set&lt;AutocompleteRecipeSearch200ResponseInner&gt;**](AutocompleteRecipeSearch200ResponseInner.md) |  |  |
| **totalProducts** | **kotlin.Int** |  |  |
| **type** | **kotlin.String** |  |  |
| **offset** | **kotlin.Int** |  |  |
| **number** | **kotlin.Int** |  |  |




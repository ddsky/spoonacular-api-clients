
# AutocompleteProductSearch200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **results** | [**kotlin.collections.Set&lt;AutocompleteProductSearch200ResponseResultsInner&gt;**](AutocompleteProductSearch200ResponseResultsInner.md) |  |  |




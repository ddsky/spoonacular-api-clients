# # GenerateMealPlan200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meals** | [**\OpenAPI\Client\Model\GetSimilarRecipes200ResponseInner[]**](GetSimilarRecipes200ResponseInner.md) |  |
**nutrients** | [**\OpenAPI\Client\Model\GenerateMealPlan200ResponseNutrients**](GenerateMealPlan200ResponseNutrients.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)


# GetComparableProducts200ResponseComparableProducts

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **calories** | [**kotlin.collections.List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  |  |
| **likes** | [**kotlin.collections.List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  |  |
| **price** | [**kotlin.collections.List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  |  |
| **protein** | [**kotlin.collections.List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  |  |
| **spoonacularScore** | [**kotlin.collections.List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  |  |
| **sugar** | [**kotlin.collections.List&lt;ComparableProduct&gt;**](ComparableProduct.md) |  |  |




# SpoonacularApi.SearchSiteContent200ResponseArticlesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataPoints** | [**[SearchSiteContent200ResponseArticlesInnerDataPointsInner]**](SearchSiteContent200ResponseArticlesInnerDataPointsInner.md) |  | [optional] 
**image** | **String** |  | 
**link** | **String** |  | 
**name** | **String** |  | 



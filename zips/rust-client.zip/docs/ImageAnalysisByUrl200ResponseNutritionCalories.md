# ImageAnalysisByUrl200ResponseNutritionCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **f64** |  | 
**unit** | **String** |  | 
**confidence_range95_percent** | [**models::ImageAnalysisByUrl200ResponseNutritionCaloriesConfidenceRange95Percent**](imageAnalysisByURL_200_response_nutrition_calories_confidenceRange95Percent.md) |  | 
**standard_deviation** | **f64** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



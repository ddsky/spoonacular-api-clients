# spoonacular.Model.DetectFoodInText200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Annotations** | [**List&lt;DetectFoodInText200ResponseAnnotationsInner&gt;**](DetectFoodInText200ResponseAnnotationsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


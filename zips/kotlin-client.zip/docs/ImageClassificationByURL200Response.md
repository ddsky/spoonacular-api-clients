
# ImageClassificationByURL200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **category** | **kotlin.String** |  |  |
| **probability** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




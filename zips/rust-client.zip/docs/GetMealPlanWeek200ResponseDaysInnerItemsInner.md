# GetMealPlanWeek200ResponseDaysInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** |  | 
**slot** | **i32** |  | 
**position** | **i32** |  | 
**r#type** | **String** |  | 
**value** | Option<[**crate::models::GetMealPlanWeek200ResponseDaysInnerItemsInnerValue**](getMealPlanWeek_200_response_days_inner_items_inner_value.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



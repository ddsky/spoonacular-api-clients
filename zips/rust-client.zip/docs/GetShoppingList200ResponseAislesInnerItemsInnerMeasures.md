# GetShoppingList200ResponseAislesInnerItemsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | [**models::GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](getShoppingList_200_response_aisles_inner_items_inner_measures_original.md) |  | 
**metric** | [**models::GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](getShoppingList_200_response_aisles_inner_items_inner_measures_original.md) |  | 
**us** | [**models::GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](getShoppingList_200_response_aisles_inner_items_inner_measures_original.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OpenapiClient::QuickAnswer200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **answer** | **String** |  |  |
| **image** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::QuickAnswer200Response.new(
  answer: null,
  image: null
)
```


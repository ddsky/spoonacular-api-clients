# IngredientSearch200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**Vec<crate::models::IngredientSearch200ResponseResultsInner>**](ingredientSearch_200_response_results_inner.md) |  | 
**offset** | **i32** |  | 
**number** | **i32** |  | 
**total_results** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



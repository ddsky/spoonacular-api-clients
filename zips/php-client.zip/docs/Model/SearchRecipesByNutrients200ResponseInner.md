# # SearchRecipesByNutrients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **float** |  |
**carbs** | **string** |  |
**fat** | **string** |  |
**id** | **int** |  |
**image** | **string** |  |
**image_type** | **string** |  |
**protein** | **string** |  |
**title** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

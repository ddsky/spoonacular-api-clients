# spoonacular.Model.SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Articles** | [**List&lt;SearchResult&gt;**](SearchResult.md) |  | 
**GroceryProducts** | [**List&lt;SearchResult&gt;**](SearchResult.md) |  | 
**MenuItems** | [**List&lt;SearchResult&gt;**](SearchResult.md) |  | 
**Recipes** | [**List&lt;SearchResult&gt;**](SearchResult.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# AnalyzeARecipeSearchQuery200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dishes** | [**kotlin.collections.Set&lt;AnalyzeARecipeSearchQuery200ResponseDishesInner&gt;**](AnalyzeARecipeSearchQuery200ResponseDishesInner.md) |  | 
**ingredients** | [**kotlin.collections.Set&lt;AnalyzeARecipeSearchQuery200ResponseIngredientsInner&gt;**](AnalyzeARecipeSearchQuery200ResponseIngredientsInner.md) |  | 
**cuisines** | **kotlin.collections.List&lt;kotlin.String&gt;** |  | 
**modifiers** | **kotlin.collections.List&lt;kotlin.String&gt;** |  | 




# GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **float** |  | 
**unit_long** | **str** |  | 
**unit_short** | **str** |  | 

## Example

```python
from spoonacular.models.get_recipe_information200_response_extended_ingredients_inner_measures_metric import GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric

# TODO update the JSON string below
json = "{}"
# create an instance of GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric from a JSON string
get_recipe_information200_response_extended_ingredients_inner_measures_metric_instance = GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.from_json(json)
# print the JSON string representation of the object
print(GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.to_json())

# convert the object into a dict
get_recipe_information200_response_extended_ingredients_inner_measures_metric_dict = get_recipe_information200_response_extended_ingredients_inner_measures_metric_instance.to_dict()
# create an instance of GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric from a dict
get_recipe_information200_response_extended_ingredients_inner_measures_metric_from_dict = GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.from_dict(get_recipe_information200_response_extended_ingredients_inner_measures_metric_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



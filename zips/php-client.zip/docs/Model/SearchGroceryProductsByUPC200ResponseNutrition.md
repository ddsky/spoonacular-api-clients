# # SearchGroceryProductsByUPC200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\OpenAPI\Client\Model\SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner[]**](SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner.md) |  |
**caloric_breakdown** | [**\OpenAPI\Client\Model\SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown**](SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# WWW::OpenAPIClient::Object::GetMealPlanTemplate200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetMealPlanTemplate200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **string** |  | 
**days** | [**ARRAY[GetMealPlanTemplate200ResponseDaysInner]**](GetMealPlanTemplate200ResponseDaysInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



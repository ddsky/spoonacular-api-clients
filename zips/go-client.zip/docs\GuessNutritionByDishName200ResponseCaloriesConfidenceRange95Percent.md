# GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Max** | **float32** |  | 
**Min** | **float32** |  | 

## Methods

### NewGuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent

`func NewGuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent(max float32, min float32, ) *GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent`

NewGuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent instantiates a new GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGuessNutritionByDishName200ResponseCaloriesConfidenceRange95PercentWithDefaults

`func NewGuessNutritionByDishName200ResponseCaloriesConfidenceRange95PercentWithDefaults() *GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent`

NewGuessNutritionByDishName200ResponseCaloriesConfidenceRange95PercentWithDefaults instantiates a new GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMax

`func (o *GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent) GetMax() float32`

GetMax returns the Max field if non-nil, zero value otherwise.

### GetMaxOk

`func (o *GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent) GetMaxOk() (*float32, bool)`

GetMaxOk returns a tuple with the Max field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMax

`func (o *GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent) SetMax(v float32)`

SetMax sets Max field to given value.


### GetMin

`func (o *GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent) GetMin() float32`

GetMin returns the Min field if non-nil, zero value otherwise.

### GetMinOk

`func (o *GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent) GetMinOk() (*float32, bool)`

GetMinOk returns a tuple with the Min field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMin

`func (o *GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent) SetMin(v float32)`

SetMin sets Min field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



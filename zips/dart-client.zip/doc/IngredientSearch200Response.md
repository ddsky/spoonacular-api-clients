# openapi.model.IngredientSearch200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**Set<IngredientSearch200ResponseResultsInner>**](IngredientSearch200ResponseResultsInner.md) |  | [default to const {}]
**offset** | **int** |  | 
**number** | **int** |  | 
**totalResults** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**aisle** | **String** |  |  |
|**amount** | **BigDecimal** |  |  |
|**id** | **Integer** |  |  |
|**image** | **String** |  |  |
|**meta** | **List&lt;String&gt;** |  |  [optional] |
|**name** | **String** |  |  |
|**extendedName** | **String** |  |  [optional] |
|**original** | **String** |  |  |
|**originalName** | **String** |  |  |
|**unit** | **String** |  |  |
|**unitLong** | **String** |  |  |
|**unitShort** | **String** |  |  |




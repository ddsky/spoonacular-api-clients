
# GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **unit** | **kotlin.String** |  |  |
| **&#x60;value&#x60;** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




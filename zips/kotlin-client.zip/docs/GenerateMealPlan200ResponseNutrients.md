
# GenerateMealPlan200ResponseNutrients

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**carbohydrates** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**fat** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**protein** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 




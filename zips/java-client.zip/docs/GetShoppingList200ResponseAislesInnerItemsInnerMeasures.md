

# GetShoppingList200ResponseAislesInnerItemsInnerMeasures


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**original** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  |  |
|**metric** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  |  |
|**us** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  |  |




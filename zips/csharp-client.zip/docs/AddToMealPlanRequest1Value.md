# spoonacular.Model.AddToMealPlanRequest1Value

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ingredients** | [**List&lt;AddToMealPlanRequest1ValueIngredientsInner&gt;**](AddToMealPlanRequest1ValueIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


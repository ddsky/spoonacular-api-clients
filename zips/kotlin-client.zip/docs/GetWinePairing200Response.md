
# GetWinePairing200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **pairedWines** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  |
| **pairingText** | **kotlin.String** |  |  |
| **productMatches** | [**kotlin.collections.Set&lt;GetWinePairing200ResponseProductMatchesInner&gt;**](GetWinePairing200ResponseProductMatchesInner.md) |  |  |




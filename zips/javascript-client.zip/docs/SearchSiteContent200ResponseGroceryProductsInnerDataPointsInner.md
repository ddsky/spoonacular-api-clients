# SpoonacularApi.SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | 
**value** | **String** |  | 



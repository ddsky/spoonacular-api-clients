# OpenapiClient::GetProductInformation200ResponseIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **description** | **String** |  | [optional] |
| **name** | **String** |  |  |
| **safety_level** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetProductInformation200ResponseIngredientsInner.new(
  description: null,
  name: null,
  safety_level: null
)
```


# GetShoppingList200ResponseAislesInnerItemsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | [**crate::models::ParseIngredients200ResponseInnerNutritionWeightPerServing**](parseIngredients_200_response_inner_nutrition_weightPerServing.md) |  | 
**metric** | [**crate::models::ParseIngredients200ResponseInnerNutritionWeightPerServing**](parseIngredients_200_response_inner_nutrition_weightPerServing.md) |  | 
**us** | [**crate::models::ParseIngredients200ResponseInnerNutritionWeightPerServing**](parseIngredients_200_response_inner_nutrition_weightPerServing.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



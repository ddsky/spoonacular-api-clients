# OpenapiClient::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **monday** | **String** |  | [optional] |
| **tuesday** | **String** |  | [optional] |
| **wednesday** | **String** |  | [optional] |
| **thursday** | **String** |  | [optional] |
| **friday** | **String** |  | [optional] |
| **saturday** | **String** |  | [optional] |
| **sunday** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.new(
  monday: null,
  tuesday: null,
  wednesday: null,
  thursday: null,
  friday: null,
  saturday: null,
  sunday: null
)
```


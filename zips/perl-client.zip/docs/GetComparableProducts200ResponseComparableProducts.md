# WWW::OpenAPIClient::Object::GetComparableProducts200ResponseComparableProducts

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetComparableProducts200ResponseComparableProducts;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**ARRAY[ComparableProduct]**](ComparableProduct.md) |  | 
**likes** | [**ARRAY[ComparableProduct]**](ComparableProduct.md) |  | 
**price** | [**ARRAY[ComparableProduct]**](ComparableProduct.md) |  | 
**protein** | [**ARRAY[ComparableProduct]**](ComparableProduct.md) |  | 
**spoonacular_score** | [**ARRAY[ComparableProduct]**](ComparableProduct.md) |  | 
**sugar** | [**ARRAY[ComparableProduct]**](ComparableProduct.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



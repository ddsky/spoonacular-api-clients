# SpoonacularApi.GetRecipeNutritionWidgetByID200ResponseBadInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**amount** | **String** |  | 
**indented** | **Boolean** |  | 
**percentOfDailyNeeds** | **Number** |  | 



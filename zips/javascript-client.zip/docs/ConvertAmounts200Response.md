# Spoonacular.ConvertAmounts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceAmount** | **Number** |  | 
**sourceUnit** | **String** |  | 
**targetAmount** | **Number** |  | 
**targetUnit** | **String** |  | 
**answer** | **String** |  | 



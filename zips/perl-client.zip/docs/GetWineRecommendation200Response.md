# WWW::OpenAPIClient::Object::GetWineRecommendation200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetWineRecommendation200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommended_wines** | [**ARRAY[GetWineRecommendation200ResponseRecommendedWinesInner]**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  | 
**total_found** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



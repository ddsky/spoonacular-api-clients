# Org.OpenAPITools.Model.DetectFoodInText200ResponseAnnotationsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Annotation** | **string** |  | 
**Image** | **string** |  | 
**Tag** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


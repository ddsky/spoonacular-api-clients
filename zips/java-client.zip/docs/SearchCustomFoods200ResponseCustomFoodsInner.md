

# SearchCustomFoods200ResponseCustomFoodsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  |
|**title** | **String** |  |  |
|**servings** | **BigDecimal** |  |  |
|**imageUrl** | **String** |  |  |
|**price** | **BigDecimal** |  |  |




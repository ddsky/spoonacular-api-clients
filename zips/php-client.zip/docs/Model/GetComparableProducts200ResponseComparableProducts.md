# # GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**\OpenAPI\Client\Model\ComparableProduct[]**](ComparableProduct.md) |  |
**likes** | [**\OpenAPI\Client\Model\ComparableProduct[]**](ComparableProduct.md) |  |
**price** | [**\OpenAPI\Client\Model\ComparableProduct[]**](ComparableProduct.md) |  |
**protein** | [**\OpenAPI\Client\Model\ComparableProduct[]**](ComparableProduct.md) |  |
**spoonacular_score** | [**\OpenAPI\Client\Model\ComparableProduct[]**](ComparableProduct.md) |  |
**sugar** | [**\OpenAPI\Client\Model\ComparableProduct[]**](ComparableProduct.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# Spoonacular.GetAnalyzedRecipeInstructions200ResponseInnerStepsInnerIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | 
**localizedName** | **String** |  | 
**image** | **String** |  | 



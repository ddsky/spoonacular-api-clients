# GetRecipePriceBreakdownById200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**Vec<crate::models::GetRecipePriceBreakdownById200ResponseIngredientsInner>**](getRecipePriceBreakdownByID_200_response_ingredients_inner.md) |  | 
**total_cost** | **f32** |  | 
**total_cost_per_serving** | **f32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



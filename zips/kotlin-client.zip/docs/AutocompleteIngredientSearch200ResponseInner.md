
# AutocompleteIngredientSearch200ResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  | 
**image** | **kotlin.String** |  | 
**id** | **kotlin.Int** |  |  [optional]
**aisle** | **kotlin.String** |  |  [optional]
**possibleUnits** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional]




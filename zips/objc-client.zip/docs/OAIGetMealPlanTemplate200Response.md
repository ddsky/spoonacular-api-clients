# OAIGetMealPlanTemplate200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** |  | 
**name** | **NSString*** |  | 
**days** | [**OAISet&lt;OAIGetMealPlanTemplate200ResponseDaysInner&gt;***](OAIGetMealPlanTemplate200ResponseDaysInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



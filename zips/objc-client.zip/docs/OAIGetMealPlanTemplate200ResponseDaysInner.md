# OAIGetMealPlanTemplate200ResponseDaysInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutritionSummary** | [**OAIGetMealPlanWeek200ResponseDaysInnerNutritionSummary***](OAIGetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional] 
**nutritionSummaryBreakfast** | [**OAIGetMealPlanWeek200ResponseDaysInnerNutritionSummary***](OAIGetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional] 
**nutritionSummaryLunch** | [**OAIGetMealPlanWeek200ResponseDaysInnerNutritionSummary***](OAIGetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional] 
**nutritionSummaryDinner** | [**OAIGetMealPlanWeek200ResponseDaysInnerNutritionSummary***](OAIGetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  | [optional] 
**day** | **NSString*** |  | 
**items** | [**OAISet&lt;OAIGetMealPlanTemplate200ResponseDaysInnerItemsInner&gt;***](OAIGetMealPlanTemplate200ResponseDaysInnerItemsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



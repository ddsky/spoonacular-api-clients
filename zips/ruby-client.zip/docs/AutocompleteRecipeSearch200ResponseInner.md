# OpenapiClient::AutocompleteRecipeSearch200ResponseInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **title** | **String** |  |  |
| **image_type** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AutocompleteRecipeSearch200ResponseInner.new(
  id: null,
  title: null,
  image_type: null
)
```


# GetMealPlanTemplates200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**Vec<crate::models::GetAnalyzedRecipeInstructions200ResponseIngredientsInner>**](getAnalyzedRecipeInstructions_200_response_ingredients_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



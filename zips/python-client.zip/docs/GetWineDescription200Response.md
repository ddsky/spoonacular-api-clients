# GetWineDescription200Response



## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**wine_description** | **str** |  | 

## Example

```python
from spoonacular.models.get_wine_description200_response import GetWineDescription200Response

# TODO update the JSON string below
json = "{}"
# create an instance of GetWineDescription200Response from a JSON string
get_wine_description200_response_instance = GetWineDescription200Response.from_json(json)
# print the JSON string representation of the object
print(GetWineDescription200Response.to_json())

# convert the object into a dict
get_wine_description200_response_dict = get_wine_description200_response_instance.to_dict()
# create an instance of GetWineDescription200Response from a dict
get_wine_description200_response_from_dict = GetWineDescription200Response.from_dict(get_wine_description200_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# AddToShoppingListRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item** | **String** |  | 
**aisle** | **String** |  | 
**parse** | **Boolean** |  | 







# ClassifyCuisine200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**cuisine** | **String** |  |  |
|**cuisines** | **List&lt;String&gt;** |  |  |
|**confidence** | **BigDecimal** |  |  |




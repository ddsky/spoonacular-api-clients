# spoonacular.Model.AddMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | 
**Items** | [**List&lt;AddMealPlanTemplate200ResponseItemsInner&gt;**](AddMealPlanTemplate200ResponseItemsInner.md) |  | 
**PublishAsPublic** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


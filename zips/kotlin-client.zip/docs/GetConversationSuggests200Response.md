
# GetConversationSuggests200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggests** | [**GetConversationSuggests200ResponseSuggests**](GetConversationSuggests200ResponseSuggests.md) |  | 
**words** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) |  | 




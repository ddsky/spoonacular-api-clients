# spoonacular.Model.SearchRecipesByNutrients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Calories** | **decimal** |  | 
**Carbs** | **string** |  | 
**Fat** | **string** |  | 
**Id** | **int** |  | 
**Image** | **string** |  | 
**ImageType** | **string** |  | 
**Protein** | **string** |  | 
**Title** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


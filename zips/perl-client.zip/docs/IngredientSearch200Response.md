# WWW::OpenAPIClient::Object::IngredientSearch200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::IngredientSearch200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**ARRAY[IngredientSearch200ResponseResultsInner]**](IngredientSearch200ResponseResultsInner.md) |  | 
**offset** | **int** |  | 
**number** | **int** |  | 
**total_results** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



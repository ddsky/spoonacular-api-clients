# # SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchSiteContent200ResponseArticlesInner[]**](SearchSiteContent200ResponseArticlesInner.md) |  |
**grocery_products** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchSiteContent200ResponseGroceryProductsInner[]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  |
**menu_items** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchSiteContent200ResponseGroceryProductsInner[]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  |
**recipes** | [**\com.spoonacular.client\com.spoonacular.client.model\SearchSiteContent200ResponseGroceryProductsInner[]**](SearchSiteContent200ResponseGroceryProductsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

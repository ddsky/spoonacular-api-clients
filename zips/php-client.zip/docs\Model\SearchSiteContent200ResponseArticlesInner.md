# # SearchSiteContent200ResponseArticlesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_points** | **mixed[]** |  | [optional]
**image** | **string** |  |
**link** | **string** |  |
**name** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

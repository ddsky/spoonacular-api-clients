# Spoonacular.AnalyzeRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsedInstructions** | [**[AnalyzeRecipeInstructions200ResponseParsedInstructionsInner]**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**ingredients** | [**[AnalyzeRecipeInstructions200ResponseIngredientsInner]**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 
**equipment** | [**[AnalyzeRecipeInstructions200ResponseIngredientsInner]**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 



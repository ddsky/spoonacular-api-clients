# OpenapiClient::AddToMealPlanRequestValue

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **ingredients** | [**Array&lt;AddToMealPlanRequestValueIngredientsInner&gt;**](AddToMealPlanRequestValueIngredientsInner.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AddToMealPlanRequestValue.new(
  ingredients: null
)
```


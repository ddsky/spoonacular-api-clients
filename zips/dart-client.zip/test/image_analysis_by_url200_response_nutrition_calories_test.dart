//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ImageAnalysisByURL200ResponseNutritionCalories
void main() {
  // final instance = ImageAnalysisByURL200ResponseNutritionCalories();

  group('test ImageAnalysisByURL200ResponseNutritionCalories', () {
    // num value
    test('to test the property `value`', () async {
      // TODO
    });

    // String unit
    test('to test the property `unit`', () async {
      // TODO
    });

    // ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent confidenceRange95Percent
    test('to test the property `confidenceRange95Percent`', () async {
      // TODO
    });

    // num standardDeviation
    test('to test the property `standardDeviation`', () async {
      // TODO
    });


  });

}

# spoonacular.Model.SearchRecipesByIngredients200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | 
**Image** | **string** |  | 
**ImageType** | **string** |  | 
**Likes** | **int** |  | 
**MissedIngredientCount** | **int** |  | 
**MissedIngredients** | [**List&lt;SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner&gt;**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 
**Title** | **string** |  | 
**UnusedIngredients** | **List&lt;Object&gt;** |  | 
**UsedIngredientCount** | **decimal** |  | 
**UsedIngredients** | [**List&lt;SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner&gt;**](SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


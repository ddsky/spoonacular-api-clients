

# DeleteFromMealPlanRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**username** | **String** | The username. |  |
|**id** | **BigDecimal** | The shopping list item id. |  |
|**hash** | **String** | The private hash for the username. |  |




# GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  | 
**us** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  | 

## Example

```python
from spoonacular.models.get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount import GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount

# TODO update the JSON string below
json = "{}"
# create an instance of GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount from a JSON string
get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_instance = GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.from_json(json)
# print the JSON string representation of the object
print(GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.to_json())

# convert the object into a dict
get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_dict = get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_instance.to_dict()
# create an instance of GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount from a dict
get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_from_dict = GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.from_dict(get_recipe_price_breakdown_by_id200_response_ingredients_inner_amount_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OAIClassifyGroceryProductBulk200ResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cleanTitle** | **NSString*** |  | 
**image** | **NSString*** |  | 
**category** | **NSString*** |  | 
**breadcrumbs** | **NSArray&lt;NSString*&gt;*** |  | 
**usdaCode** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Spoonacular.SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**[SearchResult]**](SearchResult.md) |  | 
**groceryProducts** | [**[SearchResult]**](SearchResult.md) |  | 
**menuItems** | [**[SearchResult]**](SearchResult.md) |  | 
**recipes** | [**[SearchResult]**](SearchResult.md) |  | 



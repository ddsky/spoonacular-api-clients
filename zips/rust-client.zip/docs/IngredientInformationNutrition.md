# IngredientInformationNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**Vec<models::SearchGroceryProductsByUpc200ResponseNutritionNutrientsInner>**](searchGroceryProductsByUPC_200_response_nutrition_nutrients_inner.md) |  | 
**properties** | [**Vec<models::IngredientInformationNutritionPropertiesInner>**](IngredientInformation_nutrition_properties_inner.md) |  | 
**caloric_breakdown** | [**models::SearchGroceryProductsByUpc200ResponseNutritionCaloricBreakdown**](searchGroceryProductsByUPC_200_response_nutrition_caloricBreakdown.md) |  | 
**weight_per_serving** | [**models::GetShoppingList200ResponseAislesInnerItemsInnerMeasuresOriginal**](getShoppingList_200_response_aisles_inner_items_inner_measures_original.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



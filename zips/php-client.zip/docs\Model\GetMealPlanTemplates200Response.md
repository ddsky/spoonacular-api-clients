# # GetMealPlanTemplates200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**\com.spoonacular.client\com.spoonacular.client.model\GetAnalyzedRecipeInstructions200ResponseIngredientsInner[]**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

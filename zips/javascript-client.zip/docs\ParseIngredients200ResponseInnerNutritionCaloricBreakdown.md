# SpoonacularApi.ParseIngredients200ResponseInnerNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentProtein** | **Number** |  | 
**percentFat** | **Number** |  | 
**percentCarbs** | **Number** |  | 



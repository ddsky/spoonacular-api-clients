# WWW::OpenAPIClient::Object::GetSimilarRecipes200ResponseInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetSimilarRecipes200ResponseInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **string** |  | 
**image_type** | **string** |  | 
**ready_in_minutes** | **int** |  | 
**servings** | **double** |  | 
**source_url** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



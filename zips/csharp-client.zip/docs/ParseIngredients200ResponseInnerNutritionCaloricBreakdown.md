# Org.OpenAPITools.Model.ParseIngredients200ResponseInnerNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PercentProtein** | **decimal?** |  | 
**PercentFat** | **decimal?** |  | 
**PercentCarbs** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


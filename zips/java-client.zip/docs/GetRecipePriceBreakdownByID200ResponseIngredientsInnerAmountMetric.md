

# GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**unit** | **String** |  |  |
|**value** | **BigDecimal** |  |  |




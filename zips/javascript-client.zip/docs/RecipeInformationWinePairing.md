# SpoonacularApi.RecipeInformationWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **[String]** |  | [optional] 
**pairingText** | **String** |  | [optional] 
**productMatches** | [**[RecipeInformationWinePairingProductMatchesInner]**](RecipeInformationWinePairingProductMatchesInner.md) |  | [optional] 



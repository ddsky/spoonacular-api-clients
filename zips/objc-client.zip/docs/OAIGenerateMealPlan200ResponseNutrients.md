# OAIGenerateMealPlan200ResponseNutrients

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **NSNumber*** |  | 
**carbohydrates** | **NSNumber*** |  | 
**fat** | **NSNumber*** |  | 
**protein** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# IngredientSearch200ResponseResultsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **kotlin.Int** |  | 
**name** | **kotlin.String** |  | 
**image** | **kotlin.String** |  | 




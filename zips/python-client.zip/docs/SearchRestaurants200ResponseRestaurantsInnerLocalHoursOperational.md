# SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monday** | **str** |  | [optional] 
**tuesday** | **str** |  | [optional] 
**wednesday** | **str** |  | [optional] 
**thursday** | **str** |  | [optional] 
**friday** | **str** |  | [optional] 
**saturday** | **str** |  | [optional] 
**sunday** | **str** |  | [optional] 

## Example

```python
from spoonacular.models.search_restaurants200_response_restaurants_inner_local_hours_operational import SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

# TODO update the JSON string below
json = "{}"
# create an instance of SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational from a JSON string
search_restaurants200_response_restaurants_inner_local_hours_operational_instance = SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.from_json(json)
# print the JSON string representation of the object
print SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.to_json()

# convert the object into a dict
search_restaurants200_response_restaurants_inner_local_hours_operational_dict = search_restaurants200_response_restaurants_inner_local_hours_operational_instance.to_dict()
# create an instance of SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational from a dict
search_restaurants200_response_restaurants_inner_local_hours_operational_form_dict = search_restaurants200_response_restaurants_inner_local_hours_operational.from_dict(search_restaurants200_response_restaurants_inner_local_hours_operational_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# SearchFoodVideos200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**videos** | [**kotlin.collections.Set&lt;SearchFoodVideos200ResponseVideosInner&gt;**](SearchFoodVideos200ResponseVideosInner.md) |  | 
**totalResults** | **kotlin.Int** |  | 




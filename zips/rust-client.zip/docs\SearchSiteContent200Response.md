# SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**Vec<crate::models::SearchSiteContent200ResponseArticlesInner>**](searchSiteContent_200_response_Articles_inner.md) |  | 
**grocery_products** | [**Vec<crate::models::SearchSiteContent200ResponseGroceryProductsInner>**](searchSiteContent_200_response_Grocery_Products_inner.md) |  | 
**menu_items** | [**Vec<crate::models::SearchSiteContent200ResponseGroceryProductsInner>**](searchSiteContent_200_response_Grocery_Products_inner.md) |  | 
**recipes** | [**Vec<crate::models::SearchSiteContent200ResponseGroceryProductsInner>**](searchSiteContent_200_response_Grocery_Products_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



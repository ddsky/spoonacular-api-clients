# OpenapiClient::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **steps** | [**Array&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner.new(
  name: null,
  steps: null
)
```




# GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**steps** | [**Set&lt;GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner&gt;**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInnerStepsInner.md) |  |  [optional]





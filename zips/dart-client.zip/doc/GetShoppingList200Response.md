# openapi.model.GetShoppingList200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**Set<GetShoppingList200ResponseAislesInner>**](GetShoppingList200ResponseAislesInner.md) |  | [default to const {}]
**cost** | **num** |  | 
**startDate** | **num** |  | 
**endDate** | **num** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# ParseIngredients200ResponseInnerNutritionCaloricBreakdown


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**percentProtein** | **BigDecimal** |  |  |
|**percentFat** | **BigDecimal** |  |  |
|**percentCarbs** | **BigDecimal** |  |  |




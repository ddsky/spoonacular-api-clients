

# ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**min** | **BigDecimal** |  |  |
|**max** | **BigDecimal** |  |  |




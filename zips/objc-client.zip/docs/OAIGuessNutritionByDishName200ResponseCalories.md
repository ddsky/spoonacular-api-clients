# OAIGuessNutritionByDishName200ResponseCalories

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confidenceRange95Percent** | [**OAIGuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent***](OAIGuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent.md) |  | 
**standardDeviation** | **NSNumber*** |  | 
**unit** | **NSString*** |  | 
**value** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



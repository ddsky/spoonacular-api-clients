# spoonacular.Model.GetMealPlanWeek200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List&lt;GetMealPlanWeek200ResponseDaysInner&gt;**](GetMealPlanWeek200ResponseDaysInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


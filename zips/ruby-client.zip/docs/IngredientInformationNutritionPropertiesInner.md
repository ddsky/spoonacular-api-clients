# OpenapiClient::IngredientInformationNutritionPropertiesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **amount** | **Float** |  |  |
| **unit** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::IngredientInformationNutritionPropertiesInner.new(
  name: null,
  amount: null,
  unit: null
)
```


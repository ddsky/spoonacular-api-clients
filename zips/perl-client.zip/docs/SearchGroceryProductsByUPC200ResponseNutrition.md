# WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseNutrition

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGroceryProductsByUPC200ResponseNutrition;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**ARRAY[SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner]**](SearchGroceryProductsByUPC200ResponseNutritionNutrientsInner.md) |  | 
**caloric_breakdown** | [**SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown**](SearchGroceryProductsByUPC200ResponseNutritionCaloricBreakdown.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



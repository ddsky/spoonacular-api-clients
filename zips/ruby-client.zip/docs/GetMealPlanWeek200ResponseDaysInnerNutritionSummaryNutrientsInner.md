# OpenapiClient::GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  |  |
| **amount** | **Float** |  |  |
| **unit** | **String** |  |  |
| **percent_daily_needs** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetMealPlanWeek200ResponseDaysInnerNutritionSummaryNutrientsInner.new(
  name: null,
  amount: null,
  unit: null,
  percent_daily_needs: null
)
```


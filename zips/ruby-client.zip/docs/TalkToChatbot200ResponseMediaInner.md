# OpenapiClient::TalkToChatbot200ResponseMediaInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **title** | **String** |  | [optional] |
| **image** | **String** |  | [optional] |
| **link** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::TalkToChatbot200ResponseMediaInner.new(
  title: null,
  image: null,
  link: null
)
```


# OAIAnalyzeRecipeInstructions200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsedInstructions** | [**OAISet&lt;OAIAnalyzeRecipeInstructions200ResponseParsedInstructionsInner&gt;***](OAIAnalyzeRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**ingredients** | [**OAISet&lt;OAIAnalyzeRecipeInstructions200ResponseIngredientsInner&gt;***](OAIAnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 
**equipment** | [**OAISet&lt;OAIAnalyzeRecipeInstructions200ResponseIngredientsInner&gt;***](OAIAnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



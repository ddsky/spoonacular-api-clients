# AnalyzeARecipeSearchQuery200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dishes** | [**Vec<models::AnalyzeARecipeSearchQuery200ResponseDishesInner>**](analyzeARecipeSearchQuery_200_response_dishes_inner.md) |  | 
**ingredients** | [**Vec<models::AnalyzeARecipeSearchQuery200ResponseIngredientsInner>**](analyzeARecipeSearchQuery_200_response_ingredients_inner.md) |  | 
**cuisines** | **Vec<String>** |  | 
**modifiers** | **Vec<String>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



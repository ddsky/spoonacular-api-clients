

# ImageAnalysisByURL200ResponseRecipesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 
**url** | **String** |  | 





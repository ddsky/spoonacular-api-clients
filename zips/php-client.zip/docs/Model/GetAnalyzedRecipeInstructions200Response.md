# # GetAnalyzedRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsed_instructions** | [**\OpenAPI\Client\Model\GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner[]**](GetAnalyzedRecipeInstructions200ResponseParsedInstructionsInner.md) |  |
**ingredients** | [**\OpenAPI\Client\Model\GetAnalyzedRecipeInstructions200ResponseIngredientsInner[]**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  |
**equipment** | [**\OpenAPI\Client\Model\GetAnalyzedRecipeInstructions200ResponseIngredientsInner[]**](GetAnalyzedRecipeInstructions200ResponseIngredientsInner.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

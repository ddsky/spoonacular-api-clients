

# GetRecipeInformation200ResponseWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **List&lt;String&gt;** |  | 
**pairingText** | **String** |  | 
**productMatches** | [**Set&lt;GetRecipeInformation200ResponseWinePairingProductMatchesInner&gt;**](GetRecipeInformation200ResponseWinePairingProductMatchesInner.md) |  | 





# # SearchGroceryProducts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**\OpenAPI\Client\Model\AutocompleteRecipeSearch200ResponseInner[]**](AutocompleteRecipeSearch200ResponseInner.md) |  |
**total_products** | **int** |  |
**type** | **string** |  |
**offset** | **int** |  |
**number** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

# OpenapiClient::GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **metric** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  |  |
| **us** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.new(
  metric: null,
  us: null
)
```


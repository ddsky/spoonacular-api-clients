
# SearchMenuItems200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **menuItems** | [**kotlin.collections.Set&lt;MenuItem&gt;**](MenuItem.md) |  |  |
| **totalMenuItems** | **kotlin.Int** |  |  |
| **type** | **kotlin.String** |  |  |
| **offset** | **kotlin.Int** |  |  |
| **number** | **kotlin.Int** |  |  |




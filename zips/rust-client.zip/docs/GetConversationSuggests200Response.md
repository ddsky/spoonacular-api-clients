# GetConversationSuggests200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggests** | [**crate::models::GetConversationSuggests200ResponseSuggests**](getConversationSuggests_200_response_suggests.md) |  | 
**words** | [**Vec<serde_json::Value>**](serde_json::Value.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



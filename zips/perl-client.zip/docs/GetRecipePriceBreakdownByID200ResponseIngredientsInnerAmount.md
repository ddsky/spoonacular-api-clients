# WWW::OpenAPIClient::Object::GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  | 
**us** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmountMetric.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# spoonacular.Model.ImageAnalysisByURL200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nutrition** | [**ImageAnalysisByURL200ResponseNutrition**](ImageAnalysisByURL200ResponseNutrition.md) |  | 
**Category** | [**ImageAnalysisByURL200ResponseCategory**](ImageAnalysisByURL200ResponseCategory.md) |  | 
**Recipes** | [**List&lt;ImageAnalysisByURL200ResponseRecipesInner&gt;**](ImageAnalysisByURL200ResponseRecipesInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# GetRecipeInformation200ResponseExtendedIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **kotlin.String** |  | 
**amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**consitency** | **kotlin.String** |  | 
**id** | **kotlin.Int** |  | 
**image** | **kotlin.String** |  | 
**name** | **kotlin.String** |  | 
**original** | **kotlin.String** |  | 
**originalName** | **kotlin.String** |  | 
**unit** | **kotlin.String** |  | 
**measures** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures.md) |  |  [optional]
**meta** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional]




# openapi.model.ClassifyGroceryProduct200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cleanTitle** | **String** |  | 
**image** | **String** |  | 
**category** | **String** |  | 
**breadcrumbs** | **List<String>** |  | [default to const []]
**usdaCode** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)




# GetConversationSuggests200ResponseSuggests

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **underscore** | [**kotlin.collections.Set&lt;GetConversationSuggests200ResponseSuggestsInner&gt;**](GetConversationSuggests200ResponseSuggestsInner.md) |  |  |




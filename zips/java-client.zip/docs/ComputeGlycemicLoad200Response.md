

# ComputeGlycemicLoad200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**totalGlycemicLoad** | **BigDecimal** |  |  |
|**ingredients** | [**Set&lt;ComputeGlycemicLoad200ResponseIngredientsInner&gt;**](ComputeGlycemicLoad200ResponseIngredientsInner.md) |  |  |






# AnalyzeRecipeInstructions200ResponseIngredientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **BigDecimal** |  |  |
|**name** | **String** |  |  |




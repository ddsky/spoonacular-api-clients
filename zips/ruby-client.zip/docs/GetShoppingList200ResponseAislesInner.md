# OpenapiClient::GetShoppingList200ResponseAislesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **aisle** | **String** |  |  |
| **items** | [**Array&lt;GetShoppingList200ResponseAislesInnerItemsInner&gt;**](GetShoppingList200ResponseAislesInnerItemsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetShoppingList200ResponseAislesInner.new(
  aisle: null,
  items: null
)
```


# OpenapiClient::SearchSiteContent200ResponseArticlesInnerDataPointsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **key** | **String** |  |  |
| **value** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchSiteContent200ResponseArticlesInnerDataPointsInner.new(
  key: null,
  value: null
)
```


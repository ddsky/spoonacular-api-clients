# spoonacular.Model.GetComparableProducts200ResponseComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Calories** | **List&lt;Object&gt;** |  | 
**Likes** | **List&lt;Object&gt;** |  | 
**Price** | **List&lt;Object&gt;** |  | 
**Protein** | [**List&lt;GetComparableProducts200ResponseComparableProductsProteinInner&gt;**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**SpoonacularScore** | [**List&lt;GetComparableProducts200ResponseComparableProductsProteinInner&gt;**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**Sugar** | **List&lt;Object&gt;** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **kotlin.String** |  | 
**&#x60;value&#x60;** | **kotlin.String** |  | 




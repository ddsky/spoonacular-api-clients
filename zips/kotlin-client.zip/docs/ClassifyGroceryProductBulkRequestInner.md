
# ClassifyGroceryProductBulkRequestInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** |  |  |
| **upc** | **kotlin.String** |  |  |
| **pluCode** | **kotlin.String** |  |  |




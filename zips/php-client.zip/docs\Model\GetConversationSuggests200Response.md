# # GetConversationSuggests200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggests** | [**\com.spoonacular.client\com.spoonacular.client.model\GetConversationSuggests200ResponseSuggests**](GetConversationSuggests200ResponseSuggests.md) |  |
**words** | **mixed[]** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

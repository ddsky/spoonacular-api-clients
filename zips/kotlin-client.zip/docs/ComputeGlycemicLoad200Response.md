
# ComputeGlycemicLoad200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **totalGlycemicLoad** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **ingredients** | [**kotlin.collections.Set&lt;ComputeGlycemicLoad200ResponseIngredientsInner&gt;**](ComputeGlycemicLoad200ResponseIngredientsInner.md) |  |  |




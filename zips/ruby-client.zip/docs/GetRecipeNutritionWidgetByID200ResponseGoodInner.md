# OpenapiClient::GetRecipeNutritionWidgetByID200ResponseGoodInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | **String** |  |  |
| **indented** | **Boolean** |  |  |
| **percent_of_daily_needs** | **Float** |  |  |
| **name** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipeNutritionWidgetByID200ResponseGoodInner.new(
  amount: null,
  indented: null,
  percent_of_daily_needs: null,
  name: null
)
```


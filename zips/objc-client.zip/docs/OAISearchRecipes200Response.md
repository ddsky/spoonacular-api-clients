# OAISearchRecipes200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **NSNumber*** |  | 
**number** | **NSNumber*** |  | 
**results** | [**OAISet&lt;OAISearchRecipes200ResponseResultsInner&gt;***](OAISearchRecipes200ResponseResultsInner.md) |  | 
**totalResults** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



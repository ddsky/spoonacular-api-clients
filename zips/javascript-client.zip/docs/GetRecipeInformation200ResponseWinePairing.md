# SpoonacularApi.GetRecipeInformation200ResponseWinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **[String]** |  | 
**pairingText** | **String** |  | 
**productMatches** | [**[GetRecipeInformation200ResponseWinePairingProductMatchesInner]**](GetRecipeInformation200ResponseWinePairingProductMatchesInner.md) |  | 



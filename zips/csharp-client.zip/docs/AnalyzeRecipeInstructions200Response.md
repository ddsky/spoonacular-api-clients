# spoonacular.Model.AnalyzeRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParsedInstructions** | [**List&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**Ingredients** | [**List&lt;AnalyzeRecipeInstructions200ResponseIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 
**Equipment** | [**List&lt;AnalyzeRecipeInstructions200ResponseIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


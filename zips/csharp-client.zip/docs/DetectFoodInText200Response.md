# Org.OpenAPITools.Model.DetectFoodInText200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Annotations** | [**List<DetectFoodInText200ResponseAnnotationsInner>**](DetectFoodInText200ResponseAnnotationsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


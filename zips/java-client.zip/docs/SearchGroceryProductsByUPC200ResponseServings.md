

# SearchGroceryProductsByUPC200ResponseServings


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**number** | **BigDecimal** |  |  |
|**size** | **BigDecimal** |  |  |
|**unit** | **String** |  |  |




# ParseIngredients200ResponseInnerNutritionNutrientsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**amount** | **float** |  | 
**unit** | **str** |  | 
**percent_of_daily_needs** | **float** |  | 

## Example

```python
from spoonacular.models.parse_ingredients200_response_inner_nutrition_nutrients_inner import ParseIngredients200ResponseInnerNutritionNutrientsInner

# TODO update the JSON string below
json = "{}"
# create an instance of ParseIngredients200ResponseInnerNutritionNutrientsInner from a JSON string
parse_ingredients200_response_inner_nutrition_nutrients_inner_instance = ParseIngredients200ResponseInnerNutritionNutrientsInner.from_json(json)
# print the JSON string representation of the object
print ParseIngredients200ResponseInnerNutritionNutrientsInner.to_json()

# convert the object into a dict
parse_ingredients200_response_inner_nutrition_nutrients_inner_dict = parse_ingredients200_response_inner_nutrition_nutrients_inner_instance.to_dict()
# create an instance of ParseIngredients200ResponseInnerNutritionNutrientsInner from a dict
parse_ingredients200_response_inner_nutrition_nutrients_inner_form_dict = parse_ingredients200_response_inner_nutrition_nutrients_inner.from_dict(parse_ingredients200_response_inner_nutrition_nutrients_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



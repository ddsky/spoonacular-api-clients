
# ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **min** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **max** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |




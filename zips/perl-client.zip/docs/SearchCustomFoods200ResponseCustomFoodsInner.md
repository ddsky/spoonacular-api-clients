# WWW::OpenAPIClient::Object::SearchCustomFoods200ResponseCustomFoodsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchCustomFoods200ResponseCustomFoodsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **string** |  | 
**servings** | **double** |  | 
**image_url** | **string** |  | 
**price** | **double** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



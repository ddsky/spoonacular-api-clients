# # GetMealPlanWeek200ResponseDaysInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**slot** | **int** |  |
**position** | **int** |  |
**type** | **string** |  |
**value** | [**\OpenAPI\Client\Model\GetMealPlanWeek200ResponseDaysInnerItemsInnerValue**](GetMealPlanWeek200ResponseDaysInnerItemsInnerValue.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

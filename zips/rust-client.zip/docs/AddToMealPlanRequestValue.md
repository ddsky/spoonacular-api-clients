# AddToMealPlanRequestValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**Vec<models::AddToMealPlanRequestValueIngredientsInner>**](addToMealPlan_request_value_ingredients_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)





# ComputeGlycemicLoad200ResponseIngredientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  |
|**original** | **String** |  |  |
|**glycemicIndex** | **BigDecimal** |  |  |
|**glycemicLoad** | **BigDecimal** |  |  |




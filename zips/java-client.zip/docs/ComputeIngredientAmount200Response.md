

# ComputeIngredientAmount200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**amount** | **BigDecimal** |  |  |
|**unit** | **String** |  |  |




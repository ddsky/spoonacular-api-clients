# SearchAllFood200ResponseSearchResultsInnerResultsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**name** | **str** |  | 
**image** | **str** |  | 
**link** | **str** |  | 
**type** | **str** |  | 
**relevance** | **float** |  | 
**content** | **str** |  | 

## Example

```python
from spoonacular.models.search_all_food200_response_search_results_inner_results_inner import SearchAllFood200ResponseSearchResultsInnerResultsInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchAllFood200ResponseSearchResultsInnerResultsInner from a JSON string
search_all_food200_response_search_results_inner_results_inner_instance = SearchAllFood200ResponseSearchResultsInnerResultsInner.from_json(json)
# print the JSON string representation of the object
print SearchAllFood200ResponseSearchResultsInnerResultsInner.to_json()

# convert the object into a dict
search_all_food200_response_search_results_inner_results_inner_dict = search_all_food200_response_search_results_inner_results_inner_instance.to_dict()
# create an instance of SearchAllFood200ResponseSearchResultsInnerResultsInner from a dict
search_all_food200_response_search_results_inner_results_inner_form_dict = search_all_food200_response_search_results_inner_results_inner.from_dict(search_all_food200_response_search_results_inner_results_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Org.OpenAPITools.Model.SearchRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int?** |  | 
**Number** | **int?** |  | 
**Results** | [**List<SearchRecipes200ResponseResultsInner>**](SearchRecipes200ResponseResultsInner.md) |  | 
**TotalResults** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


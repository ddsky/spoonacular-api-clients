# OpenapiClient::SearchCustomFoods200ResponseCustomFoodsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** |  |  |
| **title** | **String** |  |  |
| **servings** | **Float** |  |  |
| **image_url** | **String** |  |  |
| **price** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchCustomFoods200ResponseCustomFoodsInner.new(
  id: null,
  title: null,
  servings: null,
  image_url: null,
  price: null
)
```


# GetShoppingList200ResponseAislesInnerItemsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Original** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 
**Metric** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 
**Us** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 

## Methods

### NewGetShoppingList200ResponseAislesInnerItemsInnerMeasures

`func NewGetShoppingList200ResponseAislesInnerItemsInnerMeasures(original ParseIngredients200ResponseInnerNutritionWeightPerServing, metric ParseIngredients200ResponseInnerNutritionWeightPerServing, us ParseIngredients200ResponseInnerNutritionWeightPerServing, ) *GetShoppingList200ResponseAislesInnerItemsInnerMeasures`

NewGetShoppingList200ResponseAislesInnerItemsInnerMeasures instantiates a new GetShoppingList200ResponseAislesInnerItemsInnerMeasures object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresWithDefaults

`func NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresWithDefaults() *GetShoppingList200ResponseAislesInnerItemsInnerMeasures`

NewGetShoppingList200ResponseAislesInnerItemsInnerMeasuresWithDefaults instantiates a new GetShoppingList200ResponseAislesInnerItemsInnerMeasures object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetOriginal

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetOriginal() ParseIngredients200ResponseInnerNutritionWeightPerServing`

GetOriginal returns the Original field if non-nil, zero value otherwise.

### GetOriginalOk

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetOriginalOk() (*ParseIngredients200ResponseInnerNutritionWeightPerServing, bool)`

GetOriginalOk returns a tuple with the Original field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOriginal

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) SetOriginal(v ParseIngredients200ResponseInnerNutritionWeightPerServing)`

SetOriginal sets Original field to given value.


### GetMetric

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetMetric() ParseIngredients200ResponseInnerNutritionWeightPerServing`

GetMetric returns the Metric field if non-nil, zero value otherwise.

### GetMetricOk

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetMetricOk() (*ParseIngredients200ResponseInnerNutritionWeightPerServing, bool)`

GetMetricOk returns a tuple with the Metric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetric

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) SetMetric(v ParseIngredients200ResponseInnerNutritionWeightPerServing)`

SetMetric sets Metric field to given value.


### GetUs

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetUs() ParseIngredients200ResponseInnerNutritionWeightPerServing`

GetUs returns the Us field if non-nil, zero value otherwise.

### GetUsOk

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) GetUsOk() (*ParseIngredients200ResponseInnerNutritionWeightPerServing, bool)`

GetUsOk returns a tuple with the Us field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUs

`func (o *GetShoppingList200ResponseAislesInnerItemsInnerMeasures) SetUs(v ParseIngredients200ResponseInnerNutritionWeightPerServing)`

SetUs sets Us field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OpenapiClient::GetRecipePriceBreakdownByID200ResponseIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | [**GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount**](GetRecipePriceBreakdownByID200ResponseIngredientsInnerAmount.md) |  | [optional] |
| **image** | **String** |  |  |
| **name** | **String** |  |  |
| **price** | **Float** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GetRecipePriceBreakdownByID200ResponseIngredientsInner.new(
  amount: null,
  image: null,
  name: null,
  price: null
)
```


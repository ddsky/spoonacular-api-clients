# OAISearchGroceryProducts200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**OAISet&lt;OAIAutocompleteRecipeSearch200ResponseInner&gt;***](OAIAutocompleteRecipeSearch200ResponseInner.md) |  | 
**totalProducts** | **NSNumber*** |  | 
**type** | **NSString*** |  | 
**offset** | **NSNumber*** |  | 
**number** | **NSNumber*** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



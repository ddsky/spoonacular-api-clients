
# AddToMealPlanRequestValue

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **ingredients** | [**kotlin.collections.Set&lt;AddToMealPlanRequestValueIngredientsInner&gt;**](AddToMealPlanRequestValueIngredientsInner.md) |  |  |




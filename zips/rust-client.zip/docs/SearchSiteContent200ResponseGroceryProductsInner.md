# SearchSiteContent200ResponseGroceryProductsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_points** | Option<[**Vec<crate::models::SearchSiteContent200ResponseGroceryProductsInnerDataPointsInner>**](searchSiteContent_200_response_Grocery_Products_inner_dataPoints_inner.md)> |  | [optional]
**image** | **String** |  | 
**link** | **String** |  | 
**name** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



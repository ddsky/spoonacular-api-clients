# # SearchRestaurants200ResponseRestaurantsInnerAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**street_addr** | **string** |  | [optional]
**city** | **string** |  | [optional]
**state** | **string** |  | [optional]
**zipcode** | **string** |  | [optional]
**country** | **string** |  | [optional]
**lat** | **float** |  | [optional]
**lon** | **float** |  | [optional]
**street_addr_2** | **string** |  | [optional]
**latitude** | **float** |  | [optional]
**longitude** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)

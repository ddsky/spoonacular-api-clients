

# GetRecipeEquipmentByID200Response



## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**equipment** | [**Set&lt;GetRecipeEquipmentByID200ResponseEquipmentInner&gt;**](GetRecipeEquipmentByID200ResponseEquipmentInner.md) |  |  |






# GetMealPlanWeek200ResponseDaysInnerItemsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  |
|**slot** | **Integer** |  |  |
|**position** | **Integer** |  |  |
|**type** | **String** |  |  |
|**value** | [**GetMealPlanWeek200ResponseDaysInnerItemsInnerValue**](GetMealPlanWeek200ResponseDaysInnerItemsInnerValue.md) |  |  [optional] |




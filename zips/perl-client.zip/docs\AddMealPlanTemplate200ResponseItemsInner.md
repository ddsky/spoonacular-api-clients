# WWW::OpenAPIClient::Object::AddMealPlanTemplate200ResponseItemsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AddMealPlanTemplate200ResponseItemsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**day** | **int** |  | 
**slot** | **int** |  | 
**position** | **int** |  | 
**type** | **string** |  | 
**value** | [**AddMealPlanTemplate200ResponseItemsInnerValue**](AddMealPlanTemplate200ResponseItemsInnerValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



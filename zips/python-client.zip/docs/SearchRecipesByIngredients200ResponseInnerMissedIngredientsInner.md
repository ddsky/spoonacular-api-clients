# SearchRecipesByIngredients200ResponseInnerMissedIngredientsInner


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **str** |  | 
**amount** | **float** |  | 
**id** | **int** |  | 
**image** | **str** |  | 
**name** | **str** |  | 
**original** | **str** |  | 
**original_name** | **str** |  | 
**unit** | **str** |  | 
**unit_long** | **str** |  | 
**unit_short** | **str** |  | 
**meta** | **[str]** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



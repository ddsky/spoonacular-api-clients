# SearchFoodVideos200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**videos** | [**Vec<crate::models::SearchFoodVideos200ResponseVideosInner>**](searchFoodVideos_200_response_videos_inner.md) |  | 
**total_results** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



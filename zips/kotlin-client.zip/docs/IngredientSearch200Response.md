
# IngredientSearch200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **results** | [**kotlin.collections.Set&lt;IngredientSearch200ResponseResultsInner&gt;**](IngredientSearch200ResponseResultsInner.md) |  |  |
| **offset** | **kotlin.Int** |  |  |
| **number** | **kotlin.Int** |  |  |
| **totalResults** | **kotlin.Int** |  |  |




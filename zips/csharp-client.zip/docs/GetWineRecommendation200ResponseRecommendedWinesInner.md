# spoonacular.Model.GetWineRecommendation200ResponseRecommendedWinesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | 
**Title** | **string** |  | 
**AverageRating** | **decimal** |  | 
**Description** | **string** |  | 
**ImageUrl** | **string** |  | 
**Link** | **string** |  | 
**Price** | **string** |  | 
**RatingCount** | **int** |  | 
**Score** | **decimal** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ConvertAmounts200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **sourceAmount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **sourceUnit** | **kotlin.String** |  |  |
| **targetAmount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **targetUnit** | **kotlin.String** |  |  |
| **answer** | **kotlin.String** |  |  |




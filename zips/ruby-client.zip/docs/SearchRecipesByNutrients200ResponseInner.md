# OpenapiClient::SearchRecipesByNutrients200ResponseInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **calories** | **Float** |  |  |
| **carbs** | **String** |  |  |
| **fat** | **String** |  |  |
| **id** | **Integer** |  |  |
| **image** | **String** |  |  |
| **image_type** | **String** |  |  |
| **protein** | **String** |  |  |
| **title** | **String** |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRecipesByNutrients200ResponseInner.new(
  calories: null,
  carbs: null,
  fat: null,
  id: null,
  image: null,
  image_type: null,
  protein: null,
  title: null
)
```


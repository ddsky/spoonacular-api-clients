# spoonacular.Model.GetRecipeInformation200ResponseExtendedIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.md) |  | 
**Us** | [**GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric**](GetRecipeInformation200ResponseExtendedIngredientsInnerMeasuresMetric.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

